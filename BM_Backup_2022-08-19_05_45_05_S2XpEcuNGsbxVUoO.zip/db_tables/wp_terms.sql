/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_terms`; */
/* PRE_TABLE_NAME: `1660887906_wp_terms`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ( 
/* VALUES START */
1,
'Uncategorized',
'uncategorized',
0
/* VALUES END */
), (
/* VALUES START */
2,
'simple',
'simple',
0
/* VALUES END */
), (
/* VALUES START */
3,
'grouped',
'grouped',
0
/* VALUES END */
), (
/* VALUES START */
4,
'variable',
'variable',
0
/* VALUES END */
), (
/* VALUES START */
5,
'external',
'external',
0
/* VALUES END */
), (
/* VALUES START */
6,
'exclude-from-search',
'exclude-from-search',
0
/* VALUES END */
), (
/* VALUES START */
7,
'exclude-from-catalog',
'exclude-from-catalog',
0
/* VALUES END */
), (
/* VALUES START */
8,
'featured',
'featured',
0
/* VALUES END */
), (
/* VALUES START */
9,
'outofstock',
'outofstock',
0
/* VALUES END */
), (
/* VALUES START */
10,
'rated-1',
'rated-1',
0
/* VALUES END */
), (
/* VALUES START */
11,
'rated-2',
'rated-2',
0
/* VALUES END */
), (
/* VALUES START */
12,
'rated-3',
'rated-3',
0
/* VALUES END */
), (
/* VALUES START */
13,
'rated-4',
'rated-4',
0
/* VALUES END */
), (
/* VALUES START */
14,
'rated-5',
'rated-5',
0
/* VALUES END */
), (
/* VALUES START */
15,
'Uncategorized',
'uncategorized',
0
/* VALUES END */
), (
/* VALUES START */
18,
'Primary Menu',
'primary-menu',
0
/* VALUES END */
), (
/* VALUES START */
19,
'Quick Links',
'quick-links',
0
/* VALUES END */
), (
/* VALUES START */
20,
'Site Links',
'site-links',
0
/* VALUES END */
), (
/* VALUES START */
21,
'astra',
'astra',
0
/* VALUES END */
), (
/* VALUES START */
22,
'Fruits',
'fruits',
0
/* VALUES END */
), (
/* VALUES START */
23,
'Mr. abcd',
'mr-abcd',
0
/* VALUES END */
), (
/* VALUES START */
24,
'Mr. Abcd',
'mr-abcd',
0
/* VALUES END */
), (
/* VALUES START */
25,
'Vegetables',
'vegetables',
0
/* VALUES END */
);
/* QUERY END */

