/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_category_lookup`; */
/* PRE_TABLE_NAME: `1660887906_wp_wc_category_lookup`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_wc_category_lookup` (`category_tree_id`, `category_id`) VALUES ( 
/* VALUES START */
15,
15
/* VALUES END */
), (
/* VALUES START */
16,
16
/* VALUES END */
), (
/* VALUES START */
17,
17
/* VALUES END */
), (
/* VALUES START */
22,
22
/* VALUES END */
), (
/* VALUES START */
25,
25
/* VALUES END */
);
/* QUERY END */

