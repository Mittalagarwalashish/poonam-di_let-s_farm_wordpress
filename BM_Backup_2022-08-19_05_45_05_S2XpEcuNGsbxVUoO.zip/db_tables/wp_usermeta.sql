/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_usermeta`; */
/* PRE_TABLE_NAME: `1660887906_wp_usermeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
1,
'nickname',
'mukulyashi@gmail.com'
/* VALUES END */
), (
/* VALUES START */
2,
1,
'first_name',
'Mukul'
/* VALUES END */
), (
/* VALUES START */
3,
1,
'last_name',
'Kumar'
/* VALUES END */
), (
/* VALUES START */
4,
1,
'description',
''
/* VALUES END */
), (
/* VALUES START */
5,
1,
'rich_editing',
'true'
/* VALUES END */
), (
/* VALUES START */
6,
1,
'syntax_highlighting',
'true'
/* VALUES END */
), (
/* VALUES START */
7,
1,
'comment_shortcuts',
'false'
/* VALUES END */
), (
/* VALUES START */
8,
1,
'admin_color',
'fresh'
/* VALUES END */
), (
/* VALUES START */
9,
1,
'use_ssl',
0
/* VALUES END */
), (
/* VALUES START */
10,
1,
'show_admin_bar_front',
'true'
/* VALUES END */
), (
/* VALUES START */
11,
1,
'locale',
''
/* VALUES END */
), (
/* VALUES START */
12,
1,
'wp_capabilities',
'a:1:{s:13:\"administrator\";b:1;}'
/* VALUES END */
), (
/* VALUES START */
13,
1,
'wp_user_level',
10
/* VALUES END */
), (
/* VALUES START */
14,
1,
'dismissed_wp_pointers',
''
/* VALUES END */
), (
/* VALUES START */
15,
1,
'show_welcome_panel',
0
/* VALUES END */
), (
/* VALUES START */
17,
1,
'wp_dashboard_quick_press_last_post_id',
4052
/* VALUES END */
), (
/* VALUES START */
18,
1,
'astra-sites-on-active',
'notice-dismissed'
/* VALUES END */
), (
/* VALUES START */
19,
1,
'wc_last_active',
1660867200
/* VALUES END */
), (
/* VALUES START */
20,
1,
'_woocommerce_tracks_anon_id',
'woo:OhJwW42uh4yc6EYPj4siWcXm'
/* VALUES END */
), (
/* VALUES START */
21,
1,
'wp_user-settings',
'libraryContent=browse'
/* VALUES END */
), (
/* VALUES START */
22,
1,
'wp_user-settings-time',
1655099921
/* VALUES END */
), (
/* VALUES START */
23,
1,
'cartflows-ca-5-star-notice',
'delayed-notice'
/* VALUES END */
), (
/* VALUES START */
24,
1,
'astra-sites-5-start-notice',
'notice-dismissed'
/* VALUES END */
), (
/* VALUES START */
25,
1,
'dismissed_no_secure_connection_notice',
1
/* VALUES END */
), (
/* VALUES START */
26,
1,
'last_update',
1656435247
/* VALUES END */
), (
/* VALUES START */
27,
1,
'woocommerce_admin_task_list_tracked_started_tasks',
'{\"shipping\":1}'
/* VALUES END */
), (
/* VALUES START */
29,
1,
'billing_first_name',
'Mukul'
/* VALUES END */
), (
/* VALUES START */
30,
1,
'billing_last_name',
'Kumar'
/* VALUES END */
), (
/* VALUES START */
31,
1,
'billing_address_1',
'B-15, Ramnagar Extension, Sodhala, Jaipur'
/* VALUES END */
), (
/* VALUES START */
32,
1,
'billing_address_2',
'Ekadash Kunj Apartment'
/* VALUES END */
), (
/* VALUES START */
33,
1,
'billing_city',
'Jaipur'
/* VALUES END */
), (
/* VALUES START */
34,
1,
'billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
35,
1,
'billing_postcode',
302019
/* VALUES END */
), (
/* VALUES START */
36,
1,
'billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
37,
1,
'billing_email',
'mukulyashi@gmail.com'
/* VALUES END */
), (
/* VALUES START */
38,
1,
'billing_phone',
6350672348
/* VALUES END */
), (
/* VALUES START */
39,
1,
'shipping_method',
''
/* VALUES END */
), (
/* VALUES START */
42,
1,
'session_tokens',
'a:1:{s:64:\"698bc7ca691ce2e4ae983737d46429c5c86f76b18b1b0a61e14fd75c373ed0e1\";a:4:{s:10:\"expiration\";i:1661060670;s:2:\"ip\";s:12:\"49.36.234.12\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36\";s:5:\"login\";i:1660887870;}}'
/* VALUES END */
), (
/* VALUES START */
44,
1,
'paying_customer',
1
/* VALUES END */
), (
/* VALUES START */
49,
1,
'woocommerce_admin_homepage_layout',
'\"two_columns\"'
/* VALUES END */
), (
/* VALUES START */
50,
1,
'dokan_enable_selling',
'yes'
/* VALUES END */
), (
/* VALUES START */
51,
2,
'nickname',
'mukuljaipur.2000'
/* VALUES END */
), (
/* VALUES START */
52,
2,
'first_name',
''
/* VALUES END */
), (
/* VALUES START */
53,
2,
'last_name',
''
/* VALUES END */
), (
/* VALUES START */
54,
2,
'description',
''
/* VALUES END */
), (
/* VALUES START */
55,
2,
'rich_editing',
'true'
/* VALUES END */
), (
/* VALUES START */
56,
2,
'syntax_highlighting',
'true'
/* VALUES END */
), (
/* VALUES START */
57,
2,
'comment_shortcuts',
'false'
/* VALUES END */
), (
/* VALUES START */
58,
2,
'admin_color',
'fresh'
/* VALUES END */
), (
/* VALUES START */
59,
2,
'use_ssl',
0
/* VALUES END */
), (
/* VALUES START */
60,
2,
'show_admin_bar_front',
'true'
/* VALUES END */
), (
/* VALUES START */
61,
2,
'locale',
''
/* VALUES END */
), (
/* VALUES START */
62,
2,
'wp_capabilities',
'a:1:{s:8:\"customer\";b:1;}'
/* VALUES END */
), (
/* VALUES START */
63,
2,
'wp_user_level',
0
/* VALUES END */
), (
/* VALUES START */
64,
2,
'last_update',
1655359894
/* VALUES END */
), (
/* VALUES START */
65,
2,
'session_tokens',
'a:1:{s:64:\"980ea9cd082dd47eb4ad2c3e8dbf35029a61693e54b93ca6fcf22814cb8b0138\";a:4:{s:10:\"expiration\";i:1656569497;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36\";s:5:\"login\";i:1655359897;}}'
/* VALUES END */
), (
/* VALUES START */
66,
2,
'wc_last_active',
1655337600
/* VALUES END */
), (
/* VALUES START */
67,
1,
'dokan_profile_settings',
'a:19:{s:10:\"store_name\";s:10:\"Mukul shop\";s:6:\"social\";a:7:{s:2:\"fb\";s:0:\"\";s:7:\"twitter\";s:0:\"\";s:9:\"pinterest\";s:0:\"\";s:8:\"linkedin\";s:0:\"\";s:7:\"youtube\";s:0:\"\";s:9:\"instagram\";s:0:\"\";s:6:\"flickr\";s:0:\"\";}s:7:\"payment\";a:2:{s:6:\"paypal\";a:1:{i:0;s:5:\"email\";}s:4:\"bank\";a:0:{}}s:5:\"phone\";s:0:\"\";s:10:\"show_email\";s:2:\"no\";s:7:\"address\";a:6:{s:8:\"street_1\";s:0:\"\";s:8:\"street_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:3:\"zip\";s:0:\"\";s:7:\"country\";s:0:\"\";s:5:\"state\";s:0:\"\";}s:8:\"location\";s:0:\"\";s:6:\"banner\";i:0;s:4:\"icon\";i:0;s:8:\"gravatar\";i:0;s:14:\"show_more_ptab\";s:3:\"yes\";s:9:\"store_ppp\";i:12;s:10:\"enable_tnc\";s:3:\"off\";s:9:\"store_tnc\";s:0:\"\";s:23:\"show_min_order_discount\";s:2:\"no\";s:9:\"store_seo\";a:0:{}s:24:\"dokan_store_time_enabled\";s:2:\"no\";s:23:\"dokan_store_open_notice\";s:0:\"\";s:24:\"dokan_store_close_notice\";s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
68,
1,
'dokan_publishing',
'no'
/* VALUES END */
), (
/* VALUES START */
69,
1,
'dokan_admin_percentage',
''
/* VALUES END */
), (
/* VALUES START */
70,
1,
'dokan_admin_percentage_type',
'flat'
/* VALUES END */
), (
/* VALUES START */
71,
1,
'dokan_feature_seller',
'no'
/* VALUES END */
), (
/* VALUES START */
72,
1,
'dokan_store_name',
'Mukul shop'
/* VALUES END */
), (
/* VALUES START */
73,
1,
'billing_company',
''
/* VALUES END */
), (
/* VALUES START */
74,
1,
'shipping_first_name',
''
/* VALUES END */
), (
/* VALUES START */
75,
1,
'shipping_last_name',
''
/* VALUES END */
), (
/* VALUES START */
76,
1,
'shipping_company',
''
/* VALUES END */
), (
/* VALUES START */
77,
1,
'shipping_address_1',
''
/* VALUES END */
), (
/* VALUES START */
78,
1,
'shipping_address_2',
''
/* VALUES END */
), (
/* VALUES START */
79,
1,
'shipping_city',
''
/* VALUES END */
), (
/* VALUES START */
80,
1,
'shipping_postcode',
''
/* VALUES END */
), (
/* VALUES START */
81,
1,
'shipping_country',
''
/* VALUES END */
), (
/* VALUES START */
82,
1,
'shipping_state',
''
/* VALUES END */
), (
/* VALUES START */
83,
1,
'shipping_phone',
''
/* VALUES END */
), (
/* VALUES START */
86,
1,
'community-events-location',
'a:1:{s:2:\"ip\";s:11:\"49.36.234.0\";}'
/* VALUES END */
), (
/* VALUES START */
87,
3,
'nickname',
'poonamagarwal0071'
/* VALUES END */
), (
/* VALUES START */
88,
3,
'first_name',
'Poonam'
/* VALUES END */
), (
/* VALUES START */
89,
3,
'last_name',
'Agarwal'
/* VALUES END */
), (
/* VALUES START */
90,
3,
'description',
''
/* VALUES END */
), (
/* VALUES START */
91,
3,
'rich_editing',
'true'
/* VALUES END */
), (
/* VALUES START */
92,
3,
'syntax_highlighting',
'true'
/* VALUES END */
), (
/* VALUES START */
93,
3,
'comment_shortcuts',
'false'
/* VALUES END */
), (
/* VALUES START */
94,
3,
'admin_color',
'fresh'
/* VALUES END */
), (
/* VALUES START */
95,
3,
'use_ssl',
0
/* VALUES END */
), (
/* VALUES START */
96,
3,
'show_admin_bar_front',
'true'
/* VALUES END */
), (
/* VALUES START */
97,
3,
'locale',
''
/* VALUES END */
), (
/* VALUES START */
98,
3,
'wp_capabilities',
'a:1:{s:6:\"seller\";b:1;}'
/* VALUES END */
), (
/* VALUES START */
99,
3,
'wp_user_level',
0
/* VALUES END */
), (
/* VALUES START */
100,
3,
'dokan_enable_selling',
'yes'
/* VALUES END */
), (
/* VALUES START */
101,
3,
'dokan_profile_settings',
'a:22:{s:10:\"store_name\";s:11:\"Shree Store\";s:6:\"social\";a:7:{s:2:\"fb\";s:0:\"\";s:7:\"twitter\";s:0:\"\";s:9:\"pinterest\";s:0:\"\";s:8:\"linkedin\";s:0:\"\";s:7:\"youtube\";s:0:\"\";s:9:\"instagram\";s:0:\"\";s:6:\"flickr\";s:0:\"\";}s:7:\"payment\";a:0:{}s:5:\"phone\";s:10:\"8209314091\";s:10:\"show_email\";s:3:\"yes\";s:7:\"address\";a:6:{s:8:\"street_1\";s:0:\"\";s:8:\"street_2\";s:0:\"\";s:4:\"city\";s:0:\"\";s:3:\"zip\";s:0:\"\";s:7:\"country\";s:2:\"IN\";s:5:\"state\";s:2:\"RJ\";}s:8:\"location\";s:0:\"\";s:6:\"banner\";i:0;s:4:\"icon\";i:0;s:8:\"gravatar\";i:0;s:14:\"show_more_ptab\";s:3:\"yes\";s:9:\"store_ppp\";i:12;s:10:\"enable_tnc\";s:3:\"off\";s:9:\"store_tnc\";s:0:\"\";s:23:\"show_min_order_discount\";s:2:\"no\";s:9:\"store_seo\";a:0:{}s:24:\"dokan_store_time_enabled\";s:2:\"no\";s:23:\"dokan_store_open_notice\";s:0:\"\";s:24:\"dokan_store_close_notice\";s:0:\"\";s:12:\"find_address\";s:0:\"\";s:14:\"dokan_category\";s:0:\"\";s:18:\"profile_completion\";a:6:{s:10:\"store_name\";i:10;s:5:\"phone\";i:10;s:9:\"next_todo\";s:10:\"banner_val\";s:8:\"progress\";i:30;s:13:\"progress_vals\";a:8:{s:10:\"banner_val\";i:15;s:19:\"profile_picture_val\";i:15;s:14:\"store_name_val\";i:10;s:11:\"address_val\";i:10;s:9:\"phone_val\";i:10;s:7:\"map_val\";i:15;s:18:\"payment_method_val\";i:15;s:10:\"social_val\";a:4:{s:2:\"fb\";i:4;s:7:\"twitter\";i:2;s:7:\"youtube\";i:2;s:8:\"linkedin\";i:2;}}s:7:\"address\";i:10;}}'
/* VALUES END */
), (
/* VALUES START */
102,
3,
'dokan_store_name',
'Shree Store'
/* VALUES END */
), (
/* VALUES START */
103,
3,
'last_update',
1656435404
/* VALUES END */
), (
/* VALUES START */
105,
3,
'wc_last_active',
1656374400
/* VALUES END */
), (
/* VALUES START */
108,
3,
'_woocommerce_persistent_cart_1',
'a:1:{s:4:\"cart\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
111,
4,
'nickname',
'ashishshiv781'
/* VALUES END */
), (
/* VALUES START */
112,
4,
'first_name',
'Ashish'
/* VALUES END */
), (
/* VALUES START */
113,
4,
'last_name',
'Agarwal'
/* VALUES END */
), (
/* VALUES START */
114,
4,
'description',
''
/* VALUES END */
), (
/* VALUES START */
115,
4,
'rich_editing',
'true'
/* VALUES END */
), (
/* VALUES START */
116,
4,
'syntax_highlighting',
'true'
/* VALUES END */
), (
/* VALUES START */
117,
4,
'comment_shortcuts',
'false'
/* VALUES END */
), (
/* VALUES START */
118,
4,
'admin_color',
'fresh'
/* VALUES END */
), (
/* VALUES START */
119,
4,
'use_ssl',
0
/* VALUES END */
), (
/* VALUES START */
120,
4,
'show_admin_bar_front',
'true'
/* VALUES END */
), (
/* VALUES START */
121,
4,
'locale',
''
/* VALUES END */
), (
/* VALUES START */
122,
4,
'wp_capabilities',
'a:1:{s:8:\"customer\";b:1;}'
/* VALUES END */
), (
/* VALUES START */
123,
4,
'wp_user_level',
0
/* VALUES END */
), (
/* VALUES START */
124,
4,
'last_update',
1657812206
/* VALUES END */
), (
/* VALUES START */
126,
4,
'wc_last_active',
1657756800
/* VALUES END */
), (
/* VALUES START */
129,
4,
'billing_first_name',
'Ashish'
/* VALUES END */
), (
/* VALUES START */
130,
4,
'billing_last_name',
'Agarwal'
/* VALUES END */
), (
/* VALUES START */
131,
4,
'billing_address_1',
'ls nagr'
/* VALUES END */
), (
/* VALUES START */
132,
4,
'billing_city',
'jaipur'
/* VALUES END */
), (
/* VALUES START */
133,
4,
'billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
134,
4,
'billing_postcode',
302039
/* VALUES END */
), (
/* VALUES START */
135,
4,
'billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
136,
4,
'billing_email',
'ashishshiv781@gmail.com'
/* VALUES END */
), (
/* VALUES START */
137,
4,
'billing_phone',
9876543210
/* VALUES END */
), (
/* VALUES START */
138,
4,
'shipping_method',
''
/* VALUES END */
), (
/* VALUES START */
153,
5,
'nickname',
'testcustomer'
/* VALUES END */
), (
/* VALUES START */
154,
5,
'first_name',
'test'
/* VALUES END */
), (
/* VALUES START */
155,
5,
'last_name',
'customer'
/* VALUES END */
), (
/* VALUES START */
156,
5,
'description',
''
/* VALUES END */
), (
/* VALUES START */
157,
5,
'rich_editing',
'true'
/* VALUES END */
), (
/* VALUES START */
158,
5,
'syntax_highlighting',
'true'
/* VALUES END */
), (
/* VALUES START */
159,
5,
'comment_shortcuts',
'false'
/* VALUES END */
), (
/* VALUES START */
160,
5,
'admin_color',
'fresh'
/* VALUES END */
), (
/* VALUES START */
161,
5,
'use_ssl',
0
/* VALUES END */
), (
/* VALUES START */
162,
5,
'show_admin_bar_front',
'true'
/* VALUES END */
), (
/* VALUES START */
163,
5,
'locale',
''
/* VALUES END */
), (
/* VALUES START */
164,
5,
'wp_capabilities',
'a:1:{s:8:\"customer\";b:1;}'
/* VALUES END */
), (
/* VALUES START */
165,
5,
'wp_user_level',
0
/* VALUES END */
), (
/* VALUES START */
166,
5,
'dismissed_wp_pointers',
''
/* VALUES END */
), (
/* VALUES START */
168,
5,
'wc_last_active',
1656979200
/* VALUES END */
), (
/* VALUES START */
170,
5,
'_woocommerce_persistent_cart_1',
'a:1:{s:4:\"cart\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
174,
1,
'nav_menu_recently_edited',
18
/* VALUES END */
), (
/* VALUES START */
175,
1,
'managenav-menuscolumnshidden',
'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'
/* VALUES END */
), (
/* VALUES START */
176,
1,
'metaboxhidden_nav-menus',
'a:5:{i:0;s:21:\"add-post-type-product\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";i:3;s:15:\"add-product_cat\";i:4;s:15:\"add-product_tag\";}'
/* VALUES END */
), (
/* VALUES START */
182,
4,
'session_tokens',
'a:1:{s:64:\"03bfe8558eddb2db9cea24aed5bf3e34ebb7bb0907ac33e49c9c219cc2d40f61\";a:4:{s:10:\"expiration\";i:1657984953;s:2:\"ip\";s:14:\"223.177.215.57\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36\";s:5:\"login\";i:1657812153;}}'
/* VALUES END */
), (
/* VALUES START */
186,
1,
'_woocommerce_persistent_cart_1',
'a:1:{s:4:\"cart\";a:0:{}}'
/* VALUES END */
);
/* QUERY END */

