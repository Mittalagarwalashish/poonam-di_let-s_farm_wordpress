/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_aioseo_notifications`; */
/* PRE_TABLE_NAME: `1660887906_wp_aioseo_notifications`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_aioseo_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(13) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `level` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `notification_id` bigint(20) unsigned DEFAULT NULL,
  `notification_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `button1_label` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `button1_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `button2_label` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `button2_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dismissed` tinyint(1) NOT NULL DEFAULT 0,
  `new` tinyint(1) NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ndx_aioseo_notifications_slug` (`slug`),
  KEY `ndx_aioseo_notifications_dates` (`start`,`end`),
  KEY `ndx_aioseo_notifications_type` (`type`),
  KEY `ndx_aioseo_notifications_dismissed` (`dismissed`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_aioseo_notifications` (`id`, `slug`, `title`, `content`, `type`, `level`, `notification_id`, `notification_name`, `start`, `end`, `button1_label`, `button1_action`, `button2_label`, `button2_action`, `dismissed`, `new`, `created`, `updated`) VALUES ( 
/* VALUES START */
1,
'62bb1f514bae2',
'Advanced WooCommerce Support',
'We have detected you are running WooCommerce. Upgrade to AIOSEO Pro to unlock our advanced eCommerce SEO features, including SEO for Product Categories and more.',
'info',
'[\"all\"]',
'',
'woo-upsell',
'2022-06-28 15:33:37',
'',
'Upgrade to Pro',
'https://aioseo.com/lite-upgrade/?utm_source=WordPress&utm_campaign=liteplugin&utm_medium=woo-notification-upsell',
'',
'',
0,
0,
'2022-06-28 15:33:37',
'2022-06-28 15:33:37'
/* VALUES END */
), (
/* VALUES START */
2,
'62bb1f8acd8b6',
'LAST CHANCE: Our Birthday Celebration is Almost Over! ⌛',
'AIOSEO just turned <strong>15 years old</strong> and we\'ve been celebrating all week with as much as <strong>65% off our paid plans</strong>! 🥳\r\n<br><br>\r\nThe party’s almost over and you’re about to miss out on this amazing birthday celebration deal.\r\n<br><br>\r\nMake sure to grab yours ASAP because it <strong>expires today!</strong> 🎉 🎉',
'success',
'[\"4-x\",\"lite\"]',
399,
'',
'2022-06-29 00:00:00',
'2022-06-30 00:00:00',
'Get AIOSEO Pro NOW! (65% OFF)',
'https://aioseo.com/pricing-lite/?utm_source=WordPress&utm_campaign=15th-birthday-sale-last-chance-v4-lite&utm_medium=plugin-notification&utm_content=Get%20AIOSEO%20Pro%20NOW!%20(65%%20OFF)',
'',
'',
0,
1,
'2022-06-28 15:34:34',
'2022-06-28 15:34:34'
/* VALUES END */
);
/* QUERY END */

