/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_admin_note_actions`; */
/* PRE_TABLE_NAME: `1660887906_wp_wc_admin_note_actions`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3526 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_wc_admin_note_actions` (`action_id`, `note_id`, `name`, `label`, `query`, `status`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES ( 
/* VALUES START */
1,
1,
'connect',
'Connect',
'?page=wc-addons&section=helper',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
184,
36,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/pre-launch-checklist-the-essentials/?utm_source=inbox&utm_medium=product',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
185,
37,
'visit-the-theme-marketplace',
'Visit the theme marketplace',
'https://woocommerce.com/product-category/themes/?utm_source=inbox&utm_medium=product',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
186,
38,
'affirm-insight-first-product-and-payment',
'Yes',
'',
'actioned',
'Thanks for your feedback',
'',
''
/* VALUES END */
), (
/* VALUES START */
187,
38,
'affirm-insight-first-product-and-payment',
'No',
'',
'actioned',
'Thanks for your feedback',
'',
''
/* VALUES END */
), (
/* VALUES START */
188,
39,
'day-after-first-product',
'Learn more',
'https://woocommerce.com/document/woocommerce-customizer/?utm_source=inbox&utm_medium=product',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
225,
40,
'learn-more',
'Learn more',
'https://woocommerce.com/document/managing-orders/?utm_source=inbox&utm_medium=product',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
226,
41,
'learn-more',
'Learn more',
'https://woocommerce.com/mobile/?utm_medium=product',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
486,
43,
'tracking-opt-in',
'Activate usage tracking',
'',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
487,
44,
'affirm-insight-first-sale',
'Yes',
'',
'actioned',
'Thanks for your feedback',
'',
''
/* VALUES END */
), (
/* VALUES START */
488,
44,
'deny-insight-first-sale',
'No',
'',
'actioned',
'Thanks for your feedback',
'',
''
/* VALUES END */
), (
/* VALUES START */
526,
45,
'jetpack-backup-woocommerce',
'Get backups',
'https://jetpack.com/upgrade/backup-woocommerce/?utm_source=inbox&#038;utm_medium=automattic_referred&#038;utm_campaign=jp_backup_to_woo',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
1379,
35,
'wc-admin-EU-consumer-protection',
'Learn more about these changes',
'https://ec.europa.eu/info/law/law-topic/consumer-protection-law/review-eu-consumer-law_en#guidance',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
1537,
46,
'TikTok q2_2022',
'Promote my products on TikTok',
'https://woocommerce.com/products/tiktok-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=TikTok%20q2_2022',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
1876,
47,
'tiktok-webinar-promo-july2022-button',
'RSVP Now',
'https://gettingstartedwithtiktokforwoocommerce.splashthat.com/',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
1913,
48,
'view-report',
'View report',
'?page=wc-admin&path=/analytics/revenue&period=custom&compare=previous_year&after=2022-07-14&before=2022-07-14',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
2989,
33,
'setup_task_initiative_survey_q2_2022_share_your_input',
'Share your input',
'https://t.maze.co/87390007',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3482,
2,
'enable-navigation',
'Enable in Settings',
'http://13.233.32.209/wp-admin/admin.php?page=wc-settings&tab=advanced&section=features',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3483,
3,
'add-store-details',
'Add store details',
'http://13.233.32.209/wp-admin/admin.php?page=wc-admin&path=/setup-wizard',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3484,
4,
'browse_extensions',
'Browse extensions',
'http://13.233.32.209/wp-admin/admin.php?page=wc-adminadmin.php?page=wc-addons',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3485,
5,
'wayflyer_bnpl_q4_2021',
'Level up with funding',
'https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3486,
6,
'wc_shipping_mobile_app_usps_q4_2021',
'Get WooCommerce Shipping',
'https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3487,
7,
'wc_shipping_mobile_app_q4_2021',
'Get the WooCommerce Mobile App',
'https://woocommerce.com/mobile/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_q4_2021',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3488,
8,
'set-up-concierge',
'Schedule free session',
'https://wordpress.com/me/concierge',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3489,
9,
'learn-more',
'Learn more',
'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3490,
10,
'learn-more-ecomm-unique-shopping-experience',
'Learn more',
'https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3491,
11,
'watch-the-webinar',
'Watch the webinar',
'https://youtu.be/V_2XtCOyZ7o',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3492,
12,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3493,
13,
'optimizing-the-checkout-flow',
'Learn more',
'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3494,
14,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3495,
15,
'qualitative-feedback-from-new-users',
'Share feedback',
'https://automattic.survey.fm/wc-pay-new',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3496,
16,
'share-feedback',
'Share feedback',
'http://automattic.survey.fm/paypal-feedback',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3497,
17,
'get-started',
'Get started',
'https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3498,
18,
'update-wc-subscriptions-3-0-15',
'View latest version',
'http://13.233.32.209/wp-admin/admin.php?page=wc-admin&page=wc-addons&section=helper',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3499,
19,
'update-wc-core-5-4-0',
'How to update WooCommerce',
'https://docs.woocommerce.com/document/how-to-update-woocommerce/',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3500,
22,
'ppxo-pps-install-paypal-payments-1',
'View upgrade guide',
'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3501,
23,
'ppxo-pps-install-paypal-payments-2',
'View upgrade guide',
'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3502,
24,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3503,
24,
'dismiss',
'Dismiss',
'',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3504,
25,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3505,
25,
'dismiss',
'Dismiss',
'',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3506,
26,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3507,
26,
'dismiss',
'Dismiss',
'',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3508,
27,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3509,
27,
'dismiss',
'Dismiss',
'',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3510,
28,
'share-feedback',
'Share feedback',
'https://automattic.survey.fm/store-management',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3511,
29,
'share-navigation-survey-feedback',
'Share feedback',
'https://automattic.survey.fm/feedback-on-woocommerce-navigation',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3512,
30,
'learn-more',
'Learn more',
'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3513,
30,
'woocommerce-core-paypal-march-2022-dismiss',
'Dismiss',
'',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3514,
31,
'learn-more',
'Learn more',
'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3515,
31,
'dismiss',
'Dismiss',
'',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3516,
32,
'pinterest_03_2022_update',
'Update Instructions',
'https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3517,
34,
'store_setup_survey_survey_q2_2022_share_your_thoughts',
'Tell us how it’s going',
'https://automattic.survey.fm/store-setup-survey-2022',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3518,
42,
'wc-admin-wisepad3',
'Grow my business offline',
'https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wisepad3',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3519,
50,
'mercado_pago_q3_2022',
'Free download',
'https://woocommerce.com/products/mercado-pago-checkout/?utm_source=inbox_note&utm_medium=product&utm_campaign=mercado_pago_q3_2022',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3520,
49,
'klarna_q3_2022',
'Grow with Klarna',
'https://woocommerce.com/products/klarna-payments?utm_source=inbox_note&utm_medium=product&utm_campaign=klarna_q3_2022',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3521,
51,
'learn-more',
'Find out more',
'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3522,
51,
'dismiss',
'Dismiss',
'',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3523,
52,
'learn-more',
'Find out more',
'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/',
'unactioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3524,
52,
'dismiss',
'Dismiss',
'',
'actioned',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
3525,
53,
'mobile_app_order_management_q3_2022',
'Get the WooCommerce Mobile App',
'https://woocommerce.com/mobile/?utm_source=inbox_note&utm_medium=product&utm_campaign=mobile_app_order_management_q3_2022',
'actioned',
'',
'',
''
/* VALUES END */
);
/* QUERY END */

