/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_actionscheduler_actions`; */
/* PRE_TABLE_NAME: `1660887906_wp_actionscheduler_actions`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=245 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES ( 
/* VALUES START */
170,
'cartflows_ca_send_report_summary_email',
'complete',
'2022-07-25 15:10:31',
'2022-07-25 15:10:31',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658761831;s:18:\"\0*\0first_timestamp\";i:1655733600;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658761831;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}',
0,
1,
'2022-07-25 15:25:14',
'2022-07-25 15:25:14',
0,
''
/* VALUES END */
), (
/* VALUES START */
171,
'aioseo_cache_prune',
'complete',
'2022-07-19 17:45:56',
'2022-07-19 17:45:56',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658252756;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658252756;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-19 17:48:40',
'2022-07-19 17:48:40',
0,
''
/* VALUES END */
), (
/* VALUES START */
172,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-19 17:45:56',
'2022-07-19 17:45:56',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658252756;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658252756;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-19 17:48:40',
'2022-07-19 17:48:40',
0,
''
/* VALUES END */
), (
/* VALUES START */
173,
'aioseo_cache_prune',
'complete',
'2022-07-20 17:48:40',
'2022-07-20 17:48:40',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658339320;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658339320;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-20 18:01:17',
'2022-07-20 18:01:17',
0,
''
/* VALUES END */
), (
/* VALUES START */
174,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-20 17:48:40',
'2022-07-20 17:48:40',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658339320;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658339320;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-20 18:01:17',
'2022-07-20 18:01:17',
0,
''
/* VALUES END */
), (
/* VALUES START */
175,
'aioseo_cache_prune',
'complete',
'2022-07-21 18:01:17',
'2022-07-21 18:01:17',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658426477;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658426477;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-21 18:05:13',
'2022-07-21 18:05:13',
0,
''
/* VALUES END */
), (
/* VALUES START */
176,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-21 18:01:17',
'2022-07-21 18:01:17',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658426477;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658426477;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-21 18:05:13',
'2022-07-21 18:05:13',
0,
''
/* VALUES END */
), (
/* VALUES START */
177,
'aioseo_cache_prune',
'complete',
'2022-07-22 18:05:13',
'2022-07-22 18:05:13',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658513113;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658513113;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-22 18:15:46',
'2022-07-22 18:15:46',
0,
''
/* VALUES END */
), (
/* VALUES START */
178,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-22 18:05:13',
'2022-07-22 18:05:13',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658513113;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658513113;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-22 18:15:46',
'2022-07-22 18:15:46',
0,
''
/* VALUES END */
), (
/* VALUES START */
179,
'aioseo_cache_prune',
'complete',
'2022-07-23 18:15:46',
'2022-07-23 18:15:46',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658600146;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658600146;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-23 18:17:33',
'2022-07-23 18:17:33',
0,
''
/* VALUES END */
), (
/* VALUES START */
180,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-23 18:15:46',
'2022-07-23 18:15:46',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658600146;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658600146;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-23 18:17:33',
'2022-07-23 18:17:33',
0,
''
/* VALUES END */
), (
/* VALUES START */
181,
'aioseo_cache_prune',
'complete',
'2022-07-24 18:17:33',
'2022-07-24 18:17:33',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658686653;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658686653;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-24 18:20:15',
'2022-07-24 18:20:15',
0,
''
/* VALUES END */
), (
/* VALUES START */
182,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-24 18:17:33',
'2022-07-24 18:17:33',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658686653;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658686653;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-24 18:20:15',
'2022-07-24 18:20:15',
0,
''
/* VALUES END */
), (
/* VALUES START */
183,
'aioseo_cache_prune',
'complete',
'2022-07-25 18:20:15',
'2022-07-25 18:20:15',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658773215;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658773215;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-25 18:25:16',
'2022-07-25 18:25:16',
0,
''
/* VALUES END */
), (
/* VALUES START */
184,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-25 18:20:15',
'2022-07-25 18:20:15',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658773215;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658773215;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-25 18:25:16',
'2022-07-25 18:25:16',
0,
''
/* VALUES END */
), (
/* VALUES START */
185,
'cartflows_ca_send_report_summary_email',
'complete',
'2022-08-01 15:25:14',
'2022-08-01 15:25:14',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659367514;s:18:\"\0*\0first_timestamp\";i:1655733600;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659367514;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}',
0,
1,
'2022-08-01 15:29:05',
'2022-08-01 15:29:05',
0,
''
/* VALUES END */
), (
/* VALUES START */
186,
'aioseo_cache_prune',
'complete',
'2022-07-26 18:25:16',
'2022-07-26 18:25:16',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658859916;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658859916;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-26 18:26:24',
'2022-07-26 18:26:24',
0,
''
/* VALUES END */
), (
/* VALUES START */
187,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-26 18:25:16',
'2022-07-26 18:25:16',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658859916;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658859916;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-26 18:26:24',
'2022-07-26 18:26:24',
0,
''
/* VALUES END */
), (
/* VALUES START */
188,
'wc-admin_import_customers',
'complete',
'2022-07-26 15:30:01',
'2022-07-26 15:30:01',
'[1]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658849401;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658849401;}',
4,
1,
'2022-07-26 15:30:22',
'2022-07-26 15:30:22',
0,
''
/* VALUES END */
), (
/* VALUES START */
189,
'action_scheduler/migration_hook',
'complete',
'2022-07-26 15:39:10',
'2022-07-26 15:39:10',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658849950;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658849950;}',
1,
1,
'2022-07-26 15:39:33',
'2022-07-26 15:39:33',
0,
''
/* VALUES END */
), (
/* VALUES START */
190,
'action_scheduler/migration_hook',
'complete',
'2022-07-26 15:45:48',
'2022-07-26 15:45:48',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658850348;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658850348;}',
1,
1,
'2022-07-26 15:46:11',
'2022-07-26 15:46:11',
0,
''
/* VALUES END */
), (
/* VALUES START */
191,
'action_scheduler/migration_hook',
'complete',
'2022-07-26 15:54:49',
'2022-07-26 15:54:49',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658850889;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658850889;}',
1,
1,
'2022-07-26 15:55:50',
'2022-07-26 15:55:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
192,
'aioseo_cache_prune',
'complete',
'2022-07-27 18:26:24',
'2022-07-27 18:26:24',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658946384;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658946384;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-27 18:27:40',
'2022-07-27 18:27:40',
0,
''
/* VALUES END */
), (
/* VALUES START */
193,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-27 18:26:24',
'2022-07-27 18:26:24',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1658946384;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1658946384;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-27 18:27:40',
'2022-07-27 18:27:40',
0,
''
/* VALUES END */
), (
/* VALUES START */
194,
'wc-admin_import_customers',
'complete',
'2022-07-27 02:23:30',
'2022-07-27 02:23:30',
'[1]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1658888610;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1658888610;}',
4,
1,
'2022-07-27 02:23:33',
'2022-07-27 02:23:33',
0,
''
/* VALUES END */
), (
/* VALUES START */
195,
'aioseo_cache_prune',
'complete',
'2022-07-28 18:27:40',
'2022-07-28 18:27:40',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659032860;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659032860;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-28 18:27:41',
'2022-07-28 18:27:41',
0,
''
/* VALUES END */
), (
/* VALUES START */
196,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-28 18:27:40',
'2022-07-28 18:27:40',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659032860;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659032860;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-28 18:27:41',
'2022-07-28 18:27:41',
0,
''
/* VALUES END */
), (
/* VALUES START */
197,
'aioseo_cache_prune',
'complete',
'2022-07-29 18:27:41',
'2022-07-29 18:27:41',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659119261;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659119261;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-29 18:30:15',
'2022-07-29 18:30:15',
0,
''
/* VALUES END */
), (
/* VALUES START */
198,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-29 18:27:41',
'2022-07-29 18:27:41',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659119261;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659119261;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-29 18:30:15',
'2022-07-29 18:30:15',
0,
''
/* VALUES END */
), (
/* VALUES START */
199,
'aioseo_cache_prune',
'complete',
'2022-07-30 18:30:15',
'2022-07-30 18:30:15',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659205815;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659205815;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-30 18:31:23',
'2022-07-30 18:31:23',
0,
''
/* VALUES END */
), (
/* VALUES START */
200,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-30 18:30:15',
'2022-07-30 18:30:15',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659205815;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659205815;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-30 18:31:23',
'2022-07-30 18:31:23',
0,
''
/* VALUES END */
), (
/* VALUES START */
201,
'aioseo_cache_prune',
'complete',
'2022-07-31 18:31:23',
'2022-07-31 18:31:23',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659292283;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659292283;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-07-31 18:32:30',
'2022-07-31 18:32:30',
0,
''
/* VALUES END */
), (
/* VALUES START */
202,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-07-31 18:31:23',
'2022-07-31 18:31:23',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659292283;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659292283;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-07-31 18:32:30',
'2022-07-31 18:32:30',
0,
''
/* VALUES END */
), (
/* VALUES START */
203,
'aioseo_cache_prune',
'complete',
'2022-08-01 18:32:30',
'2022-08-01 18:32:30',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659378750;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659378750;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-01 18:41:58',
'2022-08-01 18:41:58',
0,
''
/* VALUES END */
), (
/* VALUES START */
204,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-01 18:32:30',
'2022-08-01 18:32:30',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659378750;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659378750;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-01 18:41:59',
'2022-08-01 18:41:59',
0,
''
/* VALUES END */
), (
/* VALUES START */
205,
'cartflows_ca_send_report_summary_email',
'complete',
'2022-08-08 15:29:05',
'2022-08-08 15:29:05',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659972545;s:18:\"\0*\0first_timestamp\";i:1655733600;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659972545;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}',
0,
1,
'2022-08-08 15:31:52',
'2022-08-08 15:31:52',
0,
''
/* VALUES END */
), (
/* VALUES START */
206,
'aioseo_cache_prune',
'complete',
'2022-08-02 18:41:58',
'2022-08-02 18:41:58',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659465718;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659465718;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-02 18:43:50',
'2022-08-02 18:43:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
207,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-02 18:41:59',
'2022-08-02 18:41:59',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659465719;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659465719;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-02 18:43:50',
'2022-08-02 18:43:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
208,
'aioseo_cache_prune',
'complete',
'2022-08-03 18:43:50',
'2022-08-03 18:43:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659552230;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659552230;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-03 18:46:36',
'2022-08-03 18:46:36',
0,
''
/* VALUES END */
), (
/* VALUES START */
209,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-03 18:43:50',
'2022-08-03 18:43:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659552230;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659552230;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-03 18:46:36',
'2022-08-03 18:46:36',
0,
''
/* VALUES END */
), (
/* VALUES START */
210,
'aioseo_cache_prune',
'complete',
'2022-08-04 18:46:36',
'2022-08-04 18:46:36',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659638796;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659638796;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-04 18:48:24',
'2022-08-04 18:48:24',
0,
''
/* VALUES END */
), (
/* VALUES START */
211,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-04 18:46:36',
'2022-08-04 18:46:36',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659638796;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659638796;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-04 18:48:24',
'2022-08-04 18:48:24',
0,
''
/* VALUES END */
), (
/* VALUES START */
212,
'aioseo_cache_prune',
'complete',
'2022-08-05 18:48:24',
'2022-08-05 18:48:24',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659725304;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659725304;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-05 18:50:17',
'2022-08-05 18:50:17',
0,
''
/* VALUES END */
), (
/* VALUES START */
213,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-05 18:48:24',
'2022-08-05 18:48:24',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659725304;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659725304;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-05 18:50:17',
'2022-08-05 18:50:17',
0,
''
/* VALUES END */
), (
/* VALUES START */
214,
'aioseo_cache_prune',
'complete',
'2022-08-06 18:50:17',
'2022-08-06 18:50:17',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659811817;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659811817;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-06 18:53:29',
'2022-08-06 18:53:29',
0,
''
/* VALUES END */
), (
/* VALUES START */
215,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-06 18:50:17',
'2022-08-06 18:50:17',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659811817;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659811817;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-06 18:53:29',
'2022-08-06 18:53:29',
0,
''
/* VALUES END */
), (
/* VALUES START */
216,
'aioseo_cache_prune',
'complete',
'2022-08-07 18:53:29',
'2022-08-07 18:53:29',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659898409;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659898409;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-07 19:11:50',
'2022-08-07 19:11:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
217,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-07 18:53:29',
'2022-08-07 18:53:29',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659898409;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659898409;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-07 19:11:50',
'2022-08-07 19:11:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
218,
'aioseo_cache_prune',
'complete',
'2022-08-08 19:11:50',
'2022-08-08 19:11:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659985910;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659985910;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-08 19:12:01',
'2022-08-08 19:12:01',
0,
''
/* VALUES END */
), (
/* VALUES START */
219,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-08 19:11:50',
'2022-08-08 19:11:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1659985910;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1659985910;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-08 19:12:01',
'2022-08-08 19:12:01',
0,
''
/* VALUES END */
), (
/* VALUES START */
220,
'cartflows_ca_send_report_summary_email',
'complete',
'2022-08-15 15:31:52',
'2022-08-15 15:31:52',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660577512;s:18:\"\0*\0first_timestamp\";i:1655733600;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660577512;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}',
0,
1,
'2022-08-15 15:32:21',
'2022-08-15 15:32:21',
0,
''
/* VALUES END */
), (
/* VALUES START */
221,
'aioseo_cache_prune',
'complete',
'2022-08-09 19:12:01',
'2022-08-09 19:12:01',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660072321;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660072321;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-09 19:16:50',
'2022-08-09 19:16:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
222,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-09 19:12:01',
'2022-08-09 19:12:01',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660072321;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660072321;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-09 19:16:50',
'2022-08-09 19:16:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
223,
'aioseo_cache_prune',
'complete',
'2022-08-10 19:16:50',
'2022-08-10 19:16:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660159010;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660159010;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-10 19:18:50',
'2022-08-10 19:18:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
224,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-10 19:16:50',
'2022-08-10 19:16:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660159010;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660159010;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-10 19:18:50',
'2022-08-10 19:18:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
225,
'aioseo_cache_prune',
'complete',
'2022-08-11 19:18:50',
'2022-08-11 19:18:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660245530;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660245530;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-11 19:19:02',
'2022-08-11 19:19:02',
0,
''
/* VALUES END */
), (
/* VALUES START */
226,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-11 19:18:50',
'2022-08-11 19:18:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660245530;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660245530;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-11 19:19:02',
'2022-08-11 19:19:02',
0,
''
/* VALUES END */
), (
/* VALUES START */
227,
'aioseo_cache_prune',
'complete',
'2022-08-12 19:19:02',
'2022-08-12 19:19:02',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660331942;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660331942;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-12 19:20:09',
'2022-08-12 19:20:09',
0,
''
/* VALUES END */
), (
/* VALUES START */
228,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-12 19:19:02',
'2022-08-12 19:19:02',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660331942;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660331942;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-12 19:20:09',
'2022-08-12 19:20:09',
0,
''
/* VALUES END */
), (
/* VALUES START */
229,
'aioseo_cache_prune',
'complete',
'2022-08-13 19:20:09',
'2022-08-13 19:20:09',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660418409;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660418409;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-13 19:23:50',
'2022-08-13 19:23:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
230,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-13 19:20:09',
'2022-08-13 19:20:09',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660418409;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660418409;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-13 19:23:50',
'2022-08-13 19:23:50',
0,
''
/* VALUES END */
), (
/* VALUES START */
231,
'aioseo_cache_prune',
'complete',
'2022-08-14 19:23:50',
'2022-08-14 19:23:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660505030;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660505030;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-14 19:25:42',
'2022-08-14 19:25:42',
0,
''
/* VALUES END */
), (
/* VALUES START */
232,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-14 19:23:50',
'2022-08-14 19:23:50',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660505030;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660505030;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-14 19:25:42',
'2022-08-14 19:25:42',
0,
''
/* VALUES END */
), (
/* VALUES START */
233,
'aioseo_cache_prune',
'complete',
'2022-08-15 19:25:42',
'2022-08-15 19:25:42',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660591542;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660591542;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-15 19:26:17',
'2022-08-15 19:26:17',
0,
''
/* VALUES END */
), (
/* VALUES START */
234,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-15 19:25:42',
'2022-08-15 19:25:42',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660591542;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660591542;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-15 19:26:17',
'2022-08-15 19:26:17',
0,
''
/* VALUES END */
), (
/* VALUES START */
235,
'cartflows_ca_send_report_summary_email',
'pending',
'2022-08-22 15:32:21',
'2022-08-22 15:32:21',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1661182341;s:18:\"\0*\0first_timestamp\";i:1655733600;s:13:\"\0*\0recurrence\";i:604800;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1661182341;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:604800;}',
0,
0,
'0000-00-00 00:00:00',
'0000-00-00 00:00:00',
0,
''
/* VALUES END */
), (
/* VALUES START */
236,
'aioseo_cache_prune',
'complete',
'2022-08-16 19:26:17',
'2022-08-16 19:26:17',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660677977;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660677977;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-16 19:27:16',
'2022-08-16 19:27:16',
0,
''
/* VALUES END */
), (
/* VALUES START */
237,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-16 19:26:17',
'2022-08-16 19:26:17',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660677977;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660677977;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-16 19:27:16',
'2022-08-16 19:27:16',
0,
''
/* VALUES END */
), (
/* VALUES START */
238,
'aioseo_cache_prune',
'complete',
'2022-08-17 19:27:16',
'2022-08-17 19:27:16',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660764436;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660764436;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-17 19:31:19',
'2022-08-17 19:31:19',
0,
''
/* VALUES END */
), (
/* VALUES START */
239,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-17 19:27:16',
'2022-08-17 19:27:16',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660764436;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660764436;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-17 19:31:19',
'2022-08-17 19:31:19',
0,
''
/* VALUES END */
), (
/* VALUES START */
240,
'aioseo_cache_prune',
'complete',
'2022-08-18 19:31:19',
'2022-08-18 19:31:19',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660851079;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660851079;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
1,
'2022-08-18 19:33:24',
'2022-08-18 19:33:24',
0,
''
/* VALUES END */
), (
/* VALUES START */
241,
'woocommerce_cleanup_draft_orders',
'complete',
'2022-08-18 19:31:19',
'2022-08-18 19:31:19',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660851079;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660851079;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
1,
'2022-08-18 19:33:24',
'2022-08-18 19:33:24',
0,
''
/* VALUES END */
), (
/* VALUES START */
242,
'aioseo_cache_prune',
'pending',
'2022-08-19 19:33:24',
'2022-08-19 19:33:24',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660937604;s:18:\"\0*\0first_timestamp\";i:1656430417;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660937604;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
7,
0,
'0000-00-00 00:00:00',
'0000-00-00 00:00:00',
0,
''
/* VALUES END */
), (
/* VALUES START */
243,
'woocommerce_cleanup_draft_orders',
'pending',
'2022-08-19 19:33:24',
'2022-08-19 19:33:24',
'[]',
'O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1660937604;s:18:\"\0*\0first_timestamp\";i:1655281901;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1660937604;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',
0,
0,
'0000-00-00 00:00:00',
'0000-00-00 00:00:00',
0,
''
/* VALUES END */
), (
/* VALUES START */
244,
'wc-admin_import_customers',
'pending',
'2022-08-19 05:44:35',
'2022-08-19 05:44:35',
'[1]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1660887875;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1660887875;}',
4,
0,
'0000-00-00 00:00:00',
'0000-00-00 00:00:00',
0,
''
/* VALUES END */
);
/* QUERY END */

