/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_dokan_announcement`; */
/* PRE_TABLE_NAME: `1660887906_wp_dokan_announcement`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_dokan_announcement` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(11) NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

