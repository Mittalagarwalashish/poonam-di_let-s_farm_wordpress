/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_product_meta_lookup`; */
/* PRE_TABLE_NAME: `1660887906_wp_wc_product_meta_lookup`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_wc_product_meta_lookup` (`product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES ( 
/* VALUES START */
3671,
'',
0,
0,
25,
25,
1,
0,
'instock',
0,
0,
1,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3672,
'',
0,
0,
35,
35,
0,
0,
'instock',
0,
0,
0,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3673,
'',
0,
0,
25,
25,
1,
0,
'instock',
0,
0,
0,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3674,
'',
0,
0,
34,
34,
0,
0,
'instock',
0,
0,
1,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3675,
'',
0,
0,
35,
35,
0,
0,
'instock',
0,
0,
19,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3676,
'',
0,
0,
25,
25,
1,
0,
'instock',
0,
0,
12003,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3677,
'',
0,
0,
34,
34,
0,
0,
'instock',
0,
0,
1106,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3678,
'',
0,
0,
34,
34,
0,
0,
'instock',
0,
0,
2,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3679,
'',
0,
0,
15,
15,
0,
0,
'instock',
0,
0,
12,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3680,
'',
0,
0,
18,
18,
0,
0,
'instock',
0,
0,
32,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3681,
'',
0,
0,
15,
15,
0,
0,
'instock',
0,
0,
3,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3682,
'',
0,
0,
19,
19,
0,
0,
'instock',
0,
0,
4,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3979,
'',
0,
0,
60,
60,
1,
198,
'instock',
0,
0,
10,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
3995,
'',
1,
0,
0,
0,
0,
0,
'instock',
0,
0,
0,
'none',
''
/* VALUES END */
), (
/* VALUES START */
4000,
'',
0,
0,
45,
45,
1,
'',
'instock',
0,
0,
0,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
4021,
'',
0,
0,
20,
20,
0,
'',
'instock',
0,
0,
0,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
4023,
'',
0,
0,
50,
50,
0,
'',
'instock',
0,
0,
0,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
4025,
'',
0,
0,
30,
30,
0,
'',
'instock',
0,
0,
0,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
4027,
'',
0,
0,
80,
80,
0,
'',
'instock',
0,
0,
4,
'taxable',
''
/* VALUES END */
), (
/* VALUES START */
4029,
'',
0,
0,
120,
120,
0,
'',
'instock',
0,
0,
2,
'taxable',
''
/* VALUES END */
);
/* QUERY END */

