/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_actionscheduler_groups`; */
/* PRE_TABLE_NAME: `1660887906_wp_actionscheduler_groups`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_actionscheduler_groups` (`group_id`, `slug`) VALUES ( 
/* VALUES START */
1,
'action-scheduler-migration'
/* VALUES END */
), (
/* VALUES START */
2,
'wc_update_product_lookup_tables'
/* VALUES END */
), (
/* VALUES START */
3,
'woocommerce-db-updates'
/* VALUES END */
), (
/* VALUES START */
4,
'wc-admin-data'
/* VALUES END */
), (
/* VALUES START */
5,
'woocommerce-remote-inbox-engine'
/* VALUES END */
), (
/* VALUES START */
6,
'wc_update_product_default_cat'
/* VALUES END */
), (
/* VALUES START */
7,
'aioseo'
/* VALUES END */
);
/* QUERY END */

