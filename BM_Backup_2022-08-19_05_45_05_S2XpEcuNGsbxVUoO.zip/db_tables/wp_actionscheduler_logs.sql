/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_actionscheduler_logs`; */
/* PRE_TABLE_NAME: `1660887906_wp_actionscheduler_logs`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=706 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES ( 
/* VALUES START */
485,
170,
'action created',
'2022-07-18 15:10:31',
'2022-07-18 15:10:31'
/* VALUES END */
), (
/* VALUES START */
488,
171,
'action created',
'2022-07-18 17:45:56',
'2022-07-18 17:45:56'
/* VALUES END */
), (
/* VALUES START */
491,
172,
'action created',
'2022-07-18 17:45:56',
'2022-07-18 17:45:56'
/* VALUES END */
), (
/* VALUES START */
492,
171,
'action started via WP Cron',
'2022-07-19 17:48:40',
'2022-07-19 17:48:40'
/* VALUES END */
), (
/* VALUES START */
493,
171,
'action complete via WP Cron',
'2022-07-19 17:48:40',
'2022-07-19 17:48:40'
/* VALUES END */
), (
/* VALUES START */
494,
173,
'action created',
'2022-07-19 17:48:40',
'2022-07-19 17:48:40'
/* VALUES END */
), (
/* VALUES START */
495,
172,
'action started via WP Cron',
'2022-07-19 17:48:40',
'2022-07-19 17:48:40'
/* VALUES END */
), (
/* VALUES START */
496,
172,
'action complete via WP Cron',
'2022-07-19 17:48:40',
'2022-07-19 17:48:40'
/* VALUES END */
), (
/* VALUES START */
497,
174,
'action created',
'2022-07-19 17:48:40',
'2022-07-19 17:48:40'
/* VALUES END */
), (
/* VALUES START */
498,
173,
'action started via WP Cron',
'2022-07-20 18:01:17',
'2022-07-20 18:01:17'
/* VALUES END */
), (
/* VALUES START */
499,
173,
'action complete via WP Cron',
'2022-07-20 18:01:17',
'2022-07-20 18:01:17'
/* VALUES END */
), (
/* VALUES START */
500,
175,
'action created',
'2022-07-20 18:01:17',
'2022-07-20 18:01:17'
/* VALUES END */
), (
/* VALUES START */
501,
174,
'action started via WP Cron',
'2022-07-20 18:01:17',
'2022-07-20 18:01:17'
/* VALUES END */
), (
/* VALUES START */
502,
174,
'action complete via WP Cron',
'2022-07-20 18:01:17',
'2022-07-20 18:01:17'
/* VALUES END */
), (
/* VALUES START */
503,
176,
'action created',
'2022-07-20 18:01:17',
'2022-07-20 18:01:17'
/* VALUES END */
), (
/* VALUES START */
504,
175,
'action started via WP Cron',
'2022-07-21 18:05:13',
'2022-07-21 18:05:13'
/* VALUES END */
), (
/* VALUES START */
505,
175,
'action complete via WP Cron',
'2022-07-21 18:05:13',
'2022-07-21 18:05:13'
/* VALUES END */
), (
/* VALUES START */
506,
177,
'action created',
'2022-07-21 18:05:13',
'2022-07-21 18:05:13'
/* VALUES END */
), (
/* VALUES START */
507,
176,
'action started via WP Cron',
'2022-07-21 18:05:13',
'2022-07-21 18:05:13'
/* VALUES END */
), (
/* VALUES START */
508,
176,
'action complete via WP Cron',
'2022-07-21 18:05:13',
'2022-07-21 18:05:13'
/* VALUES END */
), (
/* VALUES START */
509,
178,
'action created',
'2022-07-21 18:05:13',
'2022-07-21 18:05:13'
/* VALUES END */
), (
/* VALUES START */
510,
177,
'action started via WP Cron',
'2022-07-22 18:15:46',
'2022-07-22 18:15:46'
/* VALUES END */
), (
/* VALUES START */
511,
177,
'action complete via WP Cron',
'2022-07-22 18:15:46',
'2022-07-22 18:15:46'
/* VALUES END */
), (
/* VALUES START */
512,
179,
'action created',
'2022-07-22 18:15:46',
'2022-07-22 18:15:46'
/* VALUES END */
), (
/* VALUES START */
513,
178,
'action started via WP Cron',
'2022-07-22 18:15:46',
'2022-07-22 18:15:46'
/* VALUES END */
), (
/* VALUES START */
514,
178,
'action complete via WP Cron',
'2022-07-22 18:15:46',
'2022-07-22 18:15:46'
/* VALUES END */
), (
/* VALUES START */
515,
180,
'action created',
'2022-07-22 18:15:46',
'2022-07-22 18:15:46'
/* VALUES END */
), (
/* VALUES START */
516,
179,
'action started via WP Cron',
'2022-07-23 18:17:33',
'2022-07-23 18:17:33'
/* VALUES END */
), (
/* VALUES START */
517,
179,
'action complete via WP Cron',
'2022-07-23 18:17:33',
'2022-07-23 18:17:33'
/* VALUES END */
), (
/* VALUES START */
518,
181,
'action created',
'2022-07-23 18:17:33',
'2022-07-23 18:17:33'
/* VALUES END */
), (
/* VALUES START */
519,
180,
'action started via WP Cron',
'2022-07-23 18:17:33',
'2022-07-23 18:17:33'
/* VALUES END */
), (
/* VALUES START */
520,
180,
'action complete via WP Cron',
'2022-07-23 18:17:33',
'2022-07-23 18:17:33'
/* VALUES END */
), (
/* VALUES START */
521,
182,
'action created',
'2022-07-23 18:17:33',
'2022-07-23 18:17:33'
/* VALUES END */
), (
/* VALUES START */
522,
181,
'action started via WP Cron',
'2022-07-24 18:20:15',
'2022-07-24 18:20:15'
/* VALUES END */
), (
/* VALUES START */
523,
181,
'action complete via WP Cron',
'2022-07-24 18:20:15',
'2022-07-24 18:20:15'
/* VALUES END */
), (
/* VALUES START */
524,
183,
'action created',
'2022-07-24 18:20:15',
'2022-07-24 18:20:15'
/* VALUES END */
), (
/* VALUES START */
525,
182,
'action started via WP Cron',
'2022-07-24 18:20:15',
'2022-07-24 18:20:15'
/* VALUES END */
), (
/* VALUES START */
526,
182,
'action complete via WP Cron',
'2022-07-24 18:20:15',
'2022-07-24 18:20:15'
/* VALUES END */
), (
/* VALUES START */
527,
184,
'action created',
'2022-07-24 18:20:15',
'2022-07-24 18:20:15'
/* VALUES END */
), (
/* VALUES START */
528,
170,
'action started via WP Cron',
'2022-07-25 15:25:14',
'2022-07-25 15:25:14'
/* VALUES END */
), (
/* VALUES START */
529,
170,
'action complete via WP Cron',
'2022-07-25 15:25:14',
'2022-07-25 15:25:14'
/* VALUES END */
), (
/* VALUES START */
530,
185,
'action created',
'2022-07-25 15:25:14',
'2022-07-25 15:25:14'
/* VALUES END */
), (
/* VALUES START */
531,
183,
'action started via WP Cron',
'2022-07-25 18:25:16',
'2022-07-25 18:25:16'
/* VALUES END */
), (
/* VALUES START */
532,
183,
'action complete via WP Cron',
'2022-07-25 18:25:16',
'2022-07-25 18:25:16'
/* VALUES END */
), (
/* VALUES START */
533,
186,
'action created',
'2022-07-25 18:25:16',
'2022-07-25 18:25:16'
/* VALUES END */
), (
/* VALUES START */
534,
184,
'action started via WP Cron',
'2022-07-25 18:25:16',
'2022-07-25 18:25:16'
/* VALUES END */
), (
/* VALUES START */
535,
184,
'action complete via WP Cron',
'2022-07-25 18:25:16',
'2022-07-25 18:25:16'
/* VALUES END */
), (
/* VALUES START */
536,
187,
'action created',
'2022-07-25 18:25:16',
'2022-07-25 18:25:16'
/* VALUES END */
), (
/* VALUES START */
537,
188,
'action created',
'2022-07-26 15:29:56',
'2022-07-26 15:29:56'
/* VALUES END */
), (
/* VALUES START */
538,
188,
'action started via Async Request',
'2022-07-26 15:30:22',
'2022-07-26 15:30:22'
/* VALUES END */
), (
/* VALUES START */
539,
188,
'action complete via Async Request',
'2022-07-26 15:30:22',
'2022-07-26 15:30:22'
/* VALUES END */
), (
/* VALUES START */
540,
189,
'action created',
'2022-07-26 15:38:10',
'2022-07-26 15:38:10'
/* VALUES END */
), (
/* VALUES START */
541,
189,
'action started via WP Cron',
'2022-07-26 15:39:33',
'2022-07-26 15:39:33'
/* VALUES END */
), (
/* VALUES START */
542,
189,
'action complete via WP Cron',
'2022-07-26 15:39:33',
'2022-07-26 15:39:33'
/* VALUES END */
), (
/* VALUES START */
543,
190,
'action created',
'2022-07-26 15:44:48',
'2022-07-26 15:44:48'
/* VALUES END */
), (
/* VALUES START */
544,
190,
'action started via WP Cron',
'2022-07-26 15:46:11',
'2022-07-26 15:46:11'
/* VALUES END */
), (
/* VALUES START */
545,
190,
'action complete via WP Cron',
'2022-07-26 15:46:11',
'2022-07-26 15:46:11'
/* VALUES END */
), (
/* VALUES START */
546,
191,
'action created',
'2022-07-26 15:53:49',
'2022-07-26 15:53:49'
/* VALUES END */
), (
/* VALUES START */
547,
191,
'action started via WP Cron',
'2022-07-26 15:55:50',
'2022-07-26 15:55:50'
/* VALUES END */
), (
/* VALUES START */
548,
191,
'action complete via WP Cron',
'2022-07-26 15:55:50',
'2022-07-26 15:55:50'
/* VALUES END */
), (
/* VALUES START */
549,
186,
'action started via WP Cron',
'2022-07-26 18:26:24',
'2022-07-26 18:26:24'
/* VALUES END */
), (
/* VALUES START */
550,
186,
'action complete via WP Cron',
'2022-07-26 18:26:24',
'2022-07-26 18:26:24'
/* VALUES END */
), (
/* VALUES START */
551,
192,
'action created',
'2022-07-26 18:26:24',
'2022-07-26 18:26:24'
/* VALUES END */
), (
/* VALUES START */
552,
187,
'action started via WP Cron',
'2022-07-26 18:26:24',
'2022-07-26 18:26:24'
/* VALUES END */
), (
/* VALUES START */
553,
187,
'action complete via WP Cron',
'2022-07-26 18:26:24',
'2022-07-26 18:26:24'
/* VALUES END */
), (
/* VALUES START */
554,
193,
'action created',
'2022-07-26 18:26:24',
'2022-07-26 18:26:24'
/* VALUES END */
), (
/* VALUES START */
555,
194,
'action created',
'2022-07-27 02:23:25',
'2022-07-27 02:23:25'
/* VALUES END */
), (
/* VALUES START */
556,
194,
'action started via WP Cron',
'2022-07-27 02:23:33',
'2022-07-27 02:23:33'
/* VALUES END */
), (
/* VALUES START */
557,
194,
'action complete via WP Cron',
'2022-07-27 02:23:33',
'2022-07-27 02:23:33'
/* VALUES END */
), (
/* VALUES START */
558,
192,
'action started via WP Cron',
'2022-07-27 18:27:40',
'2022-07-27 18:27:40'
/* VALUES END */
), (
/* VALUES START */
559,
192,
'action complete via WP Cron',
'2022-07-27 18:27:40',
'2022-07-27 18:27:40'
/* VALUES END */
), (
/* VALUES START */
560,
195,
'action created',
'2022-07-27 18:27:40',
'2022-07-27 18:27:40'
/* VALUES END */
), (
/* VALUES START */
561,
193,
'action started via WP Cron',
'2022-07-27 18:27:40',
'2022-07-27 18:27:40'
/* VALUES END */
), (
/* VALUES START */
562,
193,
'action complete via WP Cron',
'2022-07-27 18:27:40',
'2022-07-27 18:27:40'
/* VALUES END */
), (
/* VALUES START */
563,
196,
'action created',
'2022-07-27 18:27:40',
'2022-07-27 18:27:40'
/* VALUES END */
), (
/* VALUES START */
564,
195,
'action started via WP Cron',
'2022-07-28 18:27:41',
'2022-07-28 18:27:41'
/* VALUES END */
), (
/* VALUES START */
565,
195,
'action complete via WP Cron',
'2022-07-28 18:27:41',
'2022-07-28 18:27:41'
/* VALUES END */
), (
/* VALUES START */
566,
197,
'action created',
'2022-07-28 18:27:41',
'2022-07-28 18:27:41'
/* VALUES END */
), (
/* VALUES START */
567,
196,
'action started via WP Cron',
'2022-07-28 18:27:41',
'2022-07-28 18:27:41'
/* VALUES END */
), (
/* VALUES START */
568,
196,
'action complete via WP Cron',
'2022-07-28 18:27:41',
'2022-07-28 18:27:41'
/* VALUES END */
), (
/* VALUES START */
569,
198,
'action created',
'2022-07-28 18:27:41',
'2022-07-28 18:27:41'
/* VALUES END */
), (
/* VALUES START */
570,
197,
'action started via WP Cron',
'2022-07-29 18:30:15',
'2022-07-29 18:30:15'
/* VALUES END */
), (
/* VALUES START */
571,
197,
'action complete via WP Cron',
'2022-07-29 18:30:15',
'2022-07-29 18:30:15'
/* VALUES END */
), (
/* VALUES START */
572,
199,
'action created',
'2022-07-29 18:30:15',
'2022-07-29 18:30:15'
/* VALUES END */
), (
/* VALUES START */
573,
198,
'action started via WP Cron',
'2022-07-29 18:30:15',
'2022-07-29 18:30:15'
/* VALUES END */
), (
/* VALUES START */
574,
198,
'action complete via WP Cron',
'2022-07-29 18:30:15',
'2022-07-29 18:30:15'
/* VALUES END */
), (
/* VALUES START */
575,
200,
'action created',
'2022-07-29 18:30:15',
'2022-07-29 18:30:15'
/* VALUES END */
), (
/* VALUES START */
576,
199,
'action started via WP Cron',
'2022-07-30 18:31:23',
'2022-07-30 18:31:23'
/* VALUES END */
), (
/* VALUES START */
577,
199,
'action complete via WP Cron',
'2022-07-30 18:31:23',
'2022-07-30 18:31:23'
/* VALUES END */
), (
/* VALUES START */
578,
201,
'action created',
'2022-07-30 18:31:23',
'2022-07-30 18:31:23'
/* VALUES END */
), (
/* VALUES START */
579,
200,
'action started via WP Cron',
'2022-07-30 18:31:23',
'2022-07-30 18:31:23'
/* VALUES END */
), (
/* VALUES START */
580,
200,
'action complete via WP Cron',
'2022-07-30 18:31:23',
'2022-07-30 18:31:23'
/* VALUES END */
), (
/* VALUES START */
581,
202,
'action created',
'2022-07-30 18:31:23',
'2022-07-30 18:31:23'
/* VALUES END */
), (
/* VALUES START */
582,
201,
'action started via WP Cron',
'2022-07-31 18:32:30',
'2022-07-31 18:32:30'
/* VALUES END */
), (
/* VALUES START */
583,
201,
'action complete via WP Cron',
'2022-07-31 18:32:30',
'2022-07-31 18:32:30'
/* VALUES END */
), (
/* VALUES START */
584,
203,
'action created',
'2022-07-31 18:32:30',
'2022-07-31 18:32:30'
/* VALUES END */
), (
/* VALUES START */
585,
202,
'action started via WP Cron',
'2022-07-31 18:32:30',
'2022-07-31 18:32:30'
/* VALUES END */
), (
/* VALUES START */
586,
202,
'action complete via WP Cron',
'2022-07-31 18:32:30',
'2022-07-31 18:32:30'
/* VALUES END */
), (
/* VALUES START */
587,
204,
'action created',
'2022-07-31 18:32:30',
'2022-07-31 18:32:30'
/* VALUES END */
), (
/* VALUES START */
588,
185,
'action started via WP Cron',
'2022-08-01 15:29:05',
'2022-08-01 15:29:05'
/* VALUES END */
), (
/* VALUES START */
589,
185,
'action complete via WP Cron',
'2022-08-01 15:29:05',
'2022-08-01 15:29:05'
/* VALUES END */
), (
/* VALUES START */
590,
205,
'action created',
'2022-08-01 15:29:05',
'2022-08-01 15:29:05'
/* VALUES END */
), (
/* VALUES START */
591,
203,
'action started via WP Cron',
'2022-08-01 18:41:58',
'2022-08-01 18:41:58'
/* VALUES END */
), (
/* VALUES START */
592,
203,
'action complete via WP Cron',
'2022-08-01 18:41:58',
'2022-08-01 18:41:58'
/* VALUES END */
), (
/* VALUES START */
593,
206,
'action created',
'2022-08-01 18:41:58',
'2022-08-01 18:41:58'
/* VALUES END */
), (
/* VALUES START */
594,
204,
'action started via WP Cron',
'2022-08-01 18:41:58',
'2022-08-01 18:41:58'
/* VALUES END */
), (
/* VALUES START */
595,
204,
'action complete via WP Cron',
'2022-08-01 18:41:59',
'2022-08-01 18:41:59'
/* VALUES END */
), (
/* VALUES START */
596,
207,
'action created',
'2022-08-01 18:41:59',
'2022-08-01 18:41:59'
/* VALUES END */
), (
/* VALUES START */
597,
206,
'action started via WP Cron',
'2022-08-02 18:43:50',
'2022-08-02 18:43:50'
/* VALUES END */
), (
/* VALUES START */
598,
206,
'action complete via WP Cron',
'2022-08-02 18:43:50',
'2022-08-02 18:43:50'
/* VALUES END */
), (
/* VALUES START */
599,
208,
'action created',
'2022-08-02 18:43:50',
'2022-08-02 18:43:50'
/* VALUES END */
), (
/* VALUES START */
600,
207,
'action started via WP Cron',
'2022-08-02 18:43:50',
'2022-08-02 18:43:50'
/* VALUES END */
), (
/* VALUES START */
601,
207,
'action complete via WP Cron',
'2022-08-02 18:43:50',
'2022-08-02 18:43:50'
/* VALUES END */
), (
/* VALUES START */
602,
209,
'action created',
'2022-08-02 18:43:50',
'2022-08-02 18:43:50'
/* VALUES END */
), (
/* VALUES START */
603,
208,
'action started via WP Cron',
'2022-08-03 18:46:36',
'2022-08-03 18:46:36'
/* VALUES END */
), (
/* VALUES START */
604,
208,
'action complete via WP Cron',
'2022-08-03 18:46:36',
'2022-08-03 18:46:36'
/* VALUES END */
), (
/* VALUES START */
605,
210,
'action created',
'2022-08-03 18:46:36',
'2022-08-03 18:46:36'
/* VALUES END */
), (
/* VALUES START */
606,
209,
'action started via WP Cron',
'2022-08-03 18:46:36',
'2022-08-03 18:46:36'
/* VALUES END */
), (
/* VALUES START */
607,
209,
'action complete via WP Cron',
'2022-08-03 18:46:36',
'2022-08-03 18:46:36'
/* VALUES END */
), (
/* VALUES START */
608,
211,
'action created',
'2022-08-03 18:46:36',
'2022-08-03 18:46:36'
/* VALUES END */
), (
/* VALUES START */
609,
210,
'action started via WP Cron',
'2022-08-04 18:48:24',
'2022-08-04 18:48:24'
/* VALUES END */
), (
/* VALUES START */
610,
210,
'action complete via WP Cron',
'2022-08-04 18:48:24',
'2022-08-04 18:48:24'
/* VALUES END */
), (
/* VALUES START */
611,
212,
'action created',
'2022-08-04 18:48:24',
'2022-08-04 18:48:24'
/* VALUES END */
), (
/* VALUES START */
612,
211,
'action started via WP Cron',
'2022-08-04 18:48:24',
'2022-08-04 18:48:24'
/* VALUES END */
), (
/* VALUES START */
613,
211,
'action complete via WP Cron',
'2022-08-04 18:48:24',
'2022-08-04 18:48:24'
/* VALUES END */
), (
/* VALUES START */
614,
213,
'action created',
'2022-08-04 18:48:24',
'2022-08-04 18:48:24'
/* VALUES END */
), (
/* VALUES START */
615,
212,
'action started via WP Cron',
'2022-08-05 18:50:17',
'2022-08-05 18:50:17'
/* VALUES END */
), (
/* VALUES START */
616,
212,
'action complete via WP Cron',
'2022-08-05 18:50:17',
'2022-08-05 18:50:17'
/* VALUES END */
), (
/* VALUES START */
617,
214,
'action created',
'2022-08-05 18:50:17',
'2022-08-05 18:50:17'
/* VALUES END */
), (
/* VALUES START */
618,
213,
'action started via WP Cron',
'2022-08-05 18:50:17',
'2022-08-05 18:50:17'
/* VALUES END */
), (
/* VALUES START */
619,
213,
'action complete via WP Cron',
'2022-08-05 18:50:17',
'2022-08-05 18:50:17'
/* VALUES END */
), (
/* VALUES START */
620,
215,
'action created',
'2022-08-05 18:50:17',
'2022-08-05 18:50:17'
/* VALUES END */
), (
/* VALUES START */
621,
214,
'action started via WP Cron',
'2022-08-06 18:53:29',
'2022-08-06 18:53:29'
/* VALUES END */
), (
/* VALUES START */
622,
214,
'action complete via WP Cron',
'2022-08-06 18:53:29',
'2022-08-06 18:53:29'
/* VALUES END */
), (
/* VALUES START */
623,
216,
'action created',
'2022-08-06 18:53:29',
'2022-08-06 18:53:29'
/* VALUES END */
), (
/* VALUES START */
624,
215,
'action started via WP Cron',
'2022-08-06 18:53:29',
'2022-08-06 18:53:29'
/* VALUES END */
), (
/* VALUES START */
625,
215,
'action complete via WP Cron',
'2022-08-06 18:53:29',
'2022-08-06 18:53:29'
/* VALUES END */
), (
/* VALUES START */
626,
217,
'action created',
'2022-08-06 18:53:29',
'2022-08-06 18:53:29'
/* VALUES END */
), (
/* VALUES START */
627,
216,
'action started via WP Cron',
'2022-08-07 19:11:50',
'2022-08-07 19:11:50'
/* VALUES END */
), (
/* VALUES START */
628,
216,
'action complete via WP Cron',
'2022-08-07 19:11:50',
'2022-08-07 19:11:50'
/* VALUES END */
), (
/* VALUES START */
629,
218,
'action created',
'2022-08-07 19:11:50',
'2022-08-07 19:11:50'
/* VALUES END */
), (
/* VALUES START */
630,
217,
'action started via WP Cron',
'2022-08-07 19:11:50',
'2022-08-07 19:11:50'
/* VALUES END */
), (
/* VALUES START */
631,
217,
'action complete via WP Cron',
'2022-08-07 19:11:50',
'2022-08-07 19:11:50'
/* VALUES END */
), (
/* VALUES START */
632,
219,
'action created',
'2022-08-07 19:11:50',
'2022-08-07 19:11:50'
/* VALUES END */
), (
/* VALUES START */
633,
205,
'action started via WP Cron',
'2022-08-08 15:31:52',
'2022-08-08 15:31:52'
/* VALUES END */
), (
/* VALUES START */
634,
205,
'action complete via WP Cron',
'2022-08-08 15:31:52',
'2022-08-08 15:31:52'
/* VALUES END */
), (
/* VALUES START */
635,
220,
'action created',
'2022-08-08 15:31:52',
'2022-08-08 15:31:52'
/* VALUES END */
), (
/* VALUES START */
636,
218,
'action started via WP Cron',
'2022-08-08 19:12:01',
'2022-08-08 19:12:01'
/* VALUES END */
), (
/* VALUES START */
637,
218,
'action complete via WP Cron',
'2022-08-08 19:12:01',
'2022-08-08 19:12:01'
/* VALUES END */
), (
/* VALUES START */
638,
221,
'action created',
'2022-08-08 19:12:01',
'2022-08-08 19:12:01'
/* VALUES END */
), (
/* VALUES START */
639,
219,
'action started via WP Cron',
'2022-08-08 19:12:01',
'2022-08-08 19:12:01'
/* VALUES END */
), (
/* VALUES START */
640,
219,
'action complete via WP Cron',
'2022-08-08 19:12:01',
'2022-08-08 19:12:01'
/* VALUES END */
), (
/* VALUES START */
641,
222,
'action created',
'2022-08-08 19:12:01',
'2022-08-08 19:12:01'
/* VALUES END */
), (
/* VALUES START */
642,
221,
'action started via WP Cron',
'2022-08-09 19:16:50',
'2022-08-09 19:16:50'
/* VALUES END */
), (
/* VALUES START */
643,
221,
'action complete via WP Cron',
'2022-08-09 19:16:50',
'2022-08-09 19:16:50'
/* VALUES END */
), (
/* VALUES START */
644,
223,
'action created',
'2022-08-09 19:16:50',
'2022-08-09 19:16:50'
/* VALUES END */
), (
/* VALUES START */
645,
222,
'action started via WP Cron',
'2022-08-09 19:16:50',
'2022-08-09 19:16:50'
/* VALUES END */
), (
/* VALUES START */
646,
222,
'action complete via WP Cron',
'2022-08-09 19:16:50',
'2022-08-09 19:16:50'
/* VALUES END */
), (
/* VALUES START */
647,
224,
'action created',
'2022-08-09 19:16:50',
'2022-08-09 19:16:50'
/* VALUES END */
), (
/* VALUES START */
648,
223,
'action started via WP Cron',
'2022-08-10 19:18:49',
'2022-08-10 19:18:49'
/* VALUES END */
), (
/* VALUES START */
649,
223,
'action complete via WP Cron',
'2022-08-10 19:18:50',
'2022-08-10 19:18:50'
/* VALUES END */
), (
/* VALUES START */
650,
225,
'action created',
'2022-08-10 19:18:50',
'2022-08-10 19:18:50'
/* VALUES END */
), (
/* VALUES START */
651,
224,
'action started via WP Cron',
'2022-08-10 19:18:50',
'2022-08-10 19:18:50'
/* VALUES END */
), (
/* VALUES START */
652,
224,
'action complete via WP Cron',
'2022-08-10 19:18:50',
'2022-08-10 19:18:50'
/* VALUES END */
), (
/* VALUES START */
653,
226,
'action created',
'2022-08-10 19:18:50',
'2022-08-10 19:18:50'
/* VALUES END */
), (
/* VALUES START */
654,
225,
'action started via WP Cron',
'2022-08-11 19:19:02',
'2022-08-11 19:19:02'
/* VALUES END */
), (
/* VALUES START */
655,
225,
'action complete via WP Cron',
'2022-08-11 19:19:02',
'2022-08-11 19:19:02'
/* VALUES END */
), (
/* VALUES START */
656,
227,
'action created',
'2022-08-11 19:19:02',
'2022-08-11 19:19:02'
/* VALUES END */
), (
/* VALUES START */
657,
226,
'action started via WP Cron',
'2022-08-11 19:19:02',
'2022-08-11 19:19:02'
/* VALUES END */
), (
/* VALUES START */
658,
226,
'action complete via WP Cron',
'2022-08-11 19:19:02',
'2022-08-11 19:19:02'
/* VALUES END */
), (
/* VALUES START */
659,
228,
'action created',
'2022-08-11 19:19:02',
'2022-08-11 19:19:02'
/* VALUES END */
), (
/* VALUES START */
660,
227,
'action started via WP Cron',
'2022-08-12 19:20:09',
'2022-08-12 19:20:09'
/* VALUES END */
), (
/* VALUES START */
661,
227,
'action complete via WP Cron',
'2022-08-12 19:20:09',
'2022-08-12 19:20:09'
/* VALUES END */
), (
/* VALUES START */
662,
229,
'action created',
'2022-08-12 19:20:09',
'2022-08-12 19:20:09'
/* VALUES END */
), (
/* VALUES START */
663,
228,
'action started via WP Cron',
'2022-08-12 19:20:09',
'2022-08-12 19:20:09'
/* VALUES END */
), (
/* VALUES START */
664,
228,
'action complete via WP Cron',
'2022-08-12 19:20:09',
'2022-08-12 19:20:09'
/* VALUES END */
), (
/* VALUES START */
665,
230,
'action created',
'2022-08-12 19:20:09',
'2022-08-12 19:20:09'
/* VALUES END */
), (
/* VALUES START */
666,
229,
'action started via WP Cron',
'2022-08-13 19:23:50',
'2022-08-13 19:23:50'
/* VALUES END */
), (
/* VALUES START */
667,
229,
'action complete via WP Cron',
'2022-08-13 19:23:50',
'2022-08-13 19:23:50'
/* VALUES END */
), (
/* VALUES START */
668,
231,
'action created',
'2022-08-13 19:23:50',
'2022-08-13 19:23:50'
/* VALUES END */
), (
/* VALUES START */
669,
230,
'action started via WP Cron',
'2022-08-13 19:23:50',
'2022-08-13 19:23:50'
/* VALUES END */
), (
/* VALUES START */
670,
230,
'action complete via WP Cron',
'2022-08-13 19:23:50',
'2022-08-13 19:23:50'
/* VALUES END */
), (
/* VALUES START */
671,
232,
'action created',
'2022-08-13 19:23:50',
'2022-08-13 19:23:50'
/* VALUES END */
), (
/* VALUES START */
672,
231,
'action started via WP Cron',
'2022-08-14 19:25:42',
'2022-08-14 19:25:42'
/* VALUES END */
), (
/* VALUES START */
673,
231,
'action complete via WP Cron',
'2022-08-14 19:25:42',
'2022-08-14 19:25:42'
/* VALUES END */
), (
/* VALUES START */
674,
233,
'action created',
'2022-08-14 19:25:42',
'2022-08-14 19:25:42'
/* VALUES END */
), (
/* VALUES START */
675,
232,
'action started via WP Cron',
'2022-08-14 19:25:42',
'2022-08-14 19:25:42'
/* VALUES END */
), (
/* VALUES START */
676,
232,
'action complete via WP Cron',
'2022-08-14 19:25:42',
'2022-08-14 19:25:42'
/* VALUES END */
), (
/* VALUES START */
677,
234,
'action created',
'2022-08-14 19:25:42',
'2022-08-14 19:25:42'
/* VALUES END */
), (
/* VALUES START */
678,
220,
'action started via WP Cron',
'2022-08-15 15:32:21',
'2022-08-15 15:32:21'
/* VALUES END */
), (
/* VALUES START */
679,
220,
'action complete via WP Cron',
'2022-08-15 15:32:21',
'2022-08-15 15:32:21'
/* VALUES END */
), (
/* VALUES START */
680,
235,
'action created',
'2022-08-15 15:32:22',
'2022-08-15 15:32:22'
/* VALUES END */
), (
/* VALUES START */
681,
233,
'action started via WP Cron',
'2022-08-15 19:26:17',
'2022-08-15 19:26:17'
/* VALUES END */
), (
/* VALUES START */
682,
233,
'action complete via WP Cron',
'2022-08-15 19:26:17',
'2022-08-15 19:26:17'
/* VALUES END */
), (
/* VALUES START */
683,
236,
'action created',
'2022-08-15 19:26:17',
'2022-08-15 19:26:17'
/* VALUES END */
), (
/* VALUES START */
684,
234,
'action started via WP Cron',
'2022-08-15 19:26:17',
'2022-08-15 19:26:17'
/* VALUES END */
), (
/* VALUES START */
685,
234,
'action complete via WP Cron',
'2022-08-15 19:26:17',
'2022-08-15 19:26:17'
/* VALUES END */
), (
/* VALUES START */
686,
237,
'action created',
'2022-08-15 19:26:17',
'2022-08-15 19:26:17'
/* VALUES END */
), (
/* VALUES START */
687,
236,
'action started via WP Cron',
'2022-08-16 19:27:16',
'2022-08-16 19:27:16'
/* VALUES END */
), (
/* VALUES START */
688,
236,
'action complete via WP Cron',
'2022-08-16 19:27:16',
'2022-08-16 19:27:16'
/* VALUES END */
), (
/* VALUES START */
689,
238,
'action created',
'2022-08-16 19:27:16',
'2022-08-16 19:27:16'
/* VALUES END */
), (
/* VALUES START */
690,
237,
'action started via WP Cron',
'2022-08-16 19:27:16',
'2022-08-16 19:27:16'
/* VALUES END */
), (
/* VALUES START */
691,
237,
'action complete via WP Cron',
'2022-08-16 19:27:16',
'2022-08-16 19:27:16'
/* VALUES END */
), (
/* VALUES START */
692,
239,
'action created',
'2022-08-16 19:27:16',
'2022-08-16 19:27:16'
/* VALUES END */
), (
/* VALUES START */
693,
238,
'action started via WP Cron',
'2022-08-17 19:31:19',
'2022-08-17 19:31:19'
/* VALUES END */
), (
/* VALUES START */
694,
238,
'action complete via WP Cron',
'2022-08-17 19:31:19',
'2022-08-17 19:31:19'
/* VALUES END */
), (
/* VALUES START */
695,
240,
'action created',
'2022-08-17 19:31:19',
'2022-08-17 19:31:19'
/* VALUES END */
), (
/* VALUES START */
696,
239,
'action started via WP Cron',
'2022-08-17 19:31:19',
'2022-08-17 19:31:19'
/* VALUES END */
), (
/* VALUES START */
697,
239,
'action complete via WP Cron',
'2022-08-17 19:31:19',
'2022-08-17 19:31:19'
/* VALUES END */
), (
/* VALUES START */
698,
241,
'action created',
'2022-08-17 19:31:19',
'2022-08-17 19:31:19'
/* VALUES END */
), (
/* VALUES START */
699,
240,
'action started via WP Cron',
'2022-08-18 19:33:24',
'2022-08-18 19:33:24'
/* VALUES END */
), (
/* VALUES START */
700,
240,
'action complete via WP Cron',
'2022-08-18 19:33:24',
'2022-08-18 19:33:24'
/* VALUES END */
), (
/* VALUES START */
701,
242,
'action created',
'2022-08-18 19:33:24',
'2022-08-18 19:33:24'
/* VALUES END */
), (
/* VALUES START */
702,
241,
'action started via WP Cron',
'2022-08-18 19:33:24',
'2022-08-18 19:33:24'
/* VALUES END */
), (
/* VALUES START */
703,
241,
'action complete via WP Cron',
'2022-08-18 19:33:24',
'2022-08-18 19:33:24'
/* VALUES END */
), (
/* VALUES START */
704,
243,
'action created',
'2022-08-18 19:33:24',
'2022-08-18 19:33:24'
/* VALUES END */
), (
/* VALUES START */
705,
244,
'action created',
'2022-08-19 05:44:30',
'2022-08-19 05:44:30'
/* VALUES END */
);
/* QUERY END */

