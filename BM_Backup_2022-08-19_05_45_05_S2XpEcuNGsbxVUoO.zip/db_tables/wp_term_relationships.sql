/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_term_relationships`; */
/* PRE_TABLE_NAME: `1660887906_wp_term_relationships`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES ( 
/* VALUES START */
1,
1,
0
/* VALUES END */
), (
/* VALUES START */
3616,
18,
0
/* VALUES END */
), (
/* VALUES START */
3617,
18,
0
/* VALUES END */
), (
/* VALUES START */
3618,
18,
0
/* VALUES END */
), (
/* VALUES START */
3619,
18,
0
/* VALUES END */
), (
/* VALUES START */
3620,
18,
0
/* VALUES END */
), (
/* VALUES START */
3621,
18,
0
/* VALUES END */
), (
/* VALUES START */
3622,
18,
0
/* VALUES END */
), (
/* VALUES START */
3673,
2,
0
/* VALUES END */
), (
/* VALUES START */
3673,
15,
0
/* VALUES END */
), (
/* VALUES START */
3674,
2,
0
/* VALUES END */
), (
/* VALUES START */
3674,
8,
0
/* VALUES END */
), (
/* VALUES START */
3674,
15,
0
/* VALUES END */
), (
/* VALUES START */
3676,
2,
0
/* VALUES END */
), (
/* VALUES START */
3676,
8,
0
/* VALUES END */
), (
/* VALUES START */
3676,
15,
0
/* VALUES END */
), (
/* VALUES START */
3677,
2,
0
/* VALUES END */
), (
/* VALUES START */
3677,
15,
0
/* VALUES END */
), (
/* VALUES START */
3681,
2,
0
/* VALUES END */
), (
/* VALUES START */
3681,
8,
0
/* VALUES END */
), (
/* VALUES START */
3681,
15,
0
/* VALUES END */
), (
/* VALUES START */
3682,
2,
0
/* VALUES END */
), (
/* VALUES START */
3682,
8,
0
/* VALUES END */
), (
/* VALUES START */
3682,
15,
0
/* VALUES END */
), (
/* VALUES START */
3682,
23,
0
/* VALUES END */
), (
/* VALUES START */
3770,
19,
0
/* VALUES END */
), (
/* VALUES START */
3771,
19,
0
/* VALUES END */
), (
/* VALUES START */
3772,
19,
0
/* VALUES END */
), (
/* VALUES START */
3773,
19,
0
/* VALUES END */
), (
/* VALUES START */
3781,
20,
0
/* VALUES END */
), (
/* VALUES START */
3782,
20,
0
/* VALUES END */
), (
/* VALUES START */
3783,
20,
0
/* VALUES END */
), (
/* VALUES START */
3784,
20,
0
/* VALUES END */
), (
/* VALUES START */
3971,
21,
0
/* VALUES END */
), (
/* VALUES START */
3979,
2,
0
/* VALUES END */
), (
/* VALUES START */
3979,
8,
0
/* VALUES END */
), (
/* VALUES START */
3979,
22,
0
/* VALUES END */
), (
/* VALUES START */
4004,
18,
0
/* VALUES END */
), (
/* VALUES START */
4012,
18,
0
/* VALUES END */
), (
/* VALUES START */
4021,
2,
0
/* VALUES END */
), (
/* VALUES START */
4021,
25,
0
/* VALUES END */
), (
/* VALUES START */
4023,
2,
0
/* VALUES END */
), (
/* VALUES START */
4023,
25,
0
/* VALUES END */
), (
/* VALUES START */
4025,
2,
0
/* VALUES END */
), (
/* VALUES START */
4025,
25,
0
/* VALUES END */
), (
/* VALUES START */
4027,
2,
0
/* VALUES END */
), (
/* VALUES START */
4027,
25,
0
/* VALUES END */
), (
/* VALUES START */
4029,
2,
0
/* VALUES END */
), (
/* VALUES START */
4029,
22,
0
/* VALUES END */
);
/* QUERY END */

