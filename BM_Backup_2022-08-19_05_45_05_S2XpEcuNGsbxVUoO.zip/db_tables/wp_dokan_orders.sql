/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_dokan_orders`; */
/* PRE_TABLE_NAME: `1660887906_wp_dokan_orders`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_dokan_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) DEFAULT NULL,
  `seller_id` bigint(20) DEFAULT NULL,
  `order_total` decimal(19,4) DEFAULT NULL,
  `net_amount` decimal(19,4) DEFAULT NULL,
  `order_status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `seller_id` (`seller_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_dokan_orders` (`id`, `order_id`, `seller_id`, `order_total`, `net_amount`, `order_status`) VALUES ( 
/* VALUES START */
1,
4002,
1,
60,
50,
'wc-processing'
/* VALUES END */
), (
/* VALUES START */
2,
4043,
3,
80,
70,
'wc-processing'
/* VALUES END */
), (
/* VALUES START */
3,
4044,
3,
80,
70,
'wc-processing'
/* VALUES END */
), (
/* VALUES START */
4,
4047,
1,
60,
50,
'wc-processing'
/* VALUES END */
), (
/* VALUES START */
5,
4048,
3,
80,
70,
'wc-processing'
/* VALUES END */
), (
/* VALUES START */
6,
4049,
3,
240,
220,
'wc-processing'
/* VALUES END */
);
/* QUERY END */

