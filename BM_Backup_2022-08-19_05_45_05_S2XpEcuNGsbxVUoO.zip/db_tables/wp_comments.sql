/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_comments`; */
/* PRE_TABLE_NAME: `1660887906_wp_comments`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES ( 
/* VALUES START */
1,
1,
'A WordPress Commenter',
'wapuu@wordpress.example',
'https://wordpress.org/',
'',
'2022-06-13 05:44:45',
'2022-06-13 05:44:45',
'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://en.gravatar.com/\">Gravatar</a>.',
0,
1,
'',
'comment',
0,
0
/* VALUES END */
), (
/* VALUES START */
3,
3982,
'WooCommerce',
'',
'',
'',
'2022-06-14 16:04:34',
'2022-06-14 16:04:34',
'Payment to be made upon delivery. Order status changed from Pending payment to Processing.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
4,
3982,
'Mukul Kumar',
'mukulyashi@gmail.com',
'',
'',
'2022-06-14 16:16:20',
'2022-06-14 16:16:20',
'Order status changed from Processing to Completed.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
5,
3984,
'WooCommerce',
'',
'',
'',
'2022-06-14 16:19:56',
'2022-06-14 16:19:56',
'Stock levels reduced: Apples (#3979) 200&rarr;195',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
6,
3984,
'WooCommerce',
'',
'',
'',
'2022-06-14 16:19:56',
'2022-06-14 16:19:56',
'Payment to be made upon delivery. Order status changed from Pending payment to Processing.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
7,
3984,
'WooCommerce',
'',
'',
'',
'2022-06-14 16:20:55',
'2022-06-14 16:20:55',
'Stock levels increased: Apples (#3979) 195&rarr;200',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
8,
3984,
'Mukul Kumar',
'mukulyashi@gmail.com',
'',
'',
'2022-06-14 16:20:55',
'2022-06-14 16:20:55',
'Order status changed from Processing to Cancelled.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
9,
4002,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-06-25 14:26:53',
'2022-06-25 14:26:53',
'Stock levels reduced: Apples (#3979) 200&rarr;199',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
10,
4002,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-06-25 14:26:53',
'2022-06-25 14:26:53',
'Payment to be made upon delivery. Order status changed from Pending payment to Processing.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
11,
4043,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-06-28 16:54:07',
'2022-06-28 16:54:07',
'Payment to be made upon delivery. Order status changed from Pending payment to Processing.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
12,
4044,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-06-28 16:55:00',
'2022-06-28 16:55:00',
'Payment to be made upon delivery. Order status changed from Pending payment to Processing.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
13,
4046,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-07-14 15:23:26',
'2022-07-14 15:23:26',
'Stock levels reduced: Apples (#3979) 199&rarr;198',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
14,
4046,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-07-14 15:23:26',
'2022-07-14 15:23:26',
'Payment to be made upon delivery. Order status changed from Pending payment to Processing.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
15,
4047,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-07-14 15:23:27',
'2022-07-14 15:23:27',
'Stock levels reduced: Apples (#3979) 198&rarr;197',
0,
0,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
16,
4047,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-07-14 15:23:27',
'2022-07-14 15:23:27',
'Stock levels reduced: Apples (#3979) 199&rarr;198',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
17,
4047,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-07-14 15:23:27',
'2022-07-14 15:23:27',
'Order status changed from Pending payment to Processing.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
18,
4048,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-07-14 15:23:27',
'2022-07-14 15:23:27',
'Order status changed from Pending payment to Processing.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
19,
4049,
'WooCommerce',
'woocommerce@letsfarm.in',
'',
'',
'2022-07-14 15:25:20',
'2022-07-14 15:25:20',
'Payment to be made upon delivery. Order status changed from Pending payment to Processing.',
0,
1,
'WooCommerce',
'order_note',
0,
0
/* VALUES END */
), (
/* VALUES START */
20,
1,
'נערות ליווי באילת שירותי ליווי באילת',
'w8eatds@gmail.com',
'https://www.israelxclub.co.il/product/%D7%A9%D7%99%D7%A8%D7%95%D7%AA%D7%99-%D7%9C%D7%99%D7%95%D7%95%D7%99-%D7%91%D7%90%D7%99%D7%9C%D7%AA/',
'144.168.210.69',
'2022-08-05 14:56:05',
'2022-08-05 14:56:05',
'Very nice article. I definitely love this site. Thanks!',
0,
0,
'Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36',
'comment',
0,
0
/* VALUES END */
);
/* QUERY END */

