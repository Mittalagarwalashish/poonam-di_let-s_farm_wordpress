/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `1655736842_wp_cartflows_ca_cart_abandonment`; */
/* PRE_TABLE_NAME: `1660887906_1655736842_wp_cartflows_ca_cart_abandonment`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_1655736842_wp_cartflows_ca_cart_abandonment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `checkout_id` int(11) NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cart_contents` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cart_total` decimal(10,2) DEFAULT NULL,
  `session_id` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_fields` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_status` enum('normal','abandoned','completed','lost') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `unsubscribed` tinyint(1) DEFAULT 0,
  `coupon_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`session_id`),
  UNIQUE KEY `session_id_UNIQUE` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

