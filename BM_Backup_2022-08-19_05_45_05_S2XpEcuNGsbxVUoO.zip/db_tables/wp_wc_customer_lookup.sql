/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_customer_lookup`; */
/* PRE_TABLE_NAME: `1660887906_wp_wc_customer_lookup`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_wc_customer_lookup` (`customer_id`, `user_id`, `username`, `first_name`, `last_name`, `email`, `date_last_active`, `date_registered`, `country`, `postcode`, `city`, `state`) VALUES ( 
/* VALUES START */
1,
1,
'mukulyashi@gmail.com',
'Mukul',
'Kumar',
'mukulyashi@gmail.com',
'2022-06-28 16:54:07',
'2022-06-13 05:44:45',
'IN',
302019,
'Jaipur',
'RJ'
/* VALUES END */
), (
/* VALUES START */
2,
4,
'ashishshiv781',
'Ashish',
'Agarwal',
'ashishshiv781@gmail.com',
'2022-07-14 15:23:26',
'2022-06-25 14:11:20',
'IN',
302039,
'jaipur',
'RJ'
/* VALUES END */
), (
/* VALUES START */
3,
5,
'testcustomer',
'test',
'customer',
'testcustomer@gmail.com',
'2022-07-05 00:00:00',
'2022-06-28 05:27:40',
'',
'',
'',
''
/* VALUES END */
), (
/* VALUES START */
4,
'',
'',
'ashish',
'agarwal',
'aaaa@gmail.co',
'2022-07-14 15:25:20',
'',
'IN',
666666,
'aaa2',
'RJ'
/* VALUES END */
);
/* QUERY END */

