/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_dokan_vendor_balance`; */
/* PRE_TABLE_NAME: `1660887906_wp_dokan_vendor_balance`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_dokan_vendor_balance` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vendor_id` bigint(20) unsigned NOT NULL,
  `trn_id` bigint(20) unsigned NOT NULL,
  `trn_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `perticulars` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `debit` decimal(19,4) NOT NULL,
  `credit` decimal(19,4) NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trn_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `balance_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_dokan_vendor_balance` (`id`, `vendor_id`, `trn_id`, `trn_type`, `perticulars`, `debit`, `credit`, `status`, `trn_date`, `balance_date`) VALUES ( 
/* VALUES START */
1,
1,
4002,
'dokan_orders',
'New order',
50,
0,
'wc-processing',
'2022-06-25 14:26:53',
'2022-06-25 02:26:53'
/* VALUES END */
), (
/* VALUES START */
2,
3,
4043,
'dokan_orders',
'New order',
70,
0,
'wc-processing',
'2022-06-28 16:54:07',
'2022-06-28 04:54:07'
/* VALUES END */
), (
/* VALUES START */
3,
3,
4044,
'dokan_orders',
'New order',
70,
0,
'wc-processing',
'2022-06-28 16:55:00',
'2022-06-28 04:55:00'
/* VALUES END */
), (
/* VALUES START */
4,
1,
4047,
'dokan_orders',
'New order',
50,
0,
'wc-processing',
'2022-07-14 15:23:27',
'2022-07-14 03:23:26'
/* VALUES END */
), (
/* VALUES START */
5,
3,
4048,
'dokan_orders',
'New order',
70,
0,
'wc-processing',
'2022-07-14 15:23:27',
'2022-07-14 03:23:26'
/* VALUES END */
), (
/* VALUES START */
6,
3,
4049,
'dokan_orders',
'New order',
220,
0,
'wc-processing',
'2022-07-14 15:25:20',
'2022-07-14 03:25:20'
/* VALUES END */
);
/* QUERY END */

