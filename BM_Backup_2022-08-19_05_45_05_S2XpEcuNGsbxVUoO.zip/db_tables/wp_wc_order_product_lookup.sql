/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_order_product_lookup`; */
/* PRE_TABLE_NAME: `1660887906_wp_wc_order_product_lookup`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT 0,
  `product_gross_revenue` double NOT NULL DEFAULT 0,
  `coupon_amount` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double NOT NULL DEFAULT 0,
  `shipping_tax_amount` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_wc_order_product_lookup` (`order_item_id`, `order_id`, `product_id`, `variation_id`, `customer_id`, `date_created`, `product_qty`, `product_net_revenue`, `product_gross_revenue`, `coupon_amount`, `tax_amount`, `shipping_amount`, `shipping_tax_amount`) VALUES ( 
/* VALUES START */
2,
3982,
3979,
0,
1,
'2022-06-14 16:04:34',
1,
60,
60,
0,
0,
0,
0
/* VALUES END */
), (
/* VALUES START */
3,
3984,
3979,
0,
1,
'2022-06-14 16:19:56',
5,
300,
300,
0,
0,
0,
0
/* VALUES END */
), (
/* VALUES START */
4,
4002,
3979,
0,
2,
'2022-06-25 14:26:53',
1,
60,
60,
0,
0,
0,
0
/* VALUES END */
), (
/* VALUES START */
5,
4043,
4027,
0,
1,
'2022-06-28 16:54:07',
1,
80,
80,
0,
0,
0,
0
/* VALUES END */
), (
/* VALUES START */
6,
4044,
4027,
0,
2,
'2022-06-28 16:54:59',
1,
80,
80,
0,
0,
0,
0
/* VALUES END */
), (
/* VALUES START */
7,
4046,
3979,
0,
2,
'2022-07-14 15:23:26',
1,
60,
60,
0,
0,
0,
0
/* VALUES END */
), (
/* VALUES START */
8,
4046,
4027,
0,
2,
'2022-07-14 15:23:26',
1,
80,
80,
0,
0,
0,
0
/* VALUES END */
), (
/* VALUES START */
11,
4049,
4029,
0,
4,
'2022-07-14 15:25:20',
2,
240,
240,
0,
0,
0,
0
/* VALUES END */
);
/* QUERY END */

