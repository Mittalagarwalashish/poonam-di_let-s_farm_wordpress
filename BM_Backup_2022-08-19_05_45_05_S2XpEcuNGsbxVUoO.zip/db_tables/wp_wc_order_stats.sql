/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_order_stats`; */
/* PRE_TABLE_NAME: `1660887906_wp_wc_order_stats`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT 0,
  `total_sales` double NOT NULL DEFAULT 0,
  `tax_total` double NOT NULL DEFAULT 0,
  `shipping_total` double NOT NULL DEFAULT 0,
  `net_total` double NOT NULL DEFAULT 0,
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_wc_order_stats` (`order_id`, `parent_id`, `date_created`, `date_created_gmt`, `num_items_sold`, `total_sales`, `tax_total`, `shipping_total`, `net_total`, `returning_customer`, `status`, `customer_id`) VALUES ( 
/* VALUES START */
3982,
0,
'2022-06-14 16:04:34',
'2022-06-14 16:04:34',
1,
60,
0,
0,
60,
0,
'wc-completed',
1
/* VALUES END */
), (
/* VALUES START */
3984,
0,
'2022-06-14 16:19:56',
'2022-06-14 16:19:56',
5,
300,
0,
0,
300,
1,
'wc-cancelled',
1
/* VALUES END */
), (
/* VALUES START */
4002,
0,
'2022-06-25 14:26:53',
'2022-06-25 14:26:53',
1,
60,
0,
0,
60,
0,
'wc-processing',
2
/* VALUES END */
), (
/* VALUES START */
4043,
0,
'2022-06-28 16:54:07',
'2022-06-28 16:54:07',
1,
80,
0,
0,
80,
1,
'wc-processing',
1
/* VALUES END */
), (
/* VALUES START */
4044,
0,
'2022-06-28 16:54:59',
'2022-06-28 16:54:59',
1,
80,
0,
0,
80,
1,
'wc-processing',
2
/* VALUES END */
), (
/* VALUES START */
4046,
0,
'2022-07-14 15:23:26',
'2022-07-14 15:23:26',
2,
140,
0,
0,
140,
1,
'wc-processing',
2
/* VALUES END */
), (
/* VALUES START */
4049,
0,
'2022-07-14 15:25:20',
'2022-07-14 15:25:20',
2,
240,
0,
0,
240,
0,
'wc-processing',
4
/* VALUES END */
);
/* QUERY END */

