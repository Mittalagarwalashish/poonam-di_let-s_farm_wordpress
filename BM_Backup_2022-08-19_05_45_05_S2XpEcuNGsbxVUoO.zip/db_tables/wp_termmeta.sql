/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_termmeta`; */
/* PRE_TABLE_NAME: `1660887906_wp_termmeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
5,
18,
'_astra_sites_imported_term',
1
/* VALUES END */
), (
/* VALUES START */
6,
19,
'_astra_sites_imported_term',
1
/* VALUES END */
), (
/* VALUES START */
7,
20,
'_astra_sites_imported_term',
1
/* VALUES END */
), (
/* VALUES START */
10,
22,
'order',
0
/* VALUES END */
), (
/* VALUES START */
11,
22,
'product_count_product_cat',
2
/* VALUES END */
), (
/* VALUES START */
12,
23,
'product_count_product_tag',
1
/* VALUES END */
), (
/* VALUES START */
13,
24,
'order_pa_farmer',
0
/* VALUES END */
), (
/* VALUES START */
14,
15,
'product_count_product_cat',
6
/* VALUES END */
), (
/* VALUES START */
15,
25,
'order',
0
/* VALUES END */
), (
/* VALUES START */
16,
25,
'display_type',
''
/* VALUES END */
), (
/* VALUES START */
17,
25,
'thumbnail_id',
4019
/* VALUES END */
), (
/* VALUES START */
18,
25,
'product_count_product_cat',
4
/* VALUES END */
);
/* QUERY END */

