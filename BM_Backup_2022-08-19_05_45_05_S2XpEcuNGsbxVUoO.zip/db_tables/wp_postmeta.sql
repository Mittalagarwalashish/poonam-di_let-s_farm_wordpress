/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_postmeta`; */
/* PRE_TABLE_NAME: `1660887906_wp_postmeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1864 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
2,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
2,
3,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
3,
5,
'_wp_attached_file',
'2022/06/logo.png'
/* VALUES END */
), (
/* VALUES START */
4,
5,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:2000;s:6:\"height\";i:1000;s:4:\"file\";s:16:\"2022/06/logo.png\";s:8:\"filesize\";i:375629;s:5:\"sizes\";a:13:{s:6:\"medium\";a:5:{s:4:\"file\";s:16:\"logo-300x150.png\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:25830;}s:5:\"large\";a:5:{s:4:\"file\";s:17:\"logo-1024x512.png\";s:5:\"width\";i:1024;s:6:\"height\";i:512;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:154216;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:16:\"logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:14149;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:16:\"logo-768x384.png\";s:5:\"width\";i:768;s:6:\"height\";i:384;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:101934;}s:9:\"1536x1536\";a:5:{s:4:\"file\";s:17:\"logo-1536x768.png\";s:5:\"width\";i:1536;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:277718;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:16:\"logo-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:38788;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:16:\"logo-600x300.png\";s:5:\"width\";i:600;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:72238;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:16:\"logo-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:7894;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:16:\"logo-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:38788;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:16:\"logo-600x300.png\";s:5:\"width\";i:600;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:72238;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:16:\"logo-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:7894;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:14:\"logo-64x32.png\";s:5:\"width\";i:64;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:2707;}s:13:\"ast-logo-size\";a:5:{s:4:\"file\";s:15:\"logo-120x60.png\";s:5:\"width\";i:120;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";s:8:\"filesize\";i:6723;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
5,
5,
'_wp_attachment_image_alt',
'Let\'s Farm'
/* VALUES END */
), (
/* VALUES START */
6,
6,
'_wp_attached_file',
'woocommerce-placeholder.png'
/* VALUES END */
), (
/* VALUES START */
7,
6,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:8:\"filesize\";i:102644;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
10,
1754,
'_wp_attached_file',
'2019/06/product11-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
11,
1754,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:498;s:6:\"height\";i:650;s:4:\"file\";s:30:\"2019/06/product11-free-img.jpg\";s:8:\"filesize\";i:11176;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
12,
1754,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
13,
1754,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
14,
1754,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
15,
1754,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
16,
1754,
'_astra_sites_image_hash',
'9442f561eb74e99a5740b737d7e0da105c6a2ca9'
/* VALUES END */
), (
/* VALUES START */
17,
1754,
'_elementor_source_image_hash',
'9442f561eb74e99a5740b737d7e0da105c6a2ca9'
/* VALUES END */
), (
/* VALUES START */
18,
1775,
'_wp_attached_file',
'2019/06/product13-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
19,
1775,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:498;s:6:\"height\";i:650;s:4:\"file\";s:30:\"2019/06/product13-free-img.jpg\";s:8:\"filesize\";i:6933;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
20,
1775,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
21,
1775,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
22,
1775,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
23,
1775,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
24,
1775,
'_astra_sites_image_hash',
'8646e2e2fa41abe9f3d8450c2cdfc9bfae802a00'
/* VALUES END */
), (
/* VALUES START */
25,
1775,
'_elementor_source_image_hash',
'8646e2e2fa41abe9f3d8450c2cdfc9bfae802a00'
/* VALUES END */
), (
/* VALUES START */
26,
1785,
'_wp_attached_file',
'2019/06/product17-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
27,
1785,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:498;s:6:\"height\";i:650;s:4:\"file\";s:30:\"2019/06/product17-free-img.jpg\";s:8:\"filesize\";i:8088;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
28,
1785,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
29,
1785,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
30,
1785,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
31,
1785,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
32,
1785,
'_astra_sites_image_hash',
'4545f165d04d2872d40e2694d12572d54b1fa32c'
/* VALUES END */
), (
/* VALUES START */
33,
1785,
'_elementor_source_image_hash',
'4545f165d04d2872d40e2694d12572d54b1fa32c'
/* VALUES END */
), (
/* VALUES START */
34,
1793,
'_wp_attached_file',
'2018/06/product20-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
35,
1793,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/product20-free-img.jpg\";s:8:\"filesize\";i:18155;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
36,
1793,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
37,
1793,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
38,
1793,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
39,
1793,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
40,
1793,
'_astra_sites_image_hash',
'59b267463683c1265c981e7d6ee83ca7a3c2aa32'
/* VALUES END */
), (
/* VALUES START */
41,
1793,
'_elementor_source_image_hash',
'59b267463683c1265c981e7d6ee83ca7a3c2aa32'
/* VALUES END */
), (
/* VALUES START */
42,
1794,
'_wp_attached_file',
'2018/06/product19-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
43,
1794,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/product19-free-img.jpg\";s:8:\"filesize\";i:18597;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
44,
1794,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
45,
1794,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
46,
1794,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
47,
1794,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
48,
1794,
'_astra_sites_image_hash',
'0ed7283ae8440d59e2f710de167c0ef5071d569c'
/* VALUES END */
), (
/* VALUES START */
49,
1794,
'_elementor_source_image_hash',
'0ed7283ae8440d59e2f710de167c0ef5071d569c'
/* VALUES END */
), (
/* VALUES START */
50,
1795,
'_wp_attached_file',
'2018/06/product21-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
51,
1795,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/product21-free-img.jpg\";s:8:\"filesize\";i:15749;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
52,
1795,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
53,
1795,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
54,
1795,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
55,
1795,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
56,
1795,
'_astra_sites_image_hash',
'b9a37f4fe3d28dd3fb4815b39d0c186f174b4e1f'
/* VALUES END */
), (
/* VALUES START */
57,
1795,
'_elementor_source_image_hash',
'b9a37f4fe3d28dd3fb4815b39d0c186f174b4e1f'
/* VALUES END */
), (
/* VALUES START */
58,
1816,
'_wp_attached_file',
'2018/06/product23-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
59,
1816,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/product23-free-img.jpg\";s:8:\"filesize\";i:14679;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
60,
1816,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
61,
1816,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
62,
1816,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
63,
1816,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
64,
1816,
'_astra_sites_image_hash',
'5a12143d2c7f5a86da32e30491ed78ea026c0fdd'
/* VALUES END */
), (
/* VALUES START */
65,
1816,
'_elementor_source_image_hash',
'5a12143d2c7f5a86da32e30491ed78ea026c0fdd'
/* VALUES END */
), (
/* VALUES START */
66,
1817,
'_wp_attached_file',
'2018/06/product24-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
67,
1817,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/product24-free-img.jpg\";s:8:\"filesize\";i:19634;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
68,
1817,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
69,
1817,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
70,
1817,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
71,
1817,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
72,
1817,
'_astra_sites_image_hash',
'83bcbe33f4239de60e887ebe900ebff47725941c'
/* VALUES END */
), (
/* VALUES START */
73,
1817,
'_elementor_source_image_hash',
'83bcbe33f4239de60e887ebe900ebff47725941c'
/* VALUES END */
), (
/* VALUES START */
74,
1818,
'_wp_attached_file',
'2018/06/product25-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
75,
1818,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/product25-free-img.jpg\";s:8:\"filesize\";i:21838;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
76,
1818,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
77,
1818,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
78,
1818,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
79,
1818,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
80,
1818,
'_astra_sites_image_hash',
'b475d6462df539dd151ecc74c4507df140b5da04'
/* VALUES END */
), (
/* VALUES START */
81,
1818,
'_elementor_source_image_hash',
'b475d6462df539dd151ecc74c4507df140b5da04'
/* VALUES END */
), (
/* VALUES START */
82,
1831,
'_wp_attached_file',
'2019/06/logo01-free-img.png'
/* VALUES END */
), (
/* VALUES START */
83,
1831,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:159;s:6:\"height\";i:100;s:4:\"file\";s:27:\"2019/06/logo01-free-img.png\";s:8:\"filesize\";i:2270;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
84,
1831,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
85,
1831,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
86,
1831,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
87,
1831,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
88,
1831,
'_astra_sites_image_hash',
'82493d6712a64c901468fb7540b9e060cab473a6'
/* VALUES END */
), (
/* VALUES START */
89,
1831,
'_elementor_source_image_hash',
'82493d6712a64c901468fb7540b9e060cab473a6'
/* VALUES END */
), (
/* VALUES START */
90,
1835,
'_wp_attached_file',
'2019/06/logo02-free-img.png'
/* VALUES END */
), (
/* VALUES START */
91,
1835,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:159;s:6:\"height\";i:100;s:4:\"file\";s:27:\"2019/06/logo02-free-img.png\";s:8:\"filesize\";i:1465;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
92,
1835,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
93,
1835,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
94,
1835,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
95,
1835,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
96,
1835,
'_astra_sites_image_hash',
'3a4465419fbbf2d708f731f8b0105861295cb979'
/* VALUES END */
), (
/* VALUES START */
97,
1835,
'_elementor_source_image_hash',
'3a4465419fbbf2d708f731f8b0105861295cb979'
/* VALUES END */
), (
/* VALUES START */
98,
1839,
'_wp_attached_file',
'2019/06/logo03-free-img.png'
/* VALUES END */
), (
/* VALUES START */
99,
1839,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:159;s:6:\"height\";i:100;s:4:\"file\";s:27:\"2019/06/logo03-free-img.png\";s:8:\"filesize\";i:1924;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
100,
1839,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
101,
1839,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
102,
1839,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
103,
1839,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
104,
1839,
'_astra_sites_image_hash',
'fffbf853ee5f54efad2ab807822578767d0a3898'
/* VALUES END */
), (
/* VALUES START */
105,
1839,
'_elementor_source_image_hash',
'fffbf853ee5f54efad2ab807822578767d0a3898'
/* VALUES END */
), (
/* VALUES START */
106,
1851,
'_wp_attached_file',
'2019/06/logo04-free-img.png'
/* VALUES END */
), (
/* VALUES START */
107,
1851,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:159;s:6:\"height\";i:100;s:4:\"file\";s:27:\"2019/06/logo04-free-img.png\";s:8:\"filesize\";i:1337;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
108,
1851,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
109,
1851,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
110,
1851,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
111,
1851,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
112,
1851,
'_astra_sites_image_hash',
'1c7fa4591b3bb6ba957c529b73d5e278d9624aaf'
/* VALUES END */
), (
/* VALUES START */
113,
1851,
'_elementor_source_image_hash',
'1c7fa4591b3bb6ba957c529b73d5e278d9624aaf'
/* VALUES END */
), (
/* VALUES START */
114,
1853,
'_wp_attached_file',
'2019/06/logo05-free-img.png'
/* VALUES END */
), (
/* VALUES START */
115,
1853,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:159;s:6:\"height\";i:100;s:4:\"file\";s:27:\"2019/06/logo05-free-img.png\";s:8:\"filesize\";i:1981;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
116,
1853,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
117,
1853,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
118,
1853,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
119,
1853,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
120,
1853,
'_astra_sites_image_hash',
'5a1cc888f8fbc8e85b4871a0db54043ebaa1699f'
/* VALUES END */
), (
/* VALUES START */
121,
1853,
'_elementor_source_image_hash',
'5a1cc888f8fbc8e85b4871a0db54043ebaa1699f'
/* VALUES END */
), (
/* VALUES START */
122,
1855,
'_wp_attached_file',
'2019/06/app-store.png'
/* VALUES END */
), (
/* VALUES START */
123,
1855,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:201;s:6:\"height\";i:60;s:4:\"file\";s:21:\"2019/06/app-store.png\";s:8:\"filesize\";i:1580;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
124,
1855,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
125,
1855,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
126,
1855,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
127,
1855,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
128,
1855,
'_astra_sites_image_hash',
'1606a534203e6a8585bce7af42335b687960b774'
/* VALUES END */
), (
/* VALUES START */
129,
1855,
'_elementor_source_image_hash',
'1606a534203e6a8585bce7af42335b687960b774'
/* VALUES END */
), (
/* VALUES START */
130,
1857,
'_wp_attached_file',
'2019/06/play-store.png'
/* VALUES END */
), (
/* VALUES START */
131,
1857,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:201;s:6:\"height\";i:60;s:4:\"file\";s:22:\"2019/06/play-store.png\";s:8:\"filesize\";i:2787;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
132,
1857,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
133,
1857,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
134,
1857,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
135,
1857,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
136,
1857,
'_astra_sites_image_hash',
'c0a5e3eb62abcdb3c1709202de9618ab71e2db1f'
/* VALUES END */
), (
/* VALUES START */
137,
1857,
'_elementor_source_image_hash',
'c0a5e3eb62abcdb3c1709202de9618ab71e2db1f'
/* VALUES END */
), (
/* VALUES START */
138,
1895,
'_wp_attached_file',
'2019/06/sydney-rae-668606-unsplash.jpg'
/* VALUES END */
), (
/* VALUES START */
139,
1895,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:2674;s:6:\"height\";i:2222;s:4:\"file\";s:38:\"2019/06/sydney-rae-668606-unsplash.jpg\";s:8:\"filesize\";i:207247;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
140,
1895,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
141,
1895,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
142,
1895,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
143,
1895,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
144,
1895,
'_astra_sites_image_hash',
'33f6a15f9d94273c760d40f2b03c3b577828778e'
/* VALUES END */
), (
/* VALUES START */
145,
1895,
'_elementor_source_image_hash',
'33f6a15f9d94273c760d40f2b03c3b577828778e'
/* VALUES END */
), (
/* VALUES START */
146,
2032,
'_wp_attached_file',
'2019/06/organic-badge-freeimg.png'
/* VALUES END */
), (
/* VALUES START */
147,
2032,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:194;s:6:\"height\";i:153;s:4:\"file\";s:33:\"2019/06/organic-badge-freeimg.png\";s:8:\"filesize\";i:8458;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
148,
2032,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
149,
2032,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
150,
2032,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
151,
2032,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
152,
2032,
'_astra_sites_image_hash',
'8894bec039a621ae6bd034273b3e4cb4d2eca509'
/* VALUES END */
), (
/* VALUES START */
153,
2032,
'_elementor_source_image_hash',
'8894bec039a621ae6bd034273b3e4cb4d2eca509'
/* VALUES END */
), (
/* VALUES START */
154,
2061,
'_wp_attached_file',
'2019/06/farming04-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
155,
2061,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:634;s:6:\"height\";i:951;s:4:\"file\";s:30:\"2019/06/farming04-free-img.jpg\";s:8:\"filesize\";i:35243;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
156,
2061,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
157,
2061,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
158,
2061,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
159,
2061,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
160,
2061,
'_astra_sites_image_hash',
'06f9aaf7299bd628a97a2b6c08d8f90ebec72265'
/* VALUES END */
), (
/* VALUES START */
161,
2061,
'_elementor_source_image_hash',
'06f9aaf7299bd628a97a2b6c08d8f90ebec72265'
/* VALUES END */
), (
/* VALUES START */
162,
2064,
'_wp_attached_file',
'2019/06/farming03-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
163,
2064,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:634;s:6:\"height\";i:951;s:4:\"file\";s:30:\"2019/06/farming03-free-img.jpg\";s:8:\"filesize\";i:158890;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
164,
2064,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
165,
2064,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
166,
2064,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
167,
2064,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
168,
2064,
'_astra_sites_image_hash',
'fc198b26b0938f6b39768acae3a6ca167e540ecc'
/* VALUES END */
), (
/* VALUES START */
169,
2064,
'_elementor_source_image_hash',
'fc198b26b0938f6b39768acae3a6ca167e540ecc'
/* VALUES END */
), (
/* VALUES START */
170,
2205,
'_wp_attached_file',
'2018/06/product26-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
171,
2205,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/product26-free-img.jpg\";s:8:\"filesize\";i:18057;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
172,
2205,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
173,
2205,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
174,
2205,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
175,
2205,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
176,
2205,
'_astra_sites_image_hash',
'323c95d054fe5dd881781a8a993d6bbf8f9a3c93'
/* VALUES END */
), (
/* VALUES START */
177,
2205,
'_elementor_source_image_hash',
'323c95d054fe5dd881781a8a993d6bbf8f9a3c93'
/* VALUES END */
), (
/* VALUES START */
178,
2207,
'_wp_attached_file',
'2018/06/product27-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
179,
2207,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/product27-free-img.jpg\";s:8:\"filesize\";i:21556;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
180,
2207,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
181,
2207,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
182,
2207,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
183,
2207,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
184,
2207,
'_astra_sites_image_hash',
'dc259e375817fc8c061034db911330c73777a891'
/* VALUES END */
), (
/* VALUES START */
185,
2207,
'_elementor_source_image_hash',
'dc259e375817fc8c061034db911330c73777a891'
/* VALUES END */
), (
/* VALUES START */
186,
2210,
'_wp_attached_file',
'2018/06/product29-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
187,
2210,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/product29-free-img.jpg\";s:8:\"filesize\";i:17123;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
188,
2210,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
189,
2210,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
190,
2210,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
191,
2210,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
192,
2210,
'_astra_sites_image_hash',
'76cf5ccffcf7363a7b92e99ddc03c21bd59e1daa'
/* VALUES END */
), (
/* VALUES START */
193,
2210,
'_elementor_source_image_hash',
'76cf5ccffcf7363a7b92e99ddc03c21bd59e1daa'
/* VALUES END */
), (
/* VALUES START */
194,
2234,
'_wp_attached_file',
'2019/06/organic-favicon-free-img.png'
/* VALUES END */
), (
/* VALUES START */
195,
2234,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:100;s:6:\"height\";i:100;s:4:\"file\";s:36:\"2019/06/organic-favicon-free-img.png\";s:8:\"filesize\";i:949;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
196,
2234,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
197,
2234,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
198,
2234,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
199,
2234,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
200,
2234,
'_astra_sites_image_hash',
'9e36965820d5bf152c8e4913bea24f9b0e0d109d'
/* VALUES END */
), (
/* VALUES START */
201,
2234,
'_elementor_source_image_hash',
'9e36965820d5bf152c8e4913bea24f9b0e0d109d'
/* VALUES END */
), (
/* VALUES START */
202,
2465,
'_wp_attached_file',
'2019/06/organic-store-yoast-img.jpg'
/* VALUES END */
), (
/* VALUES START */
203,
2465,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:628;s:4:\"file\";s:35:\"2019/06/organic-store-yoast-img.jpg\";s:8:\"filesize\";i:38564;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
204,
2465,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
205,
2465,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
206,
2465,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
207,
2465,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
208,
2465,
'_astra_sites_image_hash',
'e1f2c6fd3f8b0055e7df54fcb194a8ca7d7761cc'
/* VALUES END */
), (
/* VALUES START */
209,
2465,
'_elementor_source_image_hash',
'e1f2c6fd3f8b0055e7df54fcb194a8ca7d7761cc'
/* VALUES END */
), (
/* VALUES START */
210,
2470,
'_wp_attached_file',
'2019/06/organic-store-logo5.svg'
/* VALUES END */
), (
/* VALUES START */
211,
2470,
'_wp_attachment_metadata',
'a:1:{s:8:\"filesize\";i:41121;}'
/* VALUES END */
), (
/* VALUES START */
212,
2470,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
213,
2470,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
214,
2470,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
215,
2470,
'_astra_sites_image_hash',
'75bd381194b2d4a8a958424a0beb3a8f648e333a'
/* VALUES END */
), (
/* VALUES START */
216,
2470,
'_elementor_source_image_hash',
'75bd381194b2d4a8a958424a0beb3a8f648e333a'
/* VALUES END */
), (
/* VALUES START */
217,
2478,
'_wp_attached_file',
'2019/07/organic-store-white-logo.png'
/* VALUES END */
), (
/* VALUES START */
218,
2478,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:220;s:6:\"height\";i:97;s:4:\"file\";s:36:\"2019/07/organic-store-white-logo.png\";s:8:\"filesize\";i:2176;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
219,
2478,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
220,
2478,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
221,
2478,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
222,
2478,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
223,
2478,
'_astra_sites_image_hash',
'ce5769d9536720bdc864fe8b9359ce5195b0215a'
/* VALUES END */
), (
/* VALUES START */
224,
2478,
'_elementor_source_image_hash',
'ce5769d9536720bdc864fe8b9359ce5195b0215a'
/* VALUES END */
), (
/* VALUES START */
225,
2504,
'_wp_attached_file',
'2018/06/orange_juice_free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
226,
2504,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:33:\"2018/06/orange_juice_free-img.jpg\";s:8:\"filesize\";i:13853;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
227,
2504,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
228,
2504,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
229,
2504,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
230,
2504,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
231,
2504,
'_astra_sites_image_hash',
'583602753400234c8a33512f25e6ff0ad45b2831'
/* VALUES END */
), (
/* VALUES START */
232,
2504,
'_elementor_source_image_hash',
'583602753400234c8a33512f25e6ff0ad45b2831'
/* VALUES END */
), (
/* VALUES START */
233,
2505,
'_wp_attached_file',
'2018/06/honey-jar-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
234,
2505,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2018/06/honey-jar-free-img.jpg\";s:8:\"filesize\";i:17619;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
235,
2505,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
236,
2505,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
237,
2505,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
238,
2505,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
239,
2505,
'_astra_sites_image_hash',
'2c4a6d223d9178c0661cf78a7729254790e939eb'
/* VALUES END */
), (
/* VALUES START */
240,
2505,
'_elementor_source_image_hash',
'2c4a6d223d9178c0661cf78a7729254790e939eb'
/* VALUES END */
), (
/* VALUES START */
241,
2515,
'_wp_attached_file',
'2019/07/client02-free-img.png'
/* VALUES END */
), (
/* VALUES START */
242,
2515,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:60;s:6:\"height\";i:60;s:4:\"file\";s:29:\"2019/07/client02-free-img.png\";s:8:\"filesize\";i:3303;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
243,
2515,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
244,
2515,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
245,
2515,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
246,
2515,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
247,
2515,
'_astra_sites_image_hash',
'1b9230712b3be0d20394b408023aaa5224dbae0f'
/* VALUES END */
), (
/* VALUES START */
248,
2515,
'_elementor_source_image_hash',
'1b9230712b3be0d20394b408023aaa5224dbae0f'
/* VALUES END */
), (
/* VALUES START */
249,
2516,
'_wp_attached_file',
'2019/07/client01-free-img.png'
/* VALUES END */
), (
/* VALUES START */
250,
2516,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:60;s:6:\"height\";i:60;s:4:\"file\";s:29:\"2019/07/client01-free-img.png\";s:8:\"filesize\";i:3561;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
251,
2516,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
252,
2516,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
253,
2516,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
254,
2516,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
255,
2516,
'_astra_sites_image_hash',
'9621d29bfdc4def5cdd360eb7fd94af48cfcb058'
/* VALUES END */
), (
/* VALUES START */
256,
2516,
'_elementor_source_image_hash',
'9621d29bfdc4def5cdd360eb7fd94af48cfcb058'
/* VALUES END */
), (
/* VALUES START */
257,
2518,
'_wp_attached_file',
'2019/07/logo-leaf-new.png'
/* VALUES END */
), (
/* VALUES START */
258,
2518,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:75;s:6:\"height\";i:33;s:4:\"file\";s:25:\"2019/07/logo-leaf-new.png\";s:8:\"filesize\";i:778;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
259,
2518,
'_shortpixel_status',
2
/* VALUES END */
), (
/* VALUES START */
260,
2518,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
261,
2518,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
262,
2518,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
263,
2518,
'_astra_sites_image_hash',
'2d0f17147f5f2e0e859efeadbb098db6cae8fb55'
/* VALUES END */
), (
/* VALUES START */
264,
2518,
'_elementor_source_image_hash',
'2d0f17147f5f2e0e859efeadbb098db6cae8fb55'
/* VALUES END */
), (
/* VALUES START */
265,
3007,
'_wp_attached_file',
'2020/01/banner-01.jpg'
/* VALUES END */
), (
/* VALUES START */
266,
3007,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:800;s:6:\"height\";i:550;s:4:\"file\";s:21:\"2020/01/banner-01.jpg\";s:8:\"filesize\";i:76001;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
267,
3007,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
268,
3007,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
269,
3007,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
270,
3007,
'_astra_sites_image_hash',
'8386e9e322f0474255b40317fbbc1e0c5c1a8f56'
/* VALUES END */
), (
/* VALUES START */
271,
3007,
'_elementor_source_image_hash',
'8386e9e322f0474255b40317fbbc1e0c5c1a8f56'
/* VALUES END */
), (
/* VALUES START */
272,
3010,
'_wp_attached_file',
'2020/01/image-02.jpg'
/* VALUES END */
), (
/* VALUES START */
273,
3010,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:634;s:6:\"height\";i:951;s:4:\"file\";s:20:\"2020/01/image-02.jpg\";s:8:\"filesize\";i:102632;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
274,
3010,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
275,
3010,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
276,
3010,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
277,
3010,
'_astra_sites_image_hash',
'1715829160c641bc5af1343c4d3a9c3b65fe3293'
/* VALUES END */
), (
/* VALUES START */
278,
3010,
'_elementor_source_image_hash',
'1715829160c641bc5af1343c4d3a9c3b65fe3293'
/* VALUES END */
), (
/* VALUES START */
279,
3040,
'_wp_attached_file',
'2020/02/organic-products.png'
/* VALUES END */
), (
/* VALUES START */
280,
3040,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:634;s:6:\"height\";i:543;s:4:\"file\";s:28:\"2020/02/organic-products.png\";s:8:\"filesize\";i:306355;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
281,
3040,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
282,
3040,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
283,
3040,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
284,
3040,
'_astra_sites_image_hash',
'bfa534887f5d1f41c83bf83d123da60ef207c082'
/* VALUES END */
), (
/* VALUES START */
285,
3040,
'_elementor_source_image_hash',
'bfa534887f5d1f41c83bf83d123da60ef207c082'
/* VALUES END */
), (
/* VALUES START */
286,
3044,
'_wp_attached_file',
'2018/06/pumpkin-pulp-tin.jpg'
/* VALUES END */
), (
/* VALUES START */
287,
3044,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:28:\"2018/06/pumpkin-pulp-tin.jpg\";s:8:\"filesize\";i:449035;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
288,
3044,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
289,
3044,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
290,
3044,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
291,
3044,
'_astra_sites_image_hash',
'0350a5af5d38b5e089d7b1cc77eca95e3e5b94ce'
/* VALUES END */
), (
/* VALUES START */
292,
3044,
'_elementor_source_image_hash',
'0350a5af5d38b5e089d7b1cc77eca95e3e5b94ce'
/* VALUES END */
), (
/* VALUES START */
293,
3603,
'_wp_attached_file',
'2020/09/woocommerce-placeholder.png'
/* VALUES END */
), (
/* VALUES START */
294,
3603,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:35:\"2020/09/woocommerce-placeholder.png\";s:8:\"filesize\";i:102644;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
295,
3603,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
296,
3603,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
297,
3603,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
298,
3603,
'_astra_sites_image_hash',
'37b5d293557956a112bc4f73b7787e2111953674'
/* VALUES END */
), (
/* VALUES START */
299,
3603,
'_elementor_source_image_hash',
'37b5d293557956a112bc4f73b7787e2111953674'
/* VALUES END */
), (
/* VALUES START */
300,
3627,
'_wp_attached_file',
'2020/09/leaves-bg.jpg'
/* VALUES END */
), (
/* VALUES START */
301,
3627,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1080;s:4:\"file\";s:21:\"2020/09/leaves-bg.jpg\";s:8:\"filesize\";i:38305;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
304,
3627,
'_astra_sites_imported_post',
1
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
305,
3627,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
306,
3627,
'_astra_sites_image_hash',
'979a3e400441d3649b820cc610681a8037c41ded'
/* VALUES END */
), (
/* VALUES START */
307,
3627,
'_elementor_source_image_hash',
'979a3e400441d3649b820cc610681a8037c41ded'
/* VALUES END */
), (
/* VALUES START */
308,
3641,
'_wp_attached_file',
'2020/09/free-delivery.png'
/* VALUES END */
), (
/* VALUES START */
309,
3641,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:64;s:6:\"height\";i:64;s:4:\"file\";s:25:\"2020/09/free-delivery.png\";s:8:\"filesize\";i:886;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
312,
3641,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
313,
3641,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
314,
3641,
'_astra_sites_image_hash',
'669b5fc549142b6749154b82386726bf80ee6128'
/* VALUES END */
), (
/* VALUES START */
315,
3641,
'_elementor_source_image_hash',
'669b5fc549142b6749154b82386726bf80ee6128'
/* VALUES END */
), (
/* VALUES START */
316,
3653,
'_wp_attached_file',
'2020/09/certified.png'
/* VALUES END */
), (
/* VALUES START */
317,
3653,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:64;s:6:\"height\";i:64;s:4:\"file\";s:21:\"2020/09/certified.png\";s:8:\"filesize\";i:1249;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
320,
3653,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
321,
3653,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
322,
3653,
'_astra_sites_image_hash',
'ae528de0e492b1c66dd385d3fbcb877003eb0cd0'
/* VALUES END */
), (
/* VALUES START */
323,
3653,
'_elementor_source_image_hash',
'ae528de0e492b1c66dd385d3fbcb877003eb0cd0'
/* VALUES END */
), (
/* VALUES START */
324,
3660,
'_wp_attached_file',
'2020/09/savings.png'
/* VALUES END */
), (
/* VALUES START */
325,
3660,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:64;s:6:\"height\";i:34;s:4:\"file\";s:19:\"2020/09/savings.png\";s:8:\"filesize\";i:927;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
328,
3660,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
329,
3660,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
330,
3660,
'_astra_sites_image_hash',
'299923ed1b851291eb613c2965f203b1c6abfffa'
/* VALUES END */
), (
/* VALUES START */
331,
3660,
'_elementor_source_image_hash',
'299923ed1b851291eb613c2965f203b1c6abfffa'
/* VALUES END */
), (
/* VALUES START */
332,
3662,
'_wp_attached_file',
'2020/09/easy-returns.png'
/* VALUES END */
), (
/* VALUES START */
333,
3662,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:64;s:6:\"height\";i:64;s:4:\"file\";s:24:\"2020/09/easy-returns.png\";s:8:\"filesize\";i:1383;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
336,
3662,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
337,
3662,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
338,
3662,
'_astra_sites_image_hash',
'e9ed536af9a70d25cb896cd1dd22b405efddcb7f'
/* VALUES END */
), (
/* VALUES START */
339,
3662,
'_elementor_source_image_hash',
'e9ed536af9a70d25cb896cd1dd22b405efddcb7f'
/* VALUES END */
), (
/* VALUES START */
340,
3683,
'_wp_attached_file',
'2020/09/pumpkin-pulp-tin.jpg'
/* VALUES END */
), (
/* VALUES START */
341,
3683,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:28:\"2020/09/pumpkin-pulp-tin.jpg\";s:8:\"filesize\";i:449035;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
342,
3683,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/pumpkin-pulp-tin.jpg'
/* VALUES END */
), (
/* VALUES START */
345,
3683,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
346,
3683,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
347,
3683,
'_astra_sites_image_hash',
'08baab5e42fb21c6486ca67bc1da6fda17a44d10'
/* VALUES END */
), (
/* VALUES START */
348,
3683,
'_elementor_source_image_hash',
'08baab5e42fb21c6486ca67bc1da6fda17a44d10'
/* VALUES END */
), (
/* VALUES START */
349,
3684,
'_wp_attached_file',
'2020/09/product24-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
350,
3684,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/product24-free-img.jpg\";s:8:\"filesize\";i:19634;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
351,
3684,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/product24-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
354,
3684,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
355,
3684,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
356,
3684,
'_astra_sites_image_hash',
'46a7ba05d4f36d324e11e432501cf6c771b2046c'
/* VALUES END */
), (
/* VALUES START */
357,
3684,
'_elementor_source_image_hash',
'46a7ba05d4f36d324e11e432501cf6c771b2046c'
/* VALUES END */
), (
/* VALUES START */
358,
3685,
'_wp_attached_file',
'2020/09/product29-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
359,
3685,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/product29-free-img.jpg\";s:8:\"filesize\";i:17123;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
360,
3685,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/product29-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
363,
3685,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
364,
3685,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
365,
3685,
'_astra_sites_image_hash',
'aba38bf0fb433b4ad10820b35217c1f27a000d1c'
/* VALUES END */
), (
/* VALUES START */
366,
3685,
'_elementor_source_image_hash',
'aba38bf0fb433b4ad10820b35217c1f27a000d1c'
/* VALUES END */
), (
/* VALUES START */
367,
3686,
'_wp_attached_file',
'2020/09/product26-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
368,
3686,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/product26-free-img.jpg\";s:8:\"filesize\";i:18057;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
369,
3686,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/product26-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
372,
3686,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
373,
3686,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
374,
3686,
'_astra_sites_image_hash',
'b6dbee7fe0e691ee06b1ab1de63d2c95bd6b1b69'
/* VALUES END */
), (
/* VALUES START */
375,
3686,
'_elementor_source_image_hash',
'b6dbee7fe0e691ee06b1ab1de63d2c95bd6b1b69'
/* VALUES END */
), (
/* VALUES START */
376,
3687,
'_wp_attached_file',
'2020/09/product25-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
377,
3687,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/product25-free-img.jpg\";s:8:\"filesize\";i:21838;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
378,
3687,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/product25-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
381,
3687,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
382,
3687,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
383,
3687,
'_astra_sites_image_hash',
'1c52d140b726b9707f4e3043dfee28bdf132cb5a'
/* VALUES END */
), (
/* VALUES START */
384,
3687,
'_elementor_source_image_hash',
'1c52d140b726b9707f4e3043dfee28bdf132cb5a'
/* VALUES END */
), (
/* VALUES START */
385,
3688,
'_wp_attached_file',
'2020/09/product23-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
386,
3688,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/product23-free-img.jpg\";s:8:\"filesize\";i:14679;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
387,
3688,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/product23-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
390,
3688,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
391,
3688,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
392,
3688,
'_astra_sites_image_hash',
'7f35eacec5f6408da9d8e257ff256d46e231f0c6'
/* VALUES END */
), (
/* VALUES START */
393,
3688,
'_elementor_source_image_hash',
'7f35eacec5f6408da9d8e257ff256d46e231f0c6'
/* VALUES END */
), (
/* VALUES START */
394,
3689,
'_wp_attached_file',
'2020/09/honey-jar-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
395,
3689,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/honey-jar-free-img.jpg\";s:8:\"filesize\";i:17619;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
396,
3689,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/honey-jar-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
399,
3689,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
400,
3689,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
401,
3689,
'_astra_sites_image_hash',
'2c2902d3afeb814a3da603507a42226e51dfd66e'
/* VALUES END */
), (
/* VALUES START */
402,
3689,
'_elementor_source_image_hash',
'2c2902d3afeb814a3da603507a42226e51dfd66e'
/* VALUES END */
), (
/* VALUES START */
403,
3690,
'_wp_attached_file',
'2020/09/product27-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
404,
3690,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/product27-free-img.jpg\";s:8:\"filesize\";i:21556;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
405,
3690,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/product27-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
408,
3690,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
409,
3690,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
410,
3690,
'_astra_sites_image_hash',
'22d9cc6971237cce01037dda4fff9bd49d81f5e0'
/* VALUES END */
), (
/* VALUES START */
411,
3690,
'_elementor_source_image_hash',
'22d9cc6971237cce01037dda4fff9bd49d81f5e0'
/* VALUES END */
), (
/* VALUES START */
412,
3691,
'_wp_attached_file',
'2020/09/product19-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
413,
3691,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/product19-free-img.jpg\";s:8:\"filesize\";i:18597;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
414,
3691,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/product19-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
417,
3691,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
418,
3691,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
419,
3691,
'_astra_sites_image_hash',
'8bbf3a92cd3302b3f2f8afc9c85682174d1dcd06'
/* VALUES END */
), (
/* VALUES START */
420,
3691,
'_elementor_source_image_hash',
'8bbf3a92cd3302b3f2f8afc9c85682174d1dcd06'
/* VALUES END */
), (
/* VALUES START */
421,
3692,
'_wp_attached_file',
'2020/09/orange_juice_free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
422,
3692,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:33:\"2020/09/orange_juice_free-img.jpg\";s:8:\"filesize\";i:13853;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
423,
3692,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/orange_juice_free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
426,
3692,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
427,
3692,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
428,
3692,
'_astra_sites_image_hash',
'7050962a1241d38d8d89ed400bfff6397195852a'
/* VALUES END */
), (
/* VALUES START */
429,
3692,
'_elementor_source_image_hash',
'7050962a1241d38d8d89ed400bfff6397195852a'
/* VALUES END */
), (
/* VALUES START */
430,
3693,
'_wp_attached_file',
'2020/09/product21-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
431,
3693,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/product21-free-img.jpg\";s:8:\"filesize\";i:15749;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
432,
3693,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/product21-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
435,
3693,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
436,
3693,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
437,
3693,
'_astra_sites_image_hash',
'845eb97ca448568c8017ed784c534c3998a96828'
/* VALUES END */
), (
/* VALUES START */
438,
3693,
'_elementor_source_image_hash',
'845eb97ca448568c8017ed784c534c3998a96828'
/* VALUES END */
), (
/* VALUES START */
439,
3694,
'_wp_attached_file',
'2020/09/product20-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
440,
3694,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:30:\"2020/09/product20-free-img.jpg\";s:8:\"filesize\";i:18155;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
441,
3694,
'_wc_attachment_source',
'https://websitedemos.net/organic-shop-02/wp-content/uploads/sites/465/2018/06/product20-free-img.jpg'
/* VALUES END */
), (
/* VALUES START */
444,
3694,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
445,
3694,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
446,
3694,
'_astra_sites_image_hash',
'74334e1a85d84355396d98b51732fa2516b0bb9c'
/* VALUES END */
), (
/* VALUES START */
447,
3694,
'_elementor_source_image_hash',
'74334e1a85d84355396d98b51732fa2516b0bb9c'
/* VALUES END */
), (
/* VALUES START */
448,
3716,
'_wp_attached_file',
'2020/09/leaves-bg-rev.jpg'
/* VALUES END */
), (
/* VALUES START */
449,
3716,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:1080;s:4:\"file\";s:25:\"2020/09/leaves-bg-rev.jpg\";s:8:\"filesize\";i:38440;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
452,
3716,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
453,
3716,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
454,
3716,
'_astra_sites_image_hash',
'148ecfaf9fc39b1b23a81e90525c5761e27d026d'
/* VALUES END */
), (
/* VALUES START */
455,
3716,
'_elementor_source_image_hash',
'148ecfaf9fc39b1b23a81e90525c5761e27d026d'
/* VALUES END */
), (
/* VALUES START */
456,
3822,
'_wp_attached_file',
'2020/09/star-icon.png'
/* VALUES END */
), (
/* VALUES START */
457,
3822,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:100;s:6:\"height\";i:16;s:4:\"file\";s:21:\"2020/09/star-icon.png\";s:8:\"filesize\";i:251;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
460,
3822,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
461,
3822,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
462,
3822,
'_astra_sites_image_hash',
'91eb49ac2054064eda29a42ec9d94f13ff9f6fc3'
/* VALUES END */
), (
/* VALUES START */
463,
3822,
'_elementor_source_image_hash',
'91eb49ac2054064eda29a42ec9d94f13ff9f6fc3'
/* VALUES END */
), (
/* VALUES START */
464,
3847,
'_wp_attached_file',
'2020/09/phone.png'
/* VALUES END */
), (
/* VALUES START */
465,
3847,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:64;s:6:\"height\";i:64;s:4:\"file\";s:17:\"2020/09/phone.png\";s:8:\"filesize\";i:1064;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
468,
3847,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
469,
3847,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
470,
3847,
'_astra_sites_image_hash',
'20b17807598afd0f26edd1b05f27671a4abdde64'
/* VALUES END */
), (
/* VALUES START */
471,
3847,
'_elementor_source_image_hash',
'20b17807598afd0f26edd1b05f27671a4abdde64'
/* VALUES END */
), (
/* VALUES START */
472,
3853,
'_wp_attached_file',
'2020/09/mail-us.png'
/* VALUES END */
), (
/* VALUES START */
473,
3853,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:64;s:6:\"height\";i:48;s:4:\"file\";s:19:\"2020/09/mail-us.png\";s:8:\"filesize\";i:991;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
476,
3853,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
477,
3853,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
478,
3853,
'_astra_sites_image_hash',
'ec1a19c5870c7837fcdb0d3ec6f79269fcddbaa0'
/* VALUES END */
), (
/* VALUES START */
479,
3853,
'_elementor_source_image_hash',
'ec1a19c5870c7837fcdb0d3ec6f79269fcddbaa0'
/* VALUES END */
), (
/* VALUES START */
480,
3856,
'_wp_attached_file',
'2020/09/address.png'
/* VALUES END */
), (
/* VALUES START */
481,
3856,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:64;s:6:\"height\";i:64;s:4:\"file\";s:19:\"2020/09/address.png\";s:8:\"filesize\";i:1229;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
484,
3856,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
485,
3856,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
486,
3856,
'_astra_sites_image_hash',
'a4c86d9d864a357a41780936988aa3b426963125'
/* VALUES END */
), (
/* VALUES START */
487,
3856,
'_elementor_source_image_hash',
'a4c86d9d864a357a41780936988aa3b426963125'
/* VALUES END */
), (
/* VALUES START */
488,
3949,
'_wp_attached_file',
'2021/03/eggs.jpg'
/* VALUES END */
), (
/* VALUES START */
489,
3949,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:16:\"2021/03/eggs.jpg\";s:8:\"filesize\";i:218258;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
490,
3949,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
491,
3949,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
492,
3949,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
493,
3949,
'_astra_sites_image_hash',
'ebb9324dd12e6e25a683d85334e81524747c037e'
/* VALUES END */
), (
/* VALUES START */
494,
3949,
'_elementor_source_image_hash',
'ebb9324dd12e6e25a683d85334e81524747c037e'
/* VALUES END */
), (
/* VALUES START */
495,
3616,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
496,
3616,
'_menu_item_object_id',
3614
/* VALUES END */
), (
/* VALUES START */
497,
3616,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
498,
3616,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
499,
3616,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
501,
3616,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
502,
3616,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
503,
3617,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
504,
3617,
'_menu_item_object_id',
3612
/* VALUES END */
), (
/* VALUES START */
505,
3617,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
506,
3617,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
507,
3617,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
509,
3617,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
510,
3617,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
511,
3618,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
512,
3618,
'_menu_item_object_id',
3610
/* VALUES END */
), (
/* VALUES START */
513,
3618,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
514,
3618,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
515,
3618,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
517,
3618,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
518,
3618,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
519,
3619,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
520,
3619,
'_menu_item_menu_item_parent',
3622
/* VALUES END */
), (
/* VALUES START */
521,
3619,
'_menu_item_object_id',
3607
/* VALUES END */
), (
/* VALUES START */
522,
3619,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
523,
3619,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
524,
3619,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
526,
3619,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
527,
3619,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
528,
3620,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
529,
3620,
'_menu_item_menu_item_parent',
3622
/* VALUES END */
), (
/* VALUES START */
530,
3620,
'_menu_item_object_id',
3605
/* VALUES END */
), (
/* VALUES START */
531,
3620,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
532,
3620,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
533,
3620,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
535,
3620,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
536,
3620,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
537,
3621,
'_menu_item_type',
'post_type'
/* VALUES END */
), (
/* VALUES START */
538,
3621,
'_menu_item_object_id',
3604
/* VALUES END */
), (
/* VALUES START */
539,
3621,
'_menu_item_object',
'page'
/* VALUES END */
), (
/* VALUES START */
540,
3621,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
541,
3621,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
543,
3621,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
544,
3621,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
545,
3633,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
546,
3633,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
547,
3633,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
548,
3950,
'_wp_attached_file',
'2021/03/face-wash.jpg'
/* VALUES END */
), (
/* VALUES START */
549,
3950,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2021/03/face-wash.jpg\";s:8:\"filesize\";i:133425;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
550,
3950,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
551,
3950,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
552,
3950,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
553,
3950,
'_astra_sites_image_hash',
'c9f917913fa00dbb8f8fc71cb633bd422b734842'
/* VALUES END */
), (
/* VALUES START */
554,
3950,
'_elementor_source_image_hash',
'c9f917913fa00dbb8f8fc71cb633bd422b734842'
/* VALUES END */
), (
/* VALUES START */
555,
3951,
'_wp_attached_file',
'2021/03/orage-juice-kariz.jpg'
/* VALUES END */
), (
/* VALUES START */
556,
3951,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:29:\"2021/03/orage-juice-kariz.jpg\";s:8:\"filesize\";i:354166;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
557,
3951,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
558,
3951,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
559,
3951,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
560,
3951,
'_astra_sites_image_hash',
'03b089c997081de79ae243534e2c2e7bfe16396d'
/* VALUES END */
), (
/* VALUES START */
561,
3951,
'_elementor_source_image_hash',
'03b089c997081de79ae243534e2c2e7bfe16396d'
/* VALUES END */
), (
/* VALUES START */
562,
3952,
'_wp_attached_file',
'2021/03/organic-honey.jpg'
/* VALUES END */
), (
/* VALUES START */
563,
3952,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:25:\"2021/03/organic-honey.jpg\";s:8:\"filesize\";i:285467;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
564,
3952,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
565,
3952,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
566,
3952,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
567,
3952,
'_astra_sites_image_hash',
'a6a60ee2e1643becca3f4268423fe554ebda0cfa'
/* VALUES END */
), (
/* VALUES START */
568,
3952,
'_elementor_source_image_hash',
'a6a60ee2e1643becca3f4268423fe554ebda0cfa'
/* VALUES END */
), (
/* VALUES START */
569,
3953,
'_wp_attached_file',
'2021/03/organic-products-hero.png'
/* VALUES END */
), (
/* VALUES START */
570,
3953,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:634;s:6:\"height\";i:543;s:4:\"file\";s:33:\"2021/03/organic-products-hero.png\";s:8:\"filesize\";i:479534;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
571,
3953,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1629701265\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
572,
3953,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
573,
3953,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
574,
3953,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
575,
3953,
'_astra_sites_image_hash',
'3c717ae799ffd27a671f050ce2eba79870ee33cd'
/* VALUES END */
), (
/* VALUES START */
576,
3953,
'_elementor_source_image_hash',
'3c717ae799ffd27a671f050ce2eba79870ee33cd'
/* VALUES END */
), (
/* VALUES START */
577,
3954,
'_wp_attached_file',
'2021/03/pulses.jpg'
/* VALUES END */
), (
/* VALUES START */
578,
3954,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:18:\"2021/03/pulses.jpg\";s:8:\"filesize\";i:224803;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
579,
3954,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
580,
3954,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
581,
3954,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
582,
3954,
'_astra_sites_image_hash',
'f4c54563d7e7f32bc29d2ec07639bf900b386ab7'
/* VALUES END */
), (
/* VALUES START */
583,
3954,
'_elementor_source_image_hash',
'f4c54563d7e7f32bc29d2ec07639bf900b386ab7'
/* VALUES END */
), (
/* VALUES START */
584,
3955,
'_wp_attached_file',
'2021/03/red-chillies.jpg'
/* VALUES END */
), (
/* VALUES START */
585,
3955,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:24:\"2021/03/red-chillies.jpg\";s:8:\"filesize\";i:264009;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
586,
3955,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
587,
3955,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
588,
3955,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
589,
3955,
'_astra_sites_image_hash',
'a855c2db8f53eeca52c0041a7caf29e3849727b7'
/* VALUES END */
), (
/* VALUES START */
590,
3955,
'_elementor_source_image_hash',
'a855c2db8f53eeca52c0041a7caf29e3849727b7'
/* VALUES END */
), (
/* VALUES START */
591,
3956,
'_wp_attached_file',
'2021/03/sanitizer.jpg'
/* VALUES END */
), (
/* VALUES START */
592,
3956,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2021/03/sanitizer.jpg\";s:8:\"filesize\";i:151204;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
593,
3956,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
594,
3956,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
595,
3956,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
596,
3956,
'_astra_sites_image_hash',
'017a0cb9f9c3ccfa6769dddbe6bced0a6ea99cb1'
/* VALUES END */
), (
/* VALUES START */
597,
3956,
'_elementor_source_image_hash',
'017a0cb9f9c3ccfa6769dddbe6bced0a6ea99cb1'
/* VALUES END */
), (
/* VALUES START */
598,
3957,
'_wp_attached_file',
'2021/03/wheat.jpg'
/* VALUES END */
), (
/* VALUES START */
599,
3957,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:17:\"2021/03/wheat.jpg\";s:8:\"filesize\";i:282023;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
600,
3957,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
601,
3957,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
602,
3957,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
603,
3957,
'_astra_sites_image_hash',
'0bfd5e881d1c9f92451ab16eb13ffb51a6cdd386'
/* VALUES END */
), (
/* VALUES START */
604,
3957,
'_elementor_source_image_hash',
'0bfd5e881d1c9f92451ab16eb13ffb51a6cdd386'
/* VALUES END */
), (
/* VALUES START */
605,
3958,
'_wp_attached_file',
'2021/03/basil-leaf.png'
/* VALUES END */
), (
/* VALUES START */
606,
3958,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:209;s:6:\"height\";i:90;s:4:\"file\";s:22:\"2021/03/basil-leaf.png\";s:8:\"filesize\";i:37520;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
607,
3958,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
608,
3958,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
609,
3958,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
610,
3958,
'_astra_sites_image_hash',
'29286716f98b11a34f3ebb9716741c15a44b8fc7'
/* VALUES END */
), (
/* VALUES START */
611,
3958,
'_elementor_source_image_hash',
'29286716f98b11a34f3ebb9716741c15a44b8fc7'
/* VALUES END */
), (
/* VALUES START */
612,
3959,
'_wp_attached_file',
'2021/03/cashew-butter-500.jpg'
/* VALUES END */
), (
/* VALUES START */
613,
3959,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:29:\"2021/03/cashew-butter-500.jpg\";s:8:\"filesize\";i:320062;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
614,
3959,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
615,
3959,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
616,
3959,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
617,
3959,
'_astra_sites_image_hash',
'b4f7d2e072677b4e018312eb9b42f54a2d941646'
/* VALUES END */
), (
/* VALUES START */
618,
3959,
'_elementor_source_image_hash',
'b4f7d2e072677b4e018312eb9b42f54a2d941646'
/* VALUES END */
), (
/* VALUES START */
619,
3960,
'_wp_attached_file',
'2021/03/coffee-asorted.jpg'
/* VALUES END */
), (
/* VALUES START */
620,
3960,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:26:\"2021/03/coffee-asorted.jpg\";s:8:\"filesize\";i:235135;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
621,
3960,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
622,
3960,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
623,
3960,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
624,
3960,
'_astra_sites_image_hash',
'f9d245a254617a730e03d72d1805c93c6da8ae8c'
/* VALUES END */
), (
/* VALUES START */
625,
3960,
'_elementor_source_image_hash',
'f9d245a254617a730e03d72d1805c93c6da8ae8c'
/* VALUES END */
), (
/* VALUES START */
626,
3961,
'_wp_attached_file',
'2021/03/diabetic-cookies.jpg'
/* VALUES END */
), (
/* VALUES START */
627,
3961,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:28:\"2021/03/diabetic-cookies.jpg\";s:8:\"filesize\";i:390871;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
628,
3961,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
629,
3961,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
630,
3961,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
631,
3961,
'_astra_sites_image_hash',
'8225af22877c4a0e054b717757804f3dd920fd4e'
/* VALUES END */
), (
/* VALUES START */
632,
3961,
'_elementor_source_image_hash',
'8225af22877c4a0e054b717757804f3dd920fd4e'
/* VALUES END */
), (
/* VALUES START */
633,
3962,
'_wp_attached_file',
'2021/03/edible-oil.jpg'
/* VALUES END */
), (
/* VALUES START */
634,
3962,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1000;s:6:\"height\";i:1000;s:4:\"file\";s:22:\"2021/03/edible-oil.jpg\";s:8:\"filesize\";i:198977;s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
635,
3962,
'_wxr_import_user_slug',
'harshadd'
/* VALUES END */
), (
/* VALUES START */
636,
3962,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
637,
3962,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
638,
3962,
'_astra_sites_image_hash',
'62253c70359a2a27a9d59e7825e0f76ce59f7842'
/* VALUES END */
), (
/* VALUES START */
639,
3962,
'_elementor_source_image_hash',
'62253c70359a2a27a9d59e7825e0f76ce59f7842'
/* VALUES END */
), (
/* VALUES START */
640,
3604,
'skip_page',
1
/* VALUES END */
), (
/* VALUES START */
642,
3604,
'_wxr_import_user_slug',
'brainstormforce'
/* VALUES END */
), (
/* VALUES START */
643,
3604,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
644,
3604,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
645,
3605,
'skip_page',
1
/* VALUES END */
), (
/* VALUES START */
647,
3605,
'_wxr_import_user_slug',
'brainstormforce'
/* VALUES END */
), (
/* VALUES START */
648,
3605,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
649,
3605,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
650,
3606,
'skip_page',
1
/* VALUES END */
), (
/* VALUES START */
652,
3606,
'_wxr_import_user_slug',
'brainstormforce'
/* VALUES END */
), (
/* VALUES START */
653,
3606,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
654,
3606,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
655,
3607,
'skip_page',
1
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
657,
3607,
'_wxr_import_user_slug',
'brainstormforce'
/* VALUES END */
), (
/* VALUES START */
658,
3607,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
659,
3607,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
660,
3610,
'site-sidebar-layout',
'no-sidebar'
/* VALUES END */
), (
/* VALUES START */
661,
3610,
'site-content-layout',
'plain-container'
/* VALUES END */
), (
/* VALUES START */
662,
3610,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
663,
3610,
'site-post-title',
'disabled'
/* VALUES END */
), (
/* VALUES START */
664,
3610,
'ast-featured-img',
'disabled'
/* VALUES END */
), (
/* VALUES START */
665,
3610,
'_yoast_wpseo_content_score',
90
/* VALUES END */
), (
/* VALUES START */
666,
3610,
'astra-main-page-id',
48124
/* VALUES END */
), (
/* VALUES START */
667,
3610,
'dynamic_page',
1
/* VALUES END */
), (
/* VALUES START */
668,
3610,
'_yoast_wpseo_estimated-reading-time-minutes',
5
/* VALUES END */
), (
/* VALUES START */
669,
3610,
'ast_ist_mapping',
'O:8:\"stdClass\":0:{}'
/* VALUES END */
), (
/* VALUES START */
670,
3610,
'ast_self_id_48124',
1
/* VALUES END */
), (
/* VALUES START */
673,
3610,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
674,
3610,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
675,
3610,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
676,
3612,
'site-sidebar-layout',
'no-sidebar'
/* VALUES END */
), (
/* VALUES START */
677,
3612,
'site-content-layout',
'plain-container'
/* VALUES END */
), (
/* VALUES START */
678,
3612,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
679,
3612,
'site-post-title',
'disabled'
/* VALUES END */
), (
/* VALUES START */
680,
3612,
'ast-featured-img',
'disabled'
/* VALUES END */
), (
/* VALUES START */
681,
3612,
'_yoast_wpseo_content_score',
90
/* VALUES END */
), (
/* VALUES START */
682,
3612,
'astra-main-page-id',
48122
/* VALUES END */
), (
/* VALUES START */
683,
3612,
'_yoast_wpseo_estimated-reading-time-minutes',
2
/* VALUES END */
), (
/* VALUES START */
684,
3612,
'ast_ist_mapping',
'O:8:\"stdClass\":0:{}'
/* VALUES END */
), (
/* VALUES START */
685,
3612,
'ast_self_id_48122',
1
/* VALUES END */
), (
/* VALUES START */
688,
3612,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
689,
3612,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
690,
3612,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
691,
3614,
'site-sidebar-layout',
'no-sidebar'
/* VALUES END */
), (
/* VALUES START */
692,
3614,
'site-content-layout',
'plain-container'
/* VALUES END */
), (
/* VALUES START */
693,
3614,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
694,
3614,
'site-post-title',
'disabled'
/* VALUES END */
), (
/* VALUES START */
695,
3614,
'ast-featured-img',
'disabled'
/* VALUES END */
), (
/* VALUES START */
696,
3614,
'_yoast_wpseo_content_score',
60
/* VALUES END */
), (
/* VALUES START */
697,
3614,
'astra-main-page-id',
48123
/* VALUES END */
), (
/* VALUES START */
698,
3614,
'_yoast_wpseo_estimated-reading-time-minutes',
2
/* VALUES END */
), (
/* VALUES START */
699,
3614,
'ast_ist_mapping',
'O:8:\"stdClass\":0:{}'
/* VALUES END */
), (
/* VALUES START */
700,
3614,
'ast_self_id_48123',
1
/* VALUES END */
), (
/* VALUES START */
703,
3614,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
704,
3614,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
705,
3614,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
706,
3622,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
707,
3622,
'_menu_item_object_id',
3622
/* VALUES END */
), (
/* VALUES START */
708,
3622,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
709,
3622,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
710,
3622,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
711,
3622,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
712,
3622,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
713,
3622,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
760,
3673,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
761,
3673,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
762,
3673,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
763,
3673,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
764,
3673,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
765,
3673,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
766,
3673,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
767,
3673,
'_product_version',
'5.0.0'
/* VALUES END */
), (
/* VALUES START */
768,
3673,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
769,
3673,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
770,
3673,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
771,
3673,
'_yoast_wpseo_content_score',
30
/* VALUES END */
), (
/* VALUES START */
772,
3673,
'_wxr_import_user_slug',
'ramak'
/* VALUES END */
), (
/* VALUES START */
773,
3673,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
774,
3673,
'_wp_old_slug',
'import-placeholder-for-161'
/* VALUES END */
), (
/* VALUES START */
775,
3673,
'_regular_price',
35
/* VALUES END */
), (
/* VALUES START */
776,
3673,
'_sale_price',
25
/* VALUES END */
), (
/* VALUES START */
777,
3673,
'_thumbnail_id',
3961
/* VALUES END */
), (
/* VALUES START */
778,
3673,
'_price',
25
/* VALUES END */
), (
/* VALUES START */
779,
3673,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
780,
3673,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
781,
3673,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
782,
3674,
'total_sales',
1
/* VALUES END */
), (
/* VALUES START */
783,
3674,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
784,
3674,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
785,
3674,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
786,
3674,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
787,
3674,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
788,
3674,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
789,
3674,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
790,
3674,
'_product_version',
'5.0.0'
/* VALUES END */
), (
/* VALUES START */
791,
3674,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
792,
3674,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
793,
3674,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
794,
3674,
'_yoast_wpseo_content_score',
30
/* VALUES END */
), (
/* VALUES START */
795,
3674,
'_wxr_import_user_slug',
'ramak'
/* VALUES END */
), (
/* VALUES START */
796,
3674,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
797,
3674,
'_wp_old_slug',
'import-placeholder-for-167'
/* VALUES END */
), (
/* VALUES START */
798,
3674,
'_regular_price',
34
/* VALUES END */
), (
/* VALUES START */
799,
3674,
'_thumbnail_id',
3957
/* VALUES END */
), (
/* VALUES START */
800,
3674,
'_price',
34
/* VALUES END */
), (
/* VALUES START */
801,
3674,
'_wp_old_slug',
'black-lentils'
/* VALUES END */
), (
/* VALUES START */
802,
3674,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
803,
3674,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
804,
3674,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
805,
3770,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
806,
3770,
'_menu_item_object_id',
3770
/* VALUES END */
), (
/* VALUES START */
807,
3770,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
808,
3770,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
809,
3770,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
810,
3770,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
811,
3770,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
812,
3770,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
813,
3771,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
814,
3771,
'_menu_item_object_id',
3771
/* VALUES END */
), (
/* VALUES START */
815,
3771,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
816,
3771,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
817,
3771,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
818,
3771,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
819,
3771,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
820,
3771,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
821,
3772,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
822,
3772,
'_menu_item_object_id',
3772
/* VALUES END */
), (
/* VALUES START */
823,
3772,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
824,
3772,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
825,
3772,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
826,
3772,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
827,
3772,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
828,
3772,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
829,
3773,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
830,
3773,
'_menu_item_object_id',
3773
/* VALUES END */
), (
/* VALUES START */
831,
3773,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
832,
3773,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
833,
3773,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
834,
3773,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
835,
3773,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
836,
3773,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
837,
3781,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
838,
3781,
'_menu_item_object_id',
3781
/* VALUES END */
), (
/* VALUES START */
839,
3781,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
840,
3781,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
841,
3781,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
842,
3781,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
843,
3781,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
844,
3781,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
845,
3782,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
846,
3782,
'_menu_item_object_id',
3782
/* VALUES END */
), (
/* VALUES START */
847,
3782,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
848,
3782,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
849,
3782,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
850,
3782,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
851,
3782,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
852,
3782,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
853,
3783,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
854,
3783,
'_menu_item_object_id',
3783
/* VALUES END */
), (
/* VALUES START */
855,
3783,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
856,
3783,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
857,
3783,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
858,
3783,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
859,
3783,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
860,
3783,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
861,
3784,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
862,
3784,
'_menu_item_object_id',
3784
/* VALUES END */
), (
/* VALUES START */
863,
3784,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
864,
3784,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
865,
3784,
'_menu_item_url',
'#'
/* VALUES END */
), (
/* VALUES START */
866,
3784,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
867,
3784,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
868,
3784,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
891,
3676,
'total_sales',
12003
/* VALUES END */
), (
/* VALUES START */
892,
3676,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
893,
3676,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
894,
3676,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
895,
3676,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
896,
3676,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
897,
3676,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
898,
3676,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
899,
3676,
'_product_version',
'5.0.0'
/* VALUES END */
), (
/* VALUES START */
900,
3676,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
901,
3676,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
902,
3676,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
903,
3676,
'_yoast_wpseo_content_score',
30
/* VALUES END */
), (
/* VALUES START */
904,
3676,
'_wxr_import_user_slug',
'ramak'
/* VALUES END */
), (
/* VALUES START */
905,
3676,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
906,
3676,
'_wp_old_slug',
'import-placeholder-for-170'
/* VALUES END */
), (
/* VALUES START */
907,
3676,
'_regular_price',
34
/* VALUES END */
), (
/* VALUES START */
908,
3676,
'_sale_price',
25
/* VALUES END */
), (
/* VALUES START */
909,
3676,
'_thumbnail_id',
3962
/* VALUES END */
), (
/* VALUES START */
910,
3676,
'_price',
25
/* VALUES END */
), (
/* VALUES START */
911,
3676,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
912,
3676,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
913,
3676,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
914,
3677,
'total_sales',
1106
/* VALUES END */
), (
/* VALUES START */
915,
3677,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
916,
3677,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
917,
3677,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
918,
3677,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
919,
3677,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
920,
3677,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
921,
3677,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
922,
3677,
'_product_version',
'5.0.0'
/* VALUES END */
), (
/* VALUES START */
923,
3677,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
924,
3677,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
925,
3677,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
926,
3677,
'_yoast_wpseo_content_score',
30
/* VALUES END */
), (
/* VALUES START */
927,
3677,
'_wxr_import_user_slug',
'ramak'
/* VALUES END */
), (
/* VALUES START */
928,
3677,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
929,
3677,
'_wp_old_slug',
'import-placeholder-for-171'
/* VALUES END */
), (
/* VALUES START */
930,
3677,
'_regular_price',
34
/* VALUES END */
), (
/* VALUES START */
931,
3677,
'_thumbnail_id',
3952
/* VALUES END */
), (
/* VALUES START */
932,
3677,
'_price',
34
/* VALUES END */
), (
/* VALUES START */
933,
3677,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
934,
3677,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
935,
3677,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
1005,
3681,
'total_sales',
3
/* VALUES END */
), (
/* VALUES START */
1006,
3681,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
1007,
3681,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
1008,
3681,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
1009,
3681,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
1010,
3681,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
1011,
3681,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
1012,
3681,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
1013,
3681,
'_product_version',
'5.0.0'
/* VALUES END */
), (
/* VALUES START */
1014,
3681,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1015,
3681,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1016,
3681,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
1017,
3681,
'_yoast_wpseo_content_score',
30
/* VALUES END */
), (
/* VALUES START */
1018,
3681,
'_wxr_import_user_slug',
'ramak'
/* VALUES END */
), (
/* VALUES START */
1019,
3681,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
1020,
3681,
'_wp_old_slug',
'import-placeholder-for-243'
/* VALUES END */
), (
/* VALUES START */
1021,
3681,
'_regular_price',
15
/* VALUES END */
), (
/* VALUES START */
1022,
3681,
'_thumbnail_id',
3954
/* VALUES END */
), (
/* VALUES START */
1023,
3681,
'_price',
15
/* VALUES END */
), (
/* VALUES START */
1024,
3681,
'_wp_old_slug',
'assorted-dry-fruits'
/* VALUES END */
), (
/* VALUES START */
1025,
3681,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1026,
3681,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
1027,
3681,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
1028,
3682,
'total_sales',
4
/* VALUES END */
), (
/* VALUES START */
1029,
3682,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
1030,
3682,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
1031,
3682,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
1032,
3682,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
1033,
3682,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
1034,
3682,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
1035,
3682,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
1036,
3682,
'_product_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1037,
3682,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1038,
3682,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1039,
3682,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
1040,
3682,
'_yoast_wpseo_content_score',
30
/* VALUES END */
), (
/* VALUES START */
1041,
3682,
'_wxr_import_user_slug',
'ramak'
/* VALUES END */
), (
/* VALUES START */
1042,
3682,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
1043,
3682,
'_yoast_wpseo_primary_product_cat',
43
/* VALUES END */
), (
/* VALUES START */
1044,
3682,
'_wp_old_slug',
'import-placeholder-for-245'
/* VALUES END */
), (
/* VALUES START */
1045,
3682,
'_regular_price',
19
/* VALUES END */
), (
/* VALUES START */
1046,
3682,
'_thumbnail_id',
3955
/* VALUES END */
), (
/* VALUES START */
1047,
3682,
'_price',
19
/* VALUES END */
), (
/* VALUES START */
1048,
3682,
'_wp_old_slug',
'organic-handpicked-coffee'
/* VALUES END */
), (
/* VALUES START */
1050,
3682,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
1051,
3682,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
1052,
3907,
'_wxr_import_user_slug',
'rishabhm'
/* VALUES END */
), (
/* VALUES START */
1053,
3907,
'_astra_sites_imported_post',
1
/* VALUES END */
), (
/* VALUES START */
1054,
3907,
'_astra_sites_enable_for_batch',
1
/* VALUES END */
), (
/* VALUES START */
1057,
3610,
'_edit_lock',
'1656419547:1'
/* VALUES END */
), (
/* VALUES START */
1058,
3604,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1059,
3612,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:761:\".uag-star-rating__wrapper{display:flex;align-items:center}.uag-star-rating__wrapper.uag-star-rating__layout-stack{display:block}.uag-star-rating__wrapper .uag-star-rating__title{margin:0}.uag-star-rating__wrapper .uag-star{color:#ccd6df}\n .uagb-block-6bb92ce3 .uag-star-rating{font-size: 20px;} .uagb-block-6bb92ce3 .uag-star-rating > span{color: #ccd6df;} .uagb-block-6bb92ce3 .uag-star:nth-child(-n+5){color: #f0ad4e;} .uagb-block-6bb92ce3 .uag-star-rating__title{margin-right: 10px;} .uagb-block-6bb92ce3.uag-star-rating__wrapper{justify-content: center;text-align: center;} .uagb-block-6bb92ce3 .uag-star:nth-child(5):before{color: #f0ad4e;position: absolute;content: \'★\';overflow: hidden;} .uagb-block-6bb92ce3 .uag-star:nth-child(5){position: relative;}\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:12:{i:0;s:11:\"core/spacer\";i:1;s:10:\"core/group\";i:2;s:12:\"core/heading\";i:4;s:15:\"core/media-text\";i:5;s:14:\"core/paragraph\";i:7;s:12:\"core/columns\";i:8;s:11:\"core/column\";i:13;s:10:\"core/image\";i:15;s:16:\"uagb/star-rating\";i:18;s:9:\"core/list\";i:19;s:12:\"core/buttons\";i:20;s:11:\"core/button\";}s:8:\"uag_flag\";b:1;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1060,
3612,
'_uag_css_file_name',
'uag-css-3612-1655100365.css'
/* VALUES END */
), (
/* VALUES START */
1061,
3614,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:13429:\".uagb-ifb-icon-wrap,.uagb-ifb-icon-wrap *{-webkit-transition:all 0.2s;-o-transition:all 0.2s;transition:all 0.2s}.uagb-ifb-icon-wrap .uagb-ifb-icon,.uagb-ifb-content{display:inline-block}.uagb-ifb-icon svg{width:inherit;height:inherit;vertical-align:middle}.infobox-icon-above-title .uagb-ifb-left-right-wrap{text-align:center}a.uagb-infobox-cta-link span{font-size:inherit}.uagb-ifb-cta.uagb-infobox-cta-link-style:empty{display:none}a.uagb-infobox-cta-link,.entry .entry-content a.uagb-infobox-cta-link,a.uagb-infobox-link-wrap,.entry .entry-content a.uagb-infobox-link-wrap{text-decoration:none}a.uagb-infobox-cta-link:hover,.entry .entry-content a.uagb-infobox-cta-link:hover,a.uagb-infobox-link-wrap:hover,.entry .entry-content a.uagb-infobox-link-wrap:hover .entry .entry-content a.uagb-infobox-cta-link:hover{color:inherit}.uagb-infobox-icon-left-title.uagb-infobox-image-valign-middle .uagb-ifb-title-wrap,.uagb-infobox-icon-right-title.uagb-infobox-image-valign-middle .uagb-ifb-title-wrap,.uagb-infobox-image-valign-middle .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-left.uagb-infobox-image-valign-middle .uagb-ifb-content,.uagb-infobox-icon-right.uagb-infobox-image-valign-middle .uagb-ifb-content{-ms-flex-item-align:center;-webkit-align-self:center;align-self:center}.uagb-infobox-left{text-align:left;-webkit-box-pack:start;-ms-flex-pack:start;-webkit-justify-content:flex-start;-moz-box-pack:start;justify-content:flex-start}.uagb-infobox-center{text-align:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;-moz-box-pack:center;justify-content:center}.uagb-infobox-right{text-align:right;-webkit-box-pack:end;-ms-flex-pack:end;-webkit-justify-content:flex-end;-moz-box-pack:end;justify-content:flex-end}.uagb-ifb-left-right-wrap{width:100%;word-break:break-word}.uagb-infobox-icon-above-title .uagb-ifb-left-right-wrap,.uagb-infobox-icon-below-title .uagb-ifb-left-right-wrap{display:block;min-width:100%;width:100%}.uagb-infobox-icon-left-title .uagb-ifb-icon-wrap,.uagb-infobox-icon-left .uagb-ifb-icon-wrap{margin-right:10px}.uagb-infobox-icon-right-title .uagb-ifb-icon-wrap,.uagb-infobox-icon-right .uagb-ifb-icon-wrap{margin-left:10px}.uagb-infobox-icon-left .uagb-ifb-left-right-wrap,.uagb-infobox-icon-right .uagb-ifb-left-right-wrap,.uagb-infobox-icon-left-title .uagb-ifb-left-title-image,.uagb-infobox-icon-right-title .uagb-ifb-right-title-image{display:-webkit-box;display:-ms-flexbox;-js-display:flex;display:-webkit-flex;display:-moz-box;display:flex}.uagb-infobox-icon-right .uagb-ifb-left-right-wrap,.uagb-infobox-icon-right-title .uagb-ifb-right-title-image{-webkit-box-pack:end;-ms-flex-pack:end;-webkit-justify-content:flex-end;-moz-box-pack:end;justify-content:flex-end}.uagb-ifb-icon-wrap .uagb-ifb-icon span{font-style:initial;height:auto;width:auto}.uagb-ifb-imgicon-wrap .uagb-ifb-image-content{display:inline-block;line-height:0;position:relative;max-width:100%}.uagb-ifb-imgicon-wrap .uagb-ifb-image-content img{display:inline;height:auto !important;max-width:100%;width:auto;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;-webkit-border-radius:inherit;border-radius:inherit}.uagb-ifb-imgicon-wrap .uagb-image-crop-circle img{-webkit-border-radius:100%;border-radius:100%}.uagb-ifb-imgicon-wrap .uagb-image-crop-square img{-webkit-border-radius:0;border-radius:0}.uagb-infobox-module-link{position:absolute;width:100%;height:100%;left:0;top:0;bottom:0;right:0;z-index:4}.uagb-edit-mode .uagb-infobox-module-link{z-index:2}.uagb-infobox-link-icon-after{margin-left:5px;margin-right:0}.uagb-infobox-link-icon-before{margin-left:0;margin-right:5px}.uagb-infobox-link-icon{-webkit-transition:all 200ms linear;transition:all 200ms linear}.uagb-infobox{position:relative}.uagb-ifb-separator{width:30%;border-top-width:2px;border-top-color:#333;border-top-style:solid;display:inline-block;margin:0}.uagb-ifb-separator-parent{line-height:0em;margin-left:0;margin-right:0;margin-bottom:10px}.uagb-ifb-cta-button{display:inline-block;line-height:1;background-color:#818a91;color:#fff;text-align:center}.uagb-ifb-button-wrapper .wp-block-button__link svg{fill:currentColor}.uagb-ifb-cta a{-webkit-box-shadow:none;box-shadow:none;text-decoration:none}.uagb-ifb-title-wrap{width:100%}.uagb-ifb-title-wrap .uagb-ifb-title,.uagb-ifb-title-wrap .uagb-ifb-title-prefix{padding:0;margin:0;display:block}.uagb-infobox__content-wrap.uagb-infobox{position:relative}.uagb-ifb-icon span{font-size:40px;height:40px;color:#333;width:40px}.uagb-ifb-icon svg{fill:#333}.uagb-ifb-content{width:100%}.uagb-infobox__content-wrap.uagb-infobox,.uagb-ifb-content,.uagb-ifb-title-wrap,.uagb-ifb-title-prefix *,svg.dashicon.dashicons-upload{z-index:1}.uagb-ifb-left-right-wrap{z-index:1}.uagb-infobox-cta-link{cursor:pointer}a.uagb-infobox-link-wrap{color:inherit}.uagb-ifb-content p:empty{display:none}.uagb-infobox .uagb-ifb-icon,.uagb-infobox .uagb-ifb-image-content img{display:inline-block;box-sizing:content-box}.uagb-ifb-align-icon-after{margin-left:5px}.uagb-ifb-align-icon-before{margin-right:5px}span.uagb-ifb-button-icon.uagb-ifb-align-icon-after{float:right}.uagb-ifb-button-icon{height:15px;width:15px;font-size:15px;vertical-align:middle}.uagb-ifb-text-icon{height:15px;width:15px;font-size:15px;line-height:15px;vertical-align:middle;display:inline-block}.uagb-ifb-button-icon svg,.uagb-ifb-text-icon svg{height:inherit;width:inherit;display:inline-block}.block-editor-page #wpwrap .uagb-infobox-cta-link svg,.uagb-infobox-cta-link svg{font-style:normal}.uagb-infobox__outer-wrap{position:relative}a.uagb-infbox__link-to-all{height:100%;width:100%;top:0;left:0;position:absolute;z-index:3;-webkit-box-shadow:none;box-shadow:none;text-decoration:none}@media only screen and (max-width: 976px){.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{padding:0;margin-bottom:20px}.uagb-infobox-stacked-tablet.uagb-reverse-order-tablet .uagb-ifb-left-right-wrap{display:-webkit-inline-box;display:-ms-inline-flexbox;-js-display:inline-flex;display:-webkit-inline-flex;display:-moz-inline-box;display:inline-flex;-webkit-box-orient:vertical;-webkit-box-direction:reverse;-ms-flex-direction:column-reverse;-webkit-flex-direction:column-reverse;-moz-box-orient:vertical;-moz-box-direction:reverse;flex-direction:column-reverse}.uagb-infobox.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap .uagb-ifb-content,.uagb-infobox.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{display:block;width:100%;text-align:center}.uagb-infobox.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{margin-left:0px;margin-right:0px}.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap{display:inline-block}.uagb-infobox-icon-left-title.uagb-infobox-stacked-tablet .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-left.uagb-infobox-stacked-tablet .uagb-ifb-imgicon-wrap{margin-right:0px}.uagb-infobox-icon-right-title.uagb-infobox-stacked-tablet .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-right.uagb-infobox-stacked-tablet .uagb-ifb-imgicon-wrap{margin-left:0px}.uagb-infobox-icon-left-title .uagb-ifb-separator-parent{margin:10px 0}}@media screen and (max-width: 767px){.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{padding:0;margin-bottom:20px}.uagb-infobox-stacked-mobile.uagb-reverse-order-mobile .uagb-ifb-left-right-wrap{display:-webkit-inline-box;display:-ms-inline-flexbox;-js-display:inline-flex;display:-webkit-inline-flex;display:-moz-inline-box;display:inline-flex;-webkit-box-orient:vertical;-webkit-box-direction:reverse;-ms-flex-direction:column-reverse;-webkit-flex-direction:column-reverse;-moz-box-orient:vertical;-moz-box-direction:reverse;flex-direction:column-reverse}.uagb-infobox.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap .uagb-ifb-content,.uagb-infobox.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{display:block;width:100%;text-align:center}.uagb-infobox.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{margin-left:0px;margin-right:0px}.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap{display:inline-block}.uagb-infobox-icon-left-title.uagb-infobox-stacked-mobile .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-left.uagb-infobox-stacked-mobile .uagb-ifb-imgicon-wrap{margin-right:0px}.uagb-infobox-icon-right-title.uagb-infobox-stacked-mobile .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-right.uagb-infobox-stacked-mobile .uagb-ifb-imgicon-wrap{margin-left:0px}.uagb-infobox-icon-left-title .uagb-ifb-separator-parent{margin:10px 0}}\n.uagb-block-02b230e2 .uagb-ifb-icon{height: 25px;width: 25px;line-height: 25px;}.uagb-block-02b230e2 .uagb-ifb-icon > span{font-size: 25px;height: 25px;width: 25px;line-height: 25px;color: var(--ast-global-color-0);}.uagb-block-02b230e2 .uagb-ifb-icon svg{fill: var(--ast-global-color-0);}.uagb-block-02b230e2 .uagb-infobox__content-wrap .uagb-ifb-imgicon-wrap{margin-left: 5px;margin-right: 10px;margin-top: 5px;margin-bottom: 20px;}.uagb-block-02b230e2 .uagb-ifb-title-prefix{margin-bottom: 5px;}.uagb-block-02b230e2 .uagb-ifb-title-wrap .uagb-ifb-title{margin-bottom: 10px;}.uagb-block-02b230e2 .uagb-ifb-text-wrap .uagb-ifb-desc{color: var(--ast-global-color-5);margin-bottom: 10px;}.uagb-block-02b230e2 .uagb-ifb-separator{width: 30%;border-top-width: 2px;border-top-color: #333;border-top-style: none;}.uagb-block-02b230e2 .uagb-ifb-separator-parent{margin-bottom: 15px;}.uagb-block-02b230e2 .uagb-ifb-align-icon-after{margin-left: 5px;}.uagb-block-02b230e2 .uagb-ifb-align-icon-before{margin-right: 5px;}.uagb-block-02b230e2 .uagb-infobox-cta-link{color: #333;}.uagb-block-02b230e2 .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-02b230e2 .uagb-ifb-button-wrapper .uagb-infobox-cta-link{color: #333;background-color: transparent;border-style: solid;border-color: #333;border-width: 1px;padding-top: 10px;padding-bottom: 10px;padding-left: 14px;padding-right: 14px;}.uagb-block-02b230e2 .uagb-ifb-button-wrapper .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-02b230e2 .uagb-ifb-image-content > img{width: 120px;max-width: 120px;}.uagb-block-02b230e2 .uagb-infobox__content-wrap{text-align: center;}.uagb-block-574e18f3 .uagb-ifb-icon{height: 25px;width: 25px;line-height: 25px;}.uagb-block-574e18f3 .uagb-ifb-icon > span{font-size: 25px;height: 25px;width: 25px;line-height: 25px;color: var(--ast-global-color-0);}.uagb-block-574e18f3 .uagb-ifb-icon svg{fill: var(--ast-global-color-0);}.uagb-block-574e18f3 .uagb-infobox__content-wrap .uagb-ifb-imgicon-wrap{margin-left: 5px;margin-right: 10px;margin-top: 5px;margin-bottom: 20px;}.uagb-block-574e18f3 .uagb-ifb-title-prefix{margin-bottom: 5px;}.uagb-block-574e18f3 .uagb-ifb-title-wrap .uagb-ifb-title{margin-bottom: 10px;}.uagb-block-574e18f3 .uagb-ifb-text-wrap .uagb-ifb-desc{color: var(--ast-global-color-5);margin-bottom: 10px;}.uagb-block-574e18f3 .uagb-ifb-separator{width: 30%;border-top-width: 2px;border-top-color: #333;border-top-style: none;}.uagb-block-574e18f3 .uagb-ifb-separator-parent{margin-bottom: 15px;}.uagb-block-574e18f3 .uagb-ifb-align-icon-after{margin-left: 5px;}.uagb-block-574e18f3 .uagb-ifb-align-icon-before{margin-right: 5px;}.uagb-block-574e18f3 .uagb-infobox-cta-link{color: #333;}.uagb-block-574e18f3 .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-574e18f3 .uagb-ifb-button-wrapper .uagb-infobox-cta-link{color: #333;background-color: transparent;border-style: solid;border-color: #333;border-width: 1px;padding-top: 10px;padding-bottom: 10px;padding-left: 14px;padding-right: 14px;}.uagb-block-574e18f3 .uagb-ifb-button-wrapper .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-574e18f3 .uagb-ifb-image-content > img{width: 120px;max-width: 120px;}.uagb-block-574e18f3 .uagb-infobox__content-wrap{text-align: center;}.uagb-block-49ed56d7 .uagb-ifb-icon{height: 25px;width: 25px;line-height: 25px;}.uagb-block-49ed56d7 .uagb-ifb-icon > span{font-size: 25px;height: 25px;width: 25px;line-height: 25px;color: var(--ast-global-color-0);}.uagb-block-49ed56d7 .uagb-ifb-icon svg{fill: var(--ast-global-color-0);}.uagb-block-49ed56d7 .uagb-infobox__content-wrap .uagb-ifb-imgicon-wrap{margin-left: 5px;margin-right: 10px;margin-top: 5px;margin-bottom: 20px;}.uagb-block-49ed56d7 .uagb-ifb-title-prefix{margin-bottom: 5px;}.uagb-block-49ed56d7 .uagb-ifb-title-wrap .uagb-ifb-title{margin-bottom: 10px;}.uagb-block-49ed56d7 .uagb-ifb-text-wrap .uagb-ifb-desc{color: var(--ast-global-color-5);margin-bottom: 10px;}.uagb-block-49ed56d7 .uagb-ifb-separator{width: 30%;border-top-width: 2px;border-top-color: #333;border-top-style: none;}.uagb-block-49ed56d7 .uagb-ifb-separator-parent{margin-bottom: 15px;}.uagb-block-49ed56d7 .uagb-ifb-align-icon-after{margin-left: 5px;}.uagb-block-49ed56d7 .uagb-ifb-align-icon-before{margin-right: 5px;}.uagb-block-49ed56d7 .uagb-infobox-cta-link{color: #333;}.uagb-block-49ed56d7 .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-49ed56d7 .uagb-ifb-button-wrapper .uagb-infobox-cta-link{color: #333;background-color: transparent;border-style: solid;border-color: #333;border-width: 1px;padding-top: 10px;padding-bottom: 10px;padding-left: 14px;padding-right: 14px;}.uagb-block-49ed56d7 .uagb-ifb-button-wrapper .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-49ed56d7 .uagb-ifb-image-content > img{width: 120px;max-width: 120px;}.uagb-block-49ed56d7 .uagb-infobox__content-wrap{text-align: center;}\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:9:{i:0;s:10:\"core/group\";i:1;s:11:\"core/spacer\";i:2;s:12:\"core/heading\";i:4;s:12:\"core/columns\";i:5;s:11:\"core/column\";i:6;s:13:\"uagb/info-box\";i:7;s:10:\"core/cover\";i:8;s:10:\"core/image\";i:9;s:14:\"core/paragraph\";}s:8:\"uag_flag\";b:1;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1062,
3614,
'_uag_css_file_name',
'uag-css-3614-1655100371.css'
/* VALUES END */
), (
/* VALUES START */
1065,
3979,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
1066,
3979,
'_edit_lock',
'1655359977:1'
/* VALUES END */
), (
/* VALUES START */
1067,
3980,
'_wp_attached_file',
'2022/06/apples-red-pair-1506119.jpg'
/* VALUES END */
), (
/* VALUES START */
1068,
3980,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:35:\"2022/06/apples-red-pair-1506119.jpg\";s:8:\"filesize\";i:197795;s:5:\"sizes\";a:2:{s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:35:\"apples-red-pair-1506119-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14086;s:9:\"uncropped\";b:0;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:35:\"apples-red-pair-1506119-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2651;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"9\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:15:\"Canon EOS 1000D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"70\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:4:\"0.01\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1069,
3980,
'_source_url',
'https://pixabay.com/get/ga358ef474248891d7cc28c6b0490652314416511d0a085d760efffd60566a8bcd67c02a48225e394dc54b5167e2b9a8c3ab8798c8585b678ce6291dc7ddb2a8a_1280.jpg'
/* VALUES END */
), (
/* VALUES START */
1070,
3980,
'astra-images',
1506119
/* VALUES END */
), (
/* VALUES START */
1071,
3980,
'_wp_attachment_image_alt',
'apples, red, pair-1506119.jpg'
/* VALUES END */
), (
/* VALUES START */
1072,
3979,
'_thumbnail_id',
3980
/* VALUES END */
), (
/* VALUES START */
1073,
3979,
'_regular_price',
80
/* VALUES END */
), (
/* VALUES START */
1074,
3979,
'_sale_price',
60
/* VALUES END */
), (
/* VALUES START */
1075,
3979,
'total_sales',
10
/* VALUES END */
), (
/* VALUES START */
1076,
3979,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
1077,
3979,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
1078,
3979,
'_manage_stock',
'yes'
/* VALUES END */
), (
/* VALUES START */
1079,
3979,
'_backorders',
'yes'
/* VALUES END */
), (
/* VALUES START */
1080,
3979,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
1081,
3979,
'_weight',
1
/* VALUES END */
), (
/* VALUES START */
1082,
3979,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
1083,
3979,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
1084,
3979,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
1085,
3979,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
1086,
3979,
'_stock',
198
/* VALUES END */
), (
/* VALUES START */
1087,
3979,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
1088,
3979,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
1089,
3979,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
1090,
3979,
'_product_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1091,
3979,
'_price',
60
/* VALUES END */
), (
/* VALUES START */
1092,
3979,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1093,
3979,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1094,
3979,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
1097,
3607,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:1:{i:0;s:14:\"core/shortcode\";}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1100,
3605,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:1:{i:0;s:14:\"core/shortcode\";}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1101,
3606,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:1:{i:0;s:14:\"core/shortcode\";}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1142,
3982,
'_order_key',
'wc_order_HI2347hOhshAR'
/* VALUES END */
), (
/* VALUES START */
1143,
3982,
'_customer_user',
1
/* VALUES END */
), (
/* VALUES START */
1144,
3982,
'_payment_method',
'cod'
/* VALUES END */
), (
/* VALUES START */
1145,
3982,
'_payment_method_title',
'Cash on delivery'
/* VALUES END */
), (
/* VALUES START */
1146,
3982,
'_customer_ip_address',
'::1'
/* VALUES END */
), (
/* VALUES START */
1147,
3982,
'_customer_user_agent',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36'
/* VALUES END */
), (
/* VALUES START */
1148,
3982,
'_created_via',
'checkout'
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1149,
3982,
'_cart_hash',
'a0f0d271f57624a803ab72d14d1e2000'
/* VALUES END */
), (
/* VALUES START */
1150,
3982,
'_billing_first_name',
'Mukul'
/* VALUES END */
), (
/* VALUES START */
1151,
3982,
'_billing_last_name',
'Kumar'
/* VALUES END */
), (
/* VALUES START */
1152,
3982,
'_billing_address_1',
'B-15, Ramnagar Extension, Sodhala, Jaipur'
/* VALUES END */
), (
/* VALUES START */
1153,
3982,
'_billing_address_2',
'Ekadash Kunj Apartment'
/* VALUES END */
), (
/* VALUES START */
1154,
3982,
'_billing_city',
'Jaipur'
/* VALUES END */
), (
/* VALUES START */
1155,
3982,
'_billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
1156,
3982,
'_billing_postcode',
302019
/* VALUES END */
), (
/* VALUES START */
1157,
3982,
'_billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
1158,
3982,
'_billing_email',
'mukulyashi@gmail.com'
/* VALUES END */
), (
/* VALUES START */
1159,
3982,
'_billing_phone',
6350672348
/* VALUES END */
), (
/* VALUES START */
1160,
3982,
'_order_currency',
'INR'
/* VALUES END */
), (
/* VALUES START */
1161,
3982,
'_cart_discount',
0
/* VALUES END */
), (
/* VALUES START */
1162,
3982,
'_cart_discount_tax',
0
/* VALUES END */
), (
/* VALUES START */
1163,
3982,
'_order_shipping',
0
/* VALUES END */
), (
/* VALUES START */
1164,
3982,
'_order_shipping_tax',
0
/* VALUES END */
), (
/* VALUES START */
1165,
3982,
'_order_tax',
0
/* VALUES END */
), (
/* VALUES START */
1166,
3982,
'_order_total',
60
/* VALUES END */
), (
/* VALUES START */
1167,
3982,
'_order_version',
'6.5.1'
/* VALUES END */
), (
/* VALUES START */
1168,
3982,
'_prices_include_tax',
'no'
/* VALUES END */
), (
/* VALUES START */
1169,
3982,
'_billing_address_index',
'Mukul Kumar  B-15, Ramnagar Extension, Sodhala, Jaipur Ekadash Kunj Apartment Jaipur RJ 302019 IN mukulyashi@gmail.com 6350672348'
/* VALUES END */
), (
/* VALUES START */
1170,
3982,
'_shipping_address_index',
'         '
/* VALUES END */
), (
/* VALUES START */
1171,
3982,
'is_vat_exempt',
'no'
/* VALUES END */
), (
/* VALUES START */
1172,
3982,
'_download_permissions_granted',
'yes'
/* VALUES END */
), (
/* VALUES START */
1173,
3982,
'_recorded_sales',
'yes'
/* VALUES END */
), (
/* VALUES START */
1174,
3982,
'_recorded_coupon_usage_counts',
'yes'
/* VALUES END */
), (
/* VALUES START */
1175,
3982,
'_order_stock_reduced',
'yes'
/* VALUES END */
), (
/* VALUES START */
1176,
3982,
'_new_order_email_sent',
'true'
/* VALUES END */
), (
/* VALUES START */
1178,
3982,
'_edit_lock',
'1655223549:1'
/* VALUES END */
), (
/* VALUES START */
1179,
3982,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
1180,
3982,
'_date_completed',
1655223378
/* VALUES END */
), (
/* VALUES START */
1181,
3982,
'_date_paid',
1655223378
/* VALUES END */
), (
/* VALUES START */
1182,
3982,
'_paid_date',
'2022-06-14 16:16:18'
/* VALUES END */
), (
/* VALUES START */
1183,
3982,
'_completed_date',
'2022-06-14 16:16:18'
/* VALUES END */
), (
/* VALUES START */
1185,
3984,
'_order_key',
'wc_order_ZxZQChCAofauD'
/* VALUES END */
), (
/* VALUES START */
1186,
3984,
'_customer_user',
1
/* VALUES END */
), (
/* VALUES START */
1187,
3984,
'_payment_method',
'cod'
/* VALUES END */
), (
/* VALUES START */
1188,
3984,
'_payment_method_title',
'Cash on delivery'
/* VALUES END */
), (
/* VALUES START */
1189,
3984,
'_customer_ip_address',
'::1'
/* VALUES END */
), (
/* VALUES START */
1190,
3984,
'_customer_user_agent',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36'
/* VALUES END */
), (
/* VALUES START */
1191,
3984,
'_created_via',
'checkout'
/* VALUES END */
), (
/* VALUES START */
1192,
3984,
'_cart_hash',
'de69b1783ee30862fb07b4b992f2f598'
/* VALUES END */
), (
/* VALUES START */
1193,
3984,
'_billing_first_name',
'Mukul'
/* VALUES END */
), (
/* VALUES START */
1194,
3984,
'_billing_last_name',
'Kumar'
/* VALUES END */
), (
/* VALUES START */
1195,
3984,
'_billing_address_1',
'B-15, Ramnagar Extension, Sodhala, Jaipur'
/* VALUES END */
), (
/* VALUES START */
1196,
3984,
'_billing_address_2',
'Ekadash Kunj Apartment'
/* VALUES END */
), (
/* VALUES START */
1197,
3984,
'_billing_city',
'Jaipur'
/* VALUES END */
), (
/* VALUES START */
1198,
3984,
'_billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
1199,
3984,
'_billing_postcode',
302019
/* VALUES END */
), (
/* VALUES START */
1200,
3984,
'_billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
1201,
3984,
'_billing_email',
'mukulyashi@gmail.com'
/* VALUES END */
), (
/* VALUES START */
1202,
3984,
'_billing_phone',
6350672348
/* VALUES END */
), (
/* VALUES START */
1203,
3984,
'_order_currency',
'INR'
/* VALUES END */
), (
/* VALUES START */
1204,
3984,
'_cart_discount',
0
/* VALUES END */
), (
/* VALUES START */
1205,
3984,
'_cart_discount_tax',
0
/* VALUES END */
), (
/* VALUES START */
1206,
3984,
'_order_shipping',
0
/* VALUES END */
), (
/* VALUES START */
1207,
3984,
'_order_shipping_tax',
0
/* VALUES END */
), (
/* VALUES START */
1208,
3984,
'_order_tax',
0
/* VALUES END */
), (
/* VALUES START */
1209,
3984,
'_order_total',
300
/* VALUES END */
), (
/* VALUES START */
1210,
3984,
'_order_version',
'6.5.1'
/* VALUES END */
), (
/* VALUES START */
1211,
3984,
'_prices_include_tax',
'no'
/* VALUES END */
), (
/* VALUES START */
1212,
3984,
'_billing_address_index',
'Mukul Kumar  B-15, Ramnagar Extension, Sodhala, Jaipur Ekadash Kunj Apartment Jaipur RJ 302019 IN mukulyashi@gmail.com 6350672348'
/* VALUES END */
), (
/* VALUES START */
1213,
3984,
'_shipping_address_index',
'         '
/* VALUES END */
), (
/* VALUES START */
1214,
3984,
'is_vat_exempt',
'no'
/* VALUES END */
), (
/* VALUES START */
1215,
3984,
'_download_permissions_granted',
'yes'
/* VALUES END */
), (
/* VALUES START */
1216,
3984,
'_recorded_sales',
'yes'
/* VALUES END */
), (
/* VALUES START */
1217,
3984,
'_recorded_coupon_usage_counts',
'no'
/* VALUES END */
), (
/* VALUES START */
1218,
3984,
'_order_stock_reduced',
'no'
/* VALUES END */
), (
/* VALUES START */
1219,
3984,
'_new_order_email_sent',
'true'
/* VALUES END */
), (
/* VALUES START */
1220,
3984,
'_edit_lock',
'1655223731:1'
/* VALUES END */
), (
/* VALUES START */
1221,
3984,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
1225,
3682,
'_edit_lock',
'1655282243:1'
/* VALUES END */
), (
/* VALUES START */
1226,
3682,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
1227,
3682,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
1228,
3682,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
1229,
3682,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
1230,
3682,
'_stock',
''
/* VALUES END */
), (
/* VALUES START */
1231,
3682,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
1232,
3682,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
1234,
3682,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1263,
3992,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1265,
3979,
'pageview',
20
/* VALUES END */
), (
/* VALUES START */
1266,
3979,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1267,
3607,
'_edit_lock',
'1656398021:1'
/* VALUES END */
), (
/* VALUES START */
1268,
3993,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1269,
3617,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
1270,
3617,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
1271,
3617,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
1272,
3617,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
1273,
3617,
'_wp_old_date',
'2020-09-09'
/* VALUES END */
), (
/* VALUES START */
1274,
3616,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
1275,
3616,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
1276,
3616,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
1277,
3616,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
1278,
3616,
'_wp_old_date',
'2020-09-09'
/* VALUES END */
), (
/* VALUES START */
1279,
3622,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
1280,
3622,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
1281,
3622,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
1282,
3622,
'_wp_old_date',
'2020-09-09'
/* VALUES END */
), (
/* VALUES START */
1283,
3619,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
1284,
3619,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
1285,
3619,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
1286,
3619,
'_wp_old_date',
'2020-09-09'
/* VALUES END */
), (
/* VALUES START */
1287,
3620,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
1288,
3620,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
1289,
3620,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
1290,
3620,
'_wp_old_date',
'2020-09-09'
/* VALUES END */
), (
/* VALUES START */
1301,
3999,
'_wp_attached_file',
'2022/06/download.jpg'
/* VALUES END */
), (
/* VALUES START */
1302,
3999,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:221;s:6:\"height\";i:228;s:4:\"file\";s:20:\"2022/06/download.jpg\";s:8:\"filesize\";i:5693;s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:5:{s:4:\"file\";s:20:\"download-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4457;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:20:\"download-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2570;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:20:\"download-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2570;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1324,
4002,
'_order_key',
'wc_order_X3wOW19LrpNbf'
/* VALUES END */
), (
/* VALUES START */
1325,
4002,
'_customer_user',
4
/* VALUES END */
), (
/* VALUES START */
1326,
4002,
'_payment_method',
'cod'
/* VALUES END */
), (
/* VALUES START */
1327,
4002,
'_payment_method_title',
'Cash on delivery'
/* VALUES END */
), (
/* VALUES START */
1328,
4002,
'_customer_ip_address',
'182.68.200.227'
/* VALUES END */
), (
/* VALUES START */
1329,
4002,
'_customer_user_agent',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36'
/* VALUES END */
), (
/* VALUES START */
1330,
4002,
'_created_via',
'checkout'
/* VALUES END */
), (
/* VALUES START */
1331,
4002,
'_cart_hash',
'a0f0d271f57624a803ab72d14d1e2000'
/* VALUES END */
), (
/* VALUES START */
1332,
4002,
'_billing_first_name',
'Ashish'
/* VALUES END */
), (
/* VALUES START */
1333,
4002,
'_billing_last_name',
'Agarwal'
/* VALUES END */
), (
/* VALUES START */
1334,
4002,
'_billing_address_1',
'ls nagr'
/* VALUES END */
), (
/* VALUES START */
1335,
4002,
'_billing_city',
'jaipur'
/* VALUES END */
), (
/* VALUES START */
1336,
4002,
'_billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
1337,
4002,
'_billing_postcode',
302039
/* VALUES END */
), (
/* VALUES START */
1338,
4002,
'_billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
1339,
4002,
'_billing_email',
'ashishshiv781@gmail.com'
/* VALUES END */
), (
/* VALUES START */
1340,
4002,
'_billing_phone',
9876543210
/* VALUES END */
), (
/* VALUES START */
1341,
4002,
'_order_currency',
'INR'
/* VALUES END */
), (
/* VALUES START */
1342,
4002,
'_cart_discount',
0
/* VALUES END */
), (
/* VALUES START */
1343,
4002,
'_cart_discount_tax',
0
/* VALUES END */
), (
/* VALUES START */
1344,
4002,
'_order_shipping',
0
/* VALUES END */
), (
/* VALUES START */
1345,
4002,
'_order_shipping_tax',
0
/* VALUES END */
), (
/* VALUES START */
1346,
4002,
'_order_tax',
0
/* VALUES END */
), (
/* VALUES START */
1347,
4002,
'_order_total',
60
/* VALUES END */
), (
/* VALUES START */
1348,
4002,
'_order_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1349,
4002,
'_prices_include_tax',
'no'
/* VALUES END */
), (
/* VALUES START */
1350,
4002,
'_billing_address_index',
'Ashish Agarwal  ls nagr  jaipur RJ 302039 IN ashishshiv781@gmail.com 9876543210'
/* VALUES END */
), (
/* VALUES START */
1351,
4002,
'_shipping_address_index',
'         '
/* VALUES END */
), (
/* VALUES START */
1352,
4002,
'is_vat_exempt',
'no'
/* VALUES END */
), (
/* VALUES START */
1353,
4002,
'_dokan_vendor_id',
1
/* VALUES END */
), (
/* VALUES START */
1354,
4002,
'shipping_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1355,
4002,
'tax_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1356,
4002,
'_download_permissions_granted',
'yes'
/* VALUES END */
), (
/* VALUES START */
1357,
4002,
'_recorded_sales',
'yes'
/* VALUES END */
), (
/* VALUES START */
1358,
4002,
'_recorded_coupon_usage_counts',
'yes'
/* VALUES END */
), (
/* VALUES START */
1359,
4002,
'_order_stock_reduced',
'yes'
/* VALUES END */
), (
/* VALUES START */
1360,
4002,
'_new_order_email_sent',
'true'
/* VALUES END */
), (
/* VALUES START */
1361,
3992,
'_edit_lock',
'1656258269:1'
/* VALUES END */
), (
/* VALUES START */
1362,
1,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:1:{i:0;s:14:\"core/paragraph\";}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1363,
3674,
'pageview',
13
/* VALUES END */
), (
/* VALUES START */
1364,
3676,
'pageview',
13
/* VALUES END */
), (
/* VALUES START */
1366,
4004,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
1367,
4004,
'_menu_item_menu_item_parent',
3622
/* VALUES END */
), (
/* VALUES START */
1368,
4004,
'_menu_item_object_id',
4004
/* VALUES END */
), (
/* VALUES START */
1369,
4004,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
1370,
4004,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
1371,
4004,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
1372,
4004,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
1373,
4004,
'_menu_item_url',
'http://letsfarm.in/my-account/customer-logout/?_wpnonce=3bde592970'
/* VALUES END */
), (
/* VALUES START */
1392,
3681,
'pageview',
14
/* VALUES END */
), (
/* VALUES START */
1393,
3673,
'pageview',
10
/* VALUES END */
), (
/* VALUES START */
1396,
4012,
'_menu_item_type',
'custom'
/* VALUES END */
), (
/* VALUES START */
1397,
4012,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
1398,
4012,
'_menu_item_object_id',
4012
/* VALUES END */
), (
/* VALUES START */
1399,
4012,
'_menu_item_object',
'custom'
/* VALUES END */
), (
/* VALUES START */
1400,
4012,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
1401,
4012,
'_menu_item_classes',
'a:1:{i:0;s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
1402,
4012,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
1403,
4012,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
1405,
4012,
'_menu_item_dgwt_wcas_layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1406,
4012,
'_menu_item_dgwt_wcas_search_icon_color',
''
/* VALUES END */
), (
/* VALUES START */
1407,
3618,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
1408,
3618,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
1409,
3618,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
1410,
3618,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
1411,
3618,
'_wp_old_date',
'2020-09-09'
/* VALUES END */
), (
/* VALUES START */
1412,
3621,
'_menu_item_menu_item_parent',
0
/* VALUES END */
), (
/* VALUES START */
1413,
3621,
'_menu_item_target',
''
/* VALUES END */
), (
/* VALUES START */
1414,
3621,
'_menu_item_xfn',
''
/* VALUES END */
), (
/* VALUES START */
1415,
3621,
'_menu_item_url',
''
/* VALUES END */
), (
/* VALUES START */
1416,
3621,
'_wp_old_date',
'2020-09-09'
/* VALUES END */
), (
/* VALUES START */
1417,
3617,
'_wp_old_date',
'2022-06-20'
/* VALUES END */
), (
/* VALUES START */
1418,
3616,
'_wp_old_date',
'2022-06-20'
/* VALUES END */
), (
/* VALUES START */
1419,
3622,
'_wp_old_date',
'2022-06-20'
/* VALUES END */
), (
/* VALUES START */
1420,
3619,
'_wp_old_date',
'2022-06-20'
/* VALUES END */
), (
/* VALUES START */
1421,
3620,
'_wp_old_date',
'2022-06-20'
/* VALUES END */
), (
/* VALUES START */
1460,
4019,
'_wp_attached_file',
'2022/06/2-2-2-2foodgroups_vegetables_detailfeature.jpg'
/* VALUES END */
), (
/* VALUES START */
1461,
4019,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1200;s:6:\"height\";i:686;s:4:\"file\";s:54:\"2022/06/2-2-2-2foodgroups_vegetables_detailfeature.jpg\";s:8:\"filesize\";i:163763;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:54:\"2-2-2-2foodgroups_vegetables_detailfeature-300x172.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:172;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23883;}s:5:\"large\";a:5:{s:4:\"file\";s:55:\"2-2-2-2foodgroups_vegetables_detailfeature-1024x585.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:585;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:176500;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:54:\"2-2-2-2foodgroups_vegetables_detailfeature-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:11662;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:54:\"2-2-2-2foodgroups_vegetables_detailfeature-768x439.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:439;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:111904;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:54:\"2-2-2-2foodgroups_vegetables_detailfeature-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:37796;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:54:\"2-2-2-2foodgroups_vegetables_detailfeature-600x343.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:343;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:73585;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:54:\"2-2-2-2foodgroups_vegetables_detailfeature-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6001;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:54:\"2-2-2-2foodgroups_vegetables_detailfeature-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:37796;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:54:\"2-2-2-2foodgroups_vegetables_detailfeature-600x343.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:343;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:73585;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:54:\"2-2-2-2foodgroups_vegetables_detailfeature-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6001;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:52:\"2-2-2-2foodgroups_vegetables_detailfeature-64x37.jpg\";s:5:\"width\";i:64;s:6:\"height\";i:37;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1923;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1462,
4019,
'_wp_attachment_image_alt',
'vegetables'
/* VALUES END */
), (
/* VALUES START */
1463,
4021,
'_edit_lock',
'1656413681:1'
/* VALUES END */
), (
/* VALUES START */
1464,
4021,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
1465,
4022,
'_wp_attached_file',
'2022/06/potatoes-vegetables-food-411975.jpg'
/* VALUES END */
), (
/* VALUES START */
1466,
4022,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:43:\"2022/06/potatoes-vegetables-food-411975.jpg\";s:8:\"filesize\";i:149269;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:43:\"potatoes-vegetables-food-411975-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15962;}s:5:\"large\";a:5:{s:4:\"file\";s:44:\"potatoes-vegetables-food-411975-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:116888;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:43:\"potatoes-vegetables-food-411975-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7067;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:43:\"potatoes-vegetables-food-411975-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:73058;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:43:\"potatoes-vegetables-food-411975-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20971;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:43:\"potatoes-vegetables-food-411975-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:48887;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:43:\"potatoes-vegetables-food-411975-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3848;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:43:\"potatoes-vegetables-food-411975-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:20971;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:43:\"potatoes-vegetables-food-411975-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:48887;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:43:\"potatoes-vegetables-food-411975-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3848;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:41:\"potatoes-vegetables-food-411975-64x43.jpg\";s:5:\"width\";i:64;s:6:\"height\";i:43;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1515;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1467,
4022,
'_source_url',
'https://pixabay.com/get/gbe9ed5a50078d50eff4b490600a8c46d0da3e9679f7f9cfe8f5537cb70620d5bebf7a3132498143833de4bce5130ff22_1280.jpg'
/* VALUES END */
), (
/* VALUES START */
1468,
4022,
'astra-images',
411975
/* VALUES END */
), (
/* VALUES START */
1469,
4022,
'_wp_attachment_image_alt',
'potatoes, vegetables, food-411975.jpg'
/* VALUES END */
), (
/* VALUES START */
1470,
4021,
'_thumbnail_id',
4022
/* VALUES END */
), (
/* VALUES START */
1471,
4021,
'_regular_price',
20
/* VALUES END */
), (
/* VALUES START */
1472,
4021,
'total_sales',
0
/* VALUES END */
), (
/* VALUES START */
1473,
4021,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
1474,
4021,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
1475,
4021,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
1476,
4021,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
1477,
4021,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
1478,
4021,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
1479,
4021,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
1480,
4021,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
1481,
4021,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
1482,
4021,
'_stock',
''
/* VALUES END */
), (
/* VALUES START */
1483,
4021,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
1484,
4021,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
1485,
4021,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
1486,
4021,
'_product_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1487,
4021,
'_price',
20
/* VALUES END */
), (
/* VALUES START */
1488,
4021,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1489,
4021,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1490,
4021,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
1492,
4021,
'pageview',
14
/* VALUES END */
), (
/* VALUES START */
1496,
4023,
'_edit_lock',
'1656413923:1'
/* VALUES END */
), (
/* VALUES START */
1497,
4023,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
1498,
4024,
'_wp_attached_file',
'2022/06/onion-chopped-onion-tropea-red-onion-899102.jpg'
/* VALUES END */
), (
/* VALUES START */
1499,
4024,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:815;s:4:\"file\";s:55:\"2022/06/onion-chopped-onion-tropea-red-onion-899102.jpg\";s:8:\"filesize\";i:92911;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:55:\"onion-chopped-onion-tropea-red-onion-899102-300x191.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:191;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:9572;}s:5:\"large\";a:5:{s:4:\"file\";s:56:\"onion-chopped-onion-tropea-red-onion-899102-1024x652.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:652;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:72884;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:55:\"onion-chopped-onion-tropea-red-onion-899102-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5392;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:55:\"onion-chopped-onion-tropea-red-onion-899102-768x489.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:489;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:45356;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:55:\"onion-chopped-onion-tropea-red-onion-899102-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16030;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:55:\"onion-chopped-onion-tropea-red-onion-899102-600x382.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:382;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29773;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:55:\"onion-chopped-onion-tropea-red-onion-899102-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2978;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:55:\"onion-chopped-onion-tropea-red-onion-899102-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:16030;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:55:\"onion-chopped-onion-tropea-red-onion-899102-600x382.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:382;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:29773;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:55:\"onion-chopped-onion-tropea-red-onion-899102-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:2978;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:53:\"onion-chopped-onion-tropea-red-onion-899102-64x41.jpg\";s:5:\"width\";i:64;s:6:\"height\";i:41;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1146;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1500,
4024,
'_source_url',
'https://pixabay.com/get/g1f1d30f2edfc37f6c2cde8b40250db7deccf6eb09460b9d7affde946898b70dbb63aa2b55594557595c1e12d42bf056c_1280.jpg'
/* VALUES END */
), (
/* VALUES START */
1501,
4024,
'astra-images',
899102
/* VALUES END */
), (
/* VALUES START */
1502,
4024,
'_wp_attachment_image_alt',
'onion, chopped onion, tropea red onion-899102.jpg'
/* VALUES END */
), (
/* VALUES START */
1503,
4023,
'_thumbnail_id',
4024
/* VALUES END */
), (
/* VALUES START */
1504,
4023,
'_regular_price',
50
/* VALUES END */
), (
/* VALUES START */
1505,
4023,
'total_sales',
0
/* VALUES END */
), (
/* VALUES START */
1506,
4023,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
1507,
4023,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
1508,
4023,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
1509,
4023,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
1510,
4023,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
1511,
4023,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
1512,
4023,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
1513,
4023,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
1514,
4023,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
1515,
4023,
'_stock',
''
/* VALUES END */
), (
/* VALUES START */
1516,
4023,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
1517,
4023,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
1518,
4023,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
1519,
4023,
'_product_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1520,
4023,
'_price',
50
/* VALUES END */
), (
/* VALUES START */
1521,
4023,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1522,
4023,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1523,
4023,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
1524,
4025,
'_edit_lock',
'1656413892:1'
/* VALUES END */
), (
/* VALUES START */
1525,
4025,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
1526,
4026,
'_wp_attached_file',
'2022/06/tomatoes-red-sliced-769999.jpg'
/* VALUES END */
), (
/* VALUES START */
1527,
4026,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:38:\"2022/06/tomatoes-red-sliced-769999.jpg\";s:8:\"filesize\";i:141969;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:38:\"tomatoes-red-sliced-769999-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:13080;}s:5:\"large\";a:5:{s:4:\"file\";s:39:\"tomatoes-red-sliced-769999-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:106751;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:38:\"tomatoes-red-sliced-769999-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:5817;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:38:\"tomatoes-red-sliced-769999-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:64989;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:38:\"tomatoes-red-sliced-769999-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18191;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:38:\"tomatoes-red-sliced-769999-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42102;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:38:\"tomatoes-red-sliced-769999-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3238;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:38:\"tomatoes-red-sliced-769999-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18191;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:38:\"tomatoes-red-sliced-769999-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42102;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:38:\"tomatoes-red-sliced-769999-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3238;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:36:\"tomatoes-red-sliced-769999-64x43.jpg\";s:5:\"width\";i:64;s:6:\"height\";i:43;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1329;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1528,
4026,
'_source_url',
'https://pixabay.com/get/g03a11c731c411c3a5a77216852a7d64a9ccf1fd778c81f97b476e79ac63e599c84d86f081586711da1aceea7aa1731c7_1280.jpg'
/* VALUES END */
), (
/* VALUES START */
1529,
4026,
'astra-images',
769999
/* VALUES END */
), (
/* VALUES START */
1530,
4026,
'_wp_attachment_image_alt',
'tomatoes, red, sliced-769999.jpg'
/* VALUES END */
), (
/* VALUES START */
1531,
4025,
'_thumbnail_id',
4026
/* VALUES END */
), (
/* VALUES START */
1532,
4025,
'total_sales',
0
/* VALUES END */
), (
/* VALUES START */
1533,
4025,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
1534,
4025,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
1535,
4025,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
1536,
4025,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
1537,
4025,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
1538,
4025,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
1539,
4025,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
1540,
4025,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
1541,
4025,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
1542,
4025,
'_stock',
''
/* VALUES END */
), (
/* VALUES START */
1543,
4025,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
1544,
4025,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
1545,
4025,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
1546,
4025,
'_product_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1547,
4025,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1548,
4025,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1549,
4025,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
1550,
4027,
'_edit_lock',
'1656413869:1'
/* VALUES END */
), (
/* VALUES START */
1551,
4027,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
1552,
4028,
'_wp_attached_file',
'2022/06/carrots-vegetables-produce-3440368.jpg'
/* VALUES END */
), (
/* VALUES START */
1553,
4028,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:46:\"2022/06/carrots-vegetables-produce-3440368.jpg\";s:8:\"filesize\";i:183544;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:46:\"carrots-vegetables-produce-3440368-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:14862;}s:5:\"large\";a:5:{s:4:\"file\";s:47:\"carrots-vegetables-produce-3440368-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:86036;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:46:\"carrots-vegetables-produce-3440368-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6973;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:46:\"carrots-vegetables-produce-3440368-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:56972;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:46:\"carrots-vegetables-produce-3440368-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18329;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:46:\"carrots-vegetables-produce-3440368-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:40072;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:46:\"carrots-vegetables-produce-3440368-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4064;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:46:\"carrots-vegetables-produce-3440368-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:18329;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:46:\"carrots-vegetables-produce-3440368-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:40072;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:46:\"carrots-vegetables-produce-3440368-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4064;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:44:\"carrots-vegetables-produce-3440368-64x43.jpg\";s:5:\"width\";i:64;s:6:\"height\";i:43;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1823;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"9\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:5:\"X-T10\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"200\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:6:\"0.0025\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1554,
4028,
'_source_url',
'https://pixabay.com/get/g15652c53262c403f28396f928391d2087611c0e05d175ae5b9b2f43befdc90d746f2a168db5659043c068dd8823985f260a34849aafd7341123b977d449ed955_1280.jpg'
/* VALUES END */
), (
/* VALUES START */
1555,
4028,
'astra-images',
3440368
/* VALUES END */
), (
/* VALUES START */
1556,
4028,
'_wp_attachment_image_alt',
'carrots, vegetables, produce-3440368.jpg'
/* VALUES END */
), (
/* VALUES START */
1557,
4027,
'_thumbnail_id',
4028
/* VALUES END */
), (
/* VALUES START */
1558,
4027,
'_regular_price',
80
/* VALUES END */
), (
/* VALUES START */
1559,
4027,
'total_sales',
4
/* VALUES END */
), (
/* VALUES START */
1560,
4027,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
1561,
4027,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
1562,
4027,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
1563,
4027,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
1564,
4027,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
1565,
4027,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
1566,
4027,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
1567,
4027,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
1568,
4027,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
1569,
4027,
'_stock',
''
/* VALUES END */
), (
/* VALUES START */
1570,
4027,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
1571,
4027,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
1572,
4027,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
1573,
4027,
'_product_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1574,
4027,
'_price',
80
/* VALUES END */
), (
/* VALUES START */
1575,
4027,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1576,
4027,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1577,
4027,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
1578,
4021,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
);
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1579,
4025,
'_regular_price',
30
/* VALUES END */
), (
/* VALUES START */
1580,
4025,
'_price',
30
/* VALUES END */
), (
/* VALUES START */
1581,
4029,
'_edit_lock',
'1656414182:1'
/* VALUES END */
), (
/* VALUES START */
1582,
4029,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
1583,
4030,
'_wp_attached_file',
'2022/06/apple-red-fruits-1589874.jpg'
/* VALUES END */
), (
/* VALUES START */
1584,
4030,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:870;s:4:\"file\";s:36:\"2022/06/apple-red-fruits-1589874.jpg\";s:8:\"filesize\";i:119822;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:36:\"apple-red-fruits-1589874-300x204.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:204;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15220;}s:5:\"large\";a:5:{s:4:\"file\";s:37:\"apple-red-fruits-1589874-1024x696.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:696;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:98299;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:36:\"apple-red-fruits-1589874-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:6797;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:36:\"apple-red-fruits-1589874-768x522.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:522;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:63203;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:36:\"apple-red-fruits-1589874-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19157;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:36:\"apple-red-fruits-1589874-600x408.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:408;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42924;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:36:\"apple-red-fruits-1589874-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3888;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:36:\"apple-red-fruits-1589874-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:19157;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:36:\"apple-red-fruits-1589874-600x408.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:408;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:42924;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:36:\"apple-red-fruits-1589874-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:3888;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:34:\"apple-red-fruits-1589874-64x44.jpg\";s:5:\"width\";i:64;s:6:\"height\";i:44;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1602;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1585,
4030,
'_source_url',
'https://pixabay.com/get/gb84bb4c7cd03d5ec04ba2cf5ce1bc23e4011ee0d2a32874afa4efd24a126ef3b9d479282a9c9c601e299c740dc1d460e26b986795b8b1690eab99c8fc154ee3f_1280.jpg'
/* VALUES END */
), (
/* VALUES START */
1586,
4030,
'astra-images',
1589874
/* VALUES END */
), (
/* VALUES START */
1587,
4030,
'_wp_attachment_image_alt',
'apple, red, fruits-1589874.jpg'
/* VALUES END */
), (
/* VALUES START */
1588,
4029,
'_thumbnail_id',
4030
/* VALUES END */
), (
/* VALUES START */
1589,
4029,
'total_sales',
2
/* VALUES END */
), (
/* VALUES START */
1590,
4029,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
1591,
4029,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
1592,
4029,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
1593,
4029,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
1594,
4029,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
1595,
4029,
'_virtual',
'no'
/* VALUES END */
), (
/* VALUES START */
1596,
4029,
'_downloadable',
'no'
/* VALUES END */
), (
/* VALUES START */
1597,
4029,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
1598,
4029,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
1599,
4029,
'_stock',
''
/* VALUES END */
), (
/* VALUES START */
1600,
4029,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
1601,
4029,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
1602,
4029,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
1603,
4029,
'_product_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1604,
4029,
'site-sidebar-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1605,
4029,
'site-content-layout',
'default'
/* VALUES END */
), (
/* VALUES START */
1606,
4029,
'theme-transparent-header-meta',
'default'
/* VALUES END */
), (
/* VALUES START */
1607,
4029,
'_regular_price',
120
/* VALUES END */
), (
/* VALUES START */
1608,
4029,
'_price',
120
/* VALUES END */
), (
/* VALUES START */
1609,
4029,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1610,
4029,
'pageview',
18
/* VALUES END */
), (
/* VALUES START */
1611,
4027,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1612,
4023,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1613,
4032,
'_wp_attached_file',
'2022/06/man-indian-portrait-1129953.jpg'
/* VALUES END */
), (
/* VALUES START */
1614,
4032,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:1280;s:6:\"height\";i:853;s:4:\"file\";s:39:\"2022/06/man-indian-portrait-1129953.jpg\";s:8:\"filesize\";i:248301;s:5:\"sizes\";a:11:{s:6:\"medium\";a:5:{s:4:\"file\";s:39:\"man-indian-portrait-1129953-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:15093;}s:5:\"large\";a:5:{s:4:\"file\";s:40:\"man-indian-portrait-1129953-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:128480;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:39:\"man-indian-portrait-1129953-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:7485;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:39:\"man-indian-portrait-1129953-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:75427;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:39:\"man-indian-portrait-1129953-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23625;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:39:\"man-indian-portrait-1129953-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:48725;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:39:\"man-indian-portrait-1129953-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4113;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:39:\"man-indian-portrait-1129953-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:23625;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:39:\"man-indian-portrait-1129953-600x400.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:400;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:48725;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:39:\"man-indian-portrait-1129953-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:4113;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:37:\"man-indian-portrait-1129953-64x43.jpg\";s:5:\"width\";i:64;s:6:\"height\";i:43;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:1490;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1615,
4032,
'_source_url',
'https://pixabay.com/get/gdb57b91470bcbdd4586d18c6951d673e7d6ea118c9c3f77da0f87e14dfabeb1577fcebed8c10982cc789d0d5a990c10ececda730ff4424fae5998193ce866028_1280.jpg'
/* VALUES END */
), (
/* VALUES START */
1616,
4032,
'astra-images',
1129953
/* VALUES END */
), (
/* VALUES START */
1617,
4032,
'_wp_attachment_image_alt',
'man, indian, portrait-1129953.jpg'
/* VALUES END */
), (
/* VALUES START */
1618,
4033,
'_wp_attached_file',
'2022/06/depositphotos_44309759-stock-photo-young-indian-man-outdoors.jpg'
/* VALUES END */
), (
/* VALUES START */
1619,
4033,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:682;s:6:\"height\";i:682;s:4:\"file\";s:72:\"2022/06/depositphotos_44309759-stock-photo-young-indian-man-outdoors.jpg\";s:8:\"filesize\";i:117730;s:5:\"sizes\";a:9:{s:6:\"medium\";a:5:{s:4:\"file\";s:72:\"depositphotos_44309759-stock-photo-young-indian-man-outdoors-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:43782;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:72:\"depositphotos_44309759-stock-photo-young-indian-man-outdoors-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33961;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:72:\"depositphotos_44309759-stock-photo-young-indian-man-outdoors-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:43782;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:72:\"depositphotos_44309759-stock-photo-young-indian-man-outdoors-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:76504;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:72:\"depositphotos_44309759-stock-photo-young-indian-man-outdoors-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:31705;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:72:\"depositphotos_44309759-stock-photo-young-indian-man-outdoors-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:43782;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:72:\"depositphotos_44309759-stock-photo-young-indian-man-outdoors-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:76504;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:72:\"depositphotos_44309759-stock-photo-young-indian-man-outdoors-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:31705;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:70:\"depositphotos_44309759-stock-photo-young-indian-man-outdoors-64x64.jpg\";s:5:\"width\";i:64;s:6:\"height\";i:64;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:30196;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1656438843\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1620,
4034,
'_wp_attached_file',
'2022/06/Poshik-Sharma.jpg'
/* VALUES END */
), (
/* VALUES START */
1621,
4034,
'_wp_attachment_metadata',
'a:6:{s:5:\"width\";i:800;s:6:\"height\";i:799;s:4:\"file\";s:25:\"2022/06/Poshik-Sharma.jpg\";s:8:\"filesize\";i:143365;s:5:\"sizes\";a:10:{s:6:\"medium\";a:5:{s:4:\"file\";s:25:\"Poshik-Sharma-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:47044;}s:9:\"thumbnail\";a:5:{s:4:\"file\";s:25:\"Poshik-Sharma-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:35984;}s:12:\"medium_large\";a:5:{s:4:\"file\";s:25:\"Poshik-Sharma-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:104378;}s:21:\"woocommerce_thumbnail\";a:6:{s:4:\"file\";s:25:\"Poshik-Sharma-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:47112;s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:5:{s:4:\"file\";s:25:\"Poshik-Sharma-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:81284;}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:4:\"file\";s:25:\"Poshik-Sharma-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33452;}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:25:\"Poshik-Sharma-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:47112;}s:11:\"shop_single\";a:5:{s:4:\"file\";s:25:\"Poshik-Sharma-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:81284;}s:14:\"shop_thumbnail\";a:5:{s:4:\"file\";s:25:\"Poshik-Sharma-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:33452;}s:28:\"dgwt-wcas-product-suggestion\";a:5:{s:4:\"file\";s:23:\"Poshik-Sharma-64x64.jpg\";s:5:\"width\";i:64;s:6:\"height\";i:64;s:9:\"mime-type\";s:10:\"image/jpeg\";s:8:\"filesize\";i:31794;}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1656438816\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
1630,
4025,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:0:{}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1633,
3610,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:16304:\".uagb-ifb-icon-wrap,.uagb-ifb-icon-wrap *{-webkit-transition:all 0.2s;-o-transition:all 0.2s;transition:all 0.2s}.uagb-ifb-icon-wrap .uagb-ifb-icon,.uagb-ifb-content{display:inline-block}.uagb-ifb-icon svg{width:inherit;height:inherit;vertical-align:middle}.infobox-icon-above-title .uagb-ifb-left-right-wrap{text-align:center}a.uagb-infobox-cta-link span{font-size:inherit}.uagb-ifb-cta.uagb-infobox-cta-link-style:empty{display:none}a.uagb-infobox-cta-link,.entry .entry-content a.uagb-infobox-cta-link,a.uagb-infobox-link-wrap,.entry .entry-content a.uagb-infobox-link-wrap{text-decoration:none}a.uagb-infobox-cta-link:hover,.entry .entry-content a.uagb-infobox-cta-link:hover,a.uagb-infobox-link-wrap:hover,.entry .entry-content a.uagb-infobox-link-wrap:hover .entry .entry-content a.uagb-infobox-cta-link:hover{color:inherit}.uagb-infobox-icon-left-title.uagb-infobox-image-valign-middle .uagb-ifb-title-wrap,.uagb-infobox-icon-right-title.uagb-infobox-image-valign-middle .uagb-ifb-title-wrap,.uagb-infobox-image-valign-middle .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-left.uagb-infobox-image-valign-middle .uagb-ifb-content,.uagb-infobox-icon-right.uagb-infobox-image-valign-middle .uagb-ifb-content{-ms-flex-item-align:center;-webkit-align-self:center;align-self:center}.uagb-infobox-left{text-align:left;-webkit-box-pack:start;-ms-flex-pack:start;-webkit-justify-content:flex-start;-moz-box-pack:start;justify-content:flex-start}.uagb-infobox-center{text-align:center;-webkit-box-pack:center;-ms-flex-pack:center;-webkit-justify-content:center;-moz-box-pack:center;justify-content:center}.uagb-infobox-right{text-align:right;-webkit-box-pack:end;-ms-flex-pack:end;-webkit-justify-content:flex-end;-moz-box-pack:end;justify-content:flex-end}.uagb-ifb-left-right-wrap{width:100%;word-break:break-word}.uagb-infobox-icon-above-title .uagb-ifb-left-right-wrap,.uagb-infobox-icon-below-title .uagb-ifb-left-right-wrap{display:block;min-width:100%;width:100%}.uagb-infobox-icon-left-title .uagb-ifb-icon-wrap,.uagb-infobox-icon-left .uagb-ifb-icon-wrap{margin-right:10px}.uagb-infobox-icon-right-title .uagb-ifb-icon-wrap,.uagb-infobox-icon-right .uagb-ifb-icon-wrap{margin-left:10px}.uagb-infobox-icon-left .uagb-ifb-left-right-wrap,.uagb-infobox-icon-right .uagb-ifb-left-right-wrap,.uagb-infobox-icon-left-title .uagb-ifb-left-title-image,.uagb-infobox-icon-right-title .uagb-ifb-right-title-image{display:-webkit-box;display:-ms-flexbox;-js-display:flex;display:-webkit-flex;display:-moz-box;display:flex}.uagb-infobox-icon-right .uagb-ifb-left-right-wrap,.uagb-infobox-icon-right-title .uagb-ifb-right-title-image{-webkit-box-pack:end;-ms-flex-pack:end;-webkit-justify-content:flex-end;-moz-box-pack:end;justify-content:flex-end}.uagb-ifb-icon-wrap .uagb-ifb-icon span{font-style:initial;height:auto;width:auto}.uagb-ifb-imgicon-wrap .uagb-ifb-image-content{display:inline-block;line-height:0;position:relative;max-width:100%}.uagb-ifb-imgicon-wrap .uagb-ifb-image-content img{display:inline;height:auto !important;max-width:100%;width:auto;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;-webkit-border-radius:inherit;border-radius:inherit}.uagb-ifb-imgicon-wrap .uagb-image-crop-circle img{-webkit-border-radius:100%;border-radius:100%}.uagb-ifb-imgicon-wrap .uagb-image-crop-square img{-webkit-border-radius:0;border-radius:0}.uagb-infobox-module-link{position:absolute;width:100%;height:100%;left:0;top:0;bottom:0;right:0;z-index:4}.uagb-edit-mode .uagb-infobox-module-link{z-index:2}.uagb-infobox-link-icon-after{margin-left:5px;margin-right:0}.uagb-infobox-link-icon-before{margin-left:0;margin-right:5px}.uagb-infobox-link-icon{-webkit-transition:all 200ms linear;transition:all 200ms linear}.uagb-infobox{position:relative}.uagb-ifb-separator{width:30%;border-top-width:2px;border-top-color:#333;border-top-style:solid;display:inline-block;margin:0}.uagb-ifb-separator-parent{line-height:0em;margin-left:0;margin-right:0;margin-bottom:10px}.uagb-ifb-cta-button{display:inline-block;line-height:1;background-color:#818a91;color:#fff;text-align:center}.uagb-ifb-button-wrapper .wp-block-button__link svg{fill:currentColor}.uagb-ifb-cta a{-webkit-box-shadow:none;box-shadow:none;text-decoration:none}.uagb-ifb-title-wrap{width:100%}.uagb-ifb-title-wrap .uagb-ifb-title,.uagb-ifb-title-wrap .uagb-ifb-title-prefix{padding:0;margin:0;display:block}.uagb-infobox__content-wrap.uagb-infobox{position:relative}.uagb-ifb-icon span{font-size:40px;height:40px;color:#333;width:40px}.uagb-ifb-icon svg{fill:#333}.uagb-ifb-content{width:100%}.uagb-infobox__content-wrap.uagb-infobox,.uagb-ifb-content,.uagb-ifb-title-wrap,.uagb-ifb-title-prefix *,svg.dashicon.dashicons-upload{z-index:1}.uagb-ifb-left-right-wrap{z-index:1}.uagb-infobox-cta-link{cursor:pointer}a.uagb-infobox-link-wrap{color:inherit}.uagb-ifb-content p:empty{display:none}.uagb-infobox .uagb-ifb-icon,.uagb-infobox .uagb-ifb-image-content img{display:inline-block;box-sizing:content-box}.uagb-ifb-align-icon-after{margin-left:5px}.uagb-ifb-align-icon-before{margin-right:5px}span.uagb-ifb-button-icon.uagb-ifb-align-icon-after{float:right}.uagb-ifb-button-icon{height:15px;width:15px;font-size:15px;vertical-align:middle}.uagb-ifb-text-icon{height:15px;width:15px;font-size:15px;line-height:15px;vertical-align:middle;display:inline-block}.uagb-ifb-button-icon svg,.uagb-ifb-text-icon svg{height:inherit;width:inherit;display:inline-block}.block-editor-page #wpwrap .uagb-infobox-cta-link svg,.uagb-infobox-cta-link svg{font-style:normal}.uagb-infobox__outer-wrap{position:relative}a.uagb-infbox__link-to-all{height:100%;width:100%;top:0;left:0;position:absolute;z-index:3;-webkit-box-shadow:none;box-shadow:none;text-decoration:none}@media only screen and (max-width: 976px){.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{padding:0;margin-bottom:20px}.uagb-infobox-stacked-tablet.uagb-reverse-order-tablet .uagb-ifb-left-right-wrap{display:-webkit-inline-box;display:-ms-inline-flexbox;-js-display:inline-flex;display:-webkit-inline-flex;display:-moz-inline-box;display:inline-flex;-webkit-box-orient:vertical;-webkit-box-direction:reverse;-ms-flex-direction:column-reverse;-webkit-flex-direction:column-reverse;-moz-box-orient:vertical;-moz-box-direction:reverse;flex-direction:column-reverse}.uagb-infobox.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap .uagb-ifb-content,.uagb-infobox.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{display:block;width:100%;text-align:center}.uagb-infobox.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{margin-left:0px;margin-right:0px}.uagb-infobox-stacked-tablet .uagb-ifb-left-right-wrap{display:inline-block}.uagb-infobox-icon-left-title.uagb-infobox-stacked-tablet .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-left.uagb-infobox-stacked-tablet .uagb-ifb-imgicon-wrap{margin-right:0px}.uagb-infobox-icon-right-title.uagb-infobox-stacked-tablet .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-right.uagb-infobox-stacked-tablet .uagb-ifb-imgicon-wrap{margin-left:0px}.uagb-infobox-icon-left-title .uagb-ifb-separator-parent{margin:10px 0}}@media screen and (max-width: 767px){.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{padding:0;margin-bottom:20px}.uagb-infobox-stacked-mobile.uagb-reverse-order-mobile .uagb-ifb-left-right-wrap{display:-webkit-inline-box;display:-ms-inline-flexbox;-js-display:inline-flex;display:-webkit-inline-flex;display:-moz-inline-box;display:inline-flex;-webkit-box-orient:vertical;-webkit-box-direction:reverse;-ms-flex-direction:column-reverse;-webkit-flex-direction:column-reverse;-moz-box-orient:vertical;-moz-box-direction:reverse;flex-direction:column-reverse}.uagb-infobox.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap .uagb-ifb-content,.uagb-infobox.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{display:block;width:100%;text-align:center}.uagb-infobox.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap .uagb-ifb-imgicon-wrap{margin-left:0px;margin-right:0px}.uagb-infobox-stacked-mobile .uagb-ifb-left-right-wrap{display:inline-block}.uagb-infobox-icon-left-title.uagb-infobox-stacked-mobile .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-left.uagb-infobox-stacked-mobile .uagb-ifb-imgicon-wrap{margin-right:0px}.uagb-infobox-icon-right-title.uagb-infobox-stacked-mobile .uagb-ifb-imgicon-wrap,.uagb-infobox-icon-right.uagb-infobox-stacked-mobile .uagb-ifb-imgicon-wrap{margin-left:0px}.uagb-infobox-icon-left-title .uagb-ifb-separator-parent{margin:10px 0}}\n.uagb-block-732803e4 .uagb-ifb-icon{height: 40px;width: 40px;line-height: 40px;}.uagb-block-732803e4 .uagb-ifb-icon > span{font-size: 40px;height: 40px;width: 40px;line-height: 40px;color: var(--ast-global-color-0);}.uagb-block-732803e4 .uagb-ifb-icon svg{fill: var(--ast-global-color-0);}.uagb-block-732803e4 .uagb-infobox__content-wrap .uagb-ifb-imgicon-wrap{margin-left: 5px;margin-right: 10px;margin-top: 5px;margin-bottom: 5px;}.uagb-block-732803e4 .uagb-ifb-title-prefix{color: var(ast-global-color-7);margin-bottom: 5px;}.uagb-block-732803e4 .uagb-ifb-title-wrap .uagb-ifb-title{color: var(--ast-global-color-5);margin-bottom: 10px;}.uagb-block-732803e4 .uagb-ifb-text-wrap .uagb-ifb-desc{color: var(--ast-global-color-4);margin-bottom: 10px;}.uagb-block-732803e4 .uagb-ifb-separator{width: 30%;border-top-width: 2px;border-top-color: #333;border-top-style: none;}.uagb-block-732803e4 .uagb-ifb-separator-parent{margin-bottom: 15px;}.uagb-block-732803e4 .uagb-ifb-align-icon-after{margin-left: 5px;}.uagb-block-732803e4 .uagb-ifb-align-icon-before{margin-right: 5px;}.uagb-block-732803e4 .uagb-infobox-cta-link{color: #333;}.uagb-block-732803e4 .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-732803e4 .uagb-ifb-button-wrapper .uagb-infobox-cta-link{color: #333;background-color: transparent;border-style: solid;border-color: #333;border-width: 1px;padding-top: 10px;padding-bottom: 10px;padding-left: 14px;padding-right: 14px;}.uagb-block-732803e4 .uagb-ifb-button-wrapper .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-732803e4 .uagb-ifb-image-content > img{width: 120px;max-width: 120px;}.uagb-block-96e7c888 .uagb-ifb-icon{height: 40px;width: 40px;line-height: 40px;}.uagb-block-96e7c888 .uagb-ifb-icon > span{font-size: 40px;height: 40px;width: 40px;line-height: 40px;color: var(--ast-global-color-0);}.uagb-block-96e7c888 .uagb-ifb-icon svg{fill: var(--ast-global-color-0);}.uagb-block-96e7c888 .uagb-infobox__content-wrap .uagb-ifb-imgicon-wrap{margin-left: 5px;margin-right: 10px;margin-top: 5px;margin-bottom: 5px;}.uagb-block-96e7c888 .uagb-ifb-title-prefix{color: var(ast-global-color-7);margin-bottom: 5px;}.uagb-block-96e7c888 .uagb-ifb-title-wrap .uagb-ifb-title{color: var(--ast-global-color-5);margin-bottom: 10px;}.uagb-block-96e7c888 .uagb-ifb-text-wrap .uagb-ifb-desc{color: var(--ast-global-color-4);margin-bottom: 10px;}.uagb-block-96e7c888 .uagb-ifb-separator{width: 30%;border-top-width: 2px;border-top-color: #333;border-top-style: none;}.uagb-block-96e7c888 .uagb-ifb-separator-parent{margin-bottom: 15px;}.uagb-block-96e7c888 .uagb-ifb-align-icon-after{margin-left: 5px;}.uagb-block-96e7c888 .uagb-ifb-align-icon-before{margin-right: 5px;}.uagb-block-96e7c888 .uagb-infobox-cta-link{color: #333;}.uagb-block-96e7c888 .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-96e7c888 .uagb-ifb-button-wrapper .uagb-infobox-cta-link{color: #333;background-color: transparent;border-style: solid;border-color: #333;border-width: 1px;padding-top: 10px;padding-bottom: 10px;padding-left: 14px;padding-right: 14px;}.uagb-block-96e7c888 .uagb-ifb-button-wrapper .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-96e7c888 .uagb-ifb-image-content > img{width: 120px;max-width: 120px;}.uagb-block-4d65e1ed .uagb-ifb-icon{height: 40px;width: 40px;line-height: 40px;}.uagb-block-4d65e1ed .uagb-ifb-icon > span{font-size: 40px;height: 40px;width: 40px;line-height: 40px;color: var(--ast-global-color-0);}.uagb-block-4d65e1ed .uagb-ifb-icon svg{fill: var(--ast-global-color-0);}.uagb-block-4d65e1ed .uagb-infobox__content-wrap .uagb-ifb-imgicon-wrap{margin-left: 5px;margin-right: 10px;margin-top: 5px;margin-bottom: 5px;}.uagb-block-4d65e1ed .uagb-ifb-title-prefix{color: var(ast-global-color-7);margin-bottom: 5px;}.uagb-block-4d65e1ed .uagb-ifb-title-wrap .uagb-ifb-title{color: var(--ast-global-color-5);margin-bottom: 10px;}.uagb-block-4d65e1ed .uagb-ifb-text-wrap .uagb-ifb-desc{color: var(--ast-global-color-4);margin-bottom: 10px;}.uagb-block-4d65e1ed .uagb-ifb-separator{width: 30%;border-top-width: 2px;border-top-color: #333;border-top-style: none;}.uagb-block-4d65e1ed .uagb-ifb-separator-parent{margin-bottom: 15px;}.uagb-block-4d65e1ed .uagb-ifb-align-icon-after{margin-left: 5px;}.uagb-block-4d65e1ed .uagb-ifb-align-icon-before{margin-right: 5px;}.uagb-block-4d65e1ed .uagb-infobox-cta-link{color: #333;}.uagb-block-4d65e1ed .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-4d65e1ed .uagb-ifb-button-wrapper .uagb-infobox-cta-link{color: #333;background-color: transparent;border-style: solid;border-color: #333;border-width: 1px;padding-top: 10px;padding-bottom: 10px;padding-left: 14px;padding-right: 14px;}.uagb-block-4d65e1ed .uagb-ifb-button-wrapper .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-4d65e1ed .uagb-ifb-image-content > img{width: 120px;max-width: 120px;}.uagb-block-c223f933 .uagb-ifb-icon{height: 40px;width: 40px;line-height: 40px;}.uagb-block-c223f933 .uagb-ifb-icon > span{font-size: 40px;height: 40px;width: 40px;line-height: 40px;color: var(--ast-global-color-0);}.uagb-block-c223f933 .uagb-ifb-icon svg{fill: var(--ast-global-color-0);}.uagb-block-c223f933 .uagb-infobox__content-wrap .uagb-ifb-imgicon-wrap{margin-left: 5px;margin-right: 10px;margin-top: 5px;margin-bottom: 5px;}.uagb-block-c223f933 .uagb-ifb-title-prefix{color: var(ast-global-color-7);margin-bottom: 5px;}.uagb-block-c223f933 .uagb-ifb-title-wrap .uagb-ifb-title{color: var(--ast-global-color-5);margin-bottom: 10px;}.uagb-block-c223f933 .uagb-ifb-text-wrap .uagb-ifb-desc{color: var(--ast-global-color-4);margin-bottom: 10px;}.uagb-block-c223f933 .uagb-ifb-separator{width: 30%;border-top-width: 2px;border-top-color: #333;border-top-style: none;}.uagb-block-c223f933 .uagb-ifb-separator-parent{margin-bottom: 15px;}.uagb-block-c223f933 .uagb-ifb-align-icon-after{margin-left: 5px;}.uagb-block-c223f933 .uagb-ifb-align-icon-before{margin-right: 5px;}.uagb-block-c223f933 .uagb-infobox-cta-link{color: #333;}.uagb-block-c223f933 .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-c223f933 .uagb-ifb-button-wrapper .uagb-infobox-cta-link{color: #333;background-color: transparent;border-style: solid;border-color: #333;border-width: 1px;padding-top: 10px;padding-bottom: 10px;padding-left: 14px;padding-right: 14px;}.uagb-block-c223f933 .uagb-ifb-button-wrapper .uagb-infobox-cta-link svg{fill: #333;}.uagb-block-c223f933 .uagb-ifb-image-content > img{width: 120px;max-width: 120px;}.uag-star-rating__wrapper{display:flex;align-items:center}.uag-star-rating__wrapper.uag-star-rating__layout-stack{display:block}.uag-star-rating__wrapper .uag-star-rating__title{margin:0}.uag-star-rating__wrapper .uag-star{color:#ccd6df}\n .uagb-block-3cc7a701 .uag-star-rating{font-size: 25px;} .uagb-block-3cc7a701 .uag-star-rating > span{color: #ccd6df;} .uagb-block-3cc7a701 .uag-star:nth-child(-n+5){color: #f0ad4e;} .uagb-block-3cc7a701 .uag-star-rating__title{margin-right: 10px;} .uagb-block-3cc7a701.uag-star-rating__wrapper{justify-content: flex-start;text-align: left;} .uagb-block-3cc7a701 .uag-star:nth-child(5):before{color: #f0ad4e;position: absolute;content: \'★\';overflow: hidden;} .uagb-block-3cc7a701 .uag-star:nth-child(5){position: relative;} .uagb-block-4538d9dc .uag-star-rating{font-size: 25px;} .uagb-block-4538d9dc .uag-star-rating > span{color: #ccd6df;} .uagb-block-4538d9dc .uag-star:nth-child(-n+5){color: #f0ad4e;} .uagb-block-4538d9dc .uag-star-rating__title{margin-right: 10px;} .uagb-block-4538d9dc.uag-star-rating__wrapper{justify-content: flex-start;text-align: left;} .uagb-block-4538d9dc .uag-star:nth-child(5):before{color: #f0ad4e;position: absolute;content: \'★\';overflow: hidden;} .uagb-block-4538d9dc .uag-star:nth-child(5){position: relative;}\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:13:{i:0;s:10:\"core/cover\";i:1;s:15:\"core/media-text\";i:2;s:10:\"core/group\";i:3;s:10:\"core/image\";i:4;s:12:\"core/heading\";i:5;s:12:\"core/buttons\";i:6;s:11:\"core/button\";i:8;s:12:\"core/columns\";i:9;s:11:\"core/column\";i:10;s:13:\"uagb/info-box\";i:11;s:14:\"core/shortcode\";i:12;s:14:\"core/paragraph\";i:13;s:16:\"uagb/star-rating\";}s:8:\"uag_flag\";b:1;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1634,
3610,
'_uag_css_file_name',
'uag-css-3610-1656419539.css'
/* VALUES END */
), (
/* VALUES START */
1638,
4027,
'pageview',
10
/* VALUES END */
), (
/* VALUES START */
1639,
4043,
'_order_key',
'wc_order_qclyV3Ls6QAcw'
/* VALUES END */
), (
/* VALUES START */
1640,
4043,
'_customer_user',
1
/* VALUES END */
), (
/* VALUES START */
1641,
4043,
'_payment_method',
'cod'
/* VALUES END */
), (
/* VALUES START */
1642,
4043,
'_payment_method_title',
'Cash on delivery'
/* VALUES END */
), (
/* VALUES START */
1643,
4043,
'_customer_ip_address',
'182.68.132.91'
/* VALUES END */
), (
/* VALUES START */
1644,
4043,
'_customer_user_agent',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36'
/* VALUES END */
), (
/* VALUES START */
1645,
4043,
'_created_via',
'checkout'
/* VALUES END */
), (
/* VALUES START */
1646,
4043,
'_cart_hash',
'c53b024a6f4dc903c6418f2669e09c3f'
/* VALUES END */
), (
/* VALUES START */
1647,
4043,
'_billing_first_name',
'Mukul'
/* VALUES END */
), (
/* VALUES START */
1648,
4043,
'_billing_last_name',
'Kumar'
/* VALUES END */
), (
/* VALUES START */
1649,
4043,
'_billing_address_1',
'B-15, Ramnagar Extension, Sodhala, Jaipur'
/* VALUES END */
), (
/* VALUES START */
1650,
4043,
'_billing_address_2',
'Ekadash Kunj Apartment'
/* VALUES END */
), (
/* VALUES START */
1651,
4043,
'_billing_city',
'Jaipur'
/* VALUES END */
), (
/* VALUES START */
1652,
4043,
'_billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
1653,
4043,
'_billing_postcode',
302019
/* VALUES END */
), (
/* VALUES START */
1654,
4043,
'_billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
1655,
4043,
'_billing_email',
'mukulyashi@gmail.com'
/* VALUES END */
), (
/* VALUES START */
1656,
4043,
'_billing_phone',
6350672348
/* VALUES END */
), (
/* VALUES START */
1657,
4043,
'_order_currency',
'INR'
/* VALUES END */
), (
/* VALUES START */
1658,
4043,
'_cart_discount',
0
/* VALUES END */
), (
/* VALUES START */
1659,
4043,
'_cart_discount_tax',
0
/* VALUES END */
), (
/* VALUES START */
1660,
4043,
'_order_shipping',
0
/* VALUES END */
), (
/* VALUES START */
1661,
4043,
'_order_shipping_tax',
0
/* VALUES END */
), (
/* VALUES START */
1662,
4043,
'_order_tax',
0
/* VALUES END */
), (
/* VALUES START */
1663,
4043,
'_order_total',
80
/* VALUES END */
), (
/* VALUES START */
1664,
4043,
'_order_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1665,
4043,
'_prices_include_tax',
'no'
/* VALUES END */
), (
/* VALUES START */
1666,
4043,
'_billing_address_index',
'Mukul Kumar  B-15, Ramnagar Extension, Sodhala, Jaipur Ekadash Kunj Apartment Jaipur RJ 302019 IN mukulyashi@gmail.com 6350672348'
/* VALUES END */
), (
/* VALUES START */
1667,
4043,
'_shipping_address_index',
'         '
/* VALUES END */
), (
/* VALUES START */
1668,
4043,
'is_vat_exempt',
'no'
/* VALUES END */
), (
/* VALUES START */
1669,
4043,
'_dokan_vendor_id',
3
/* VALUES END */
), (
/* VALUES START */
1670,
4043,
'shipping_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1671,
4043,
'tax_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1672,
4043,
'_download_permissions_granted',
'yes'
/* VALUES END */
), (
/* VALUES START */
1673,
4043,
'_recorded_sales',
'yes'
/* VALUES END */
), (
/* VALUES START */
1674,
4043,
'_recorded_coupon_usage_counts',
'yes'
/* VALUES END */
), (
/* VALUES START */
1675,
4043,
'_order_stock_reduced',
'yes'
/* VALUES END */
), (
/* VALUES START */
1676,
4043,
'_new_order_email_sent',
'true'
/* VALUES END */
), (
/* VALUES START */
1677,
4044,
'_order_key',
'wc_order_n9IQFCl7bkP4h'
/* VALUES END */
), (
/* VALUES START */
1678,
4044,
'_customer_user',
4
/* VALUES END */
), (
/* VALUES START */
1679,
4044,
'_payment_method',
'cod'
/* VALUES END */
), (
/* VALUES START */
1680,
4044,
'_payment_method_title',
'Cash on delivery'
/* VALUES END */
), (
/* VALUES START */
1681,
4044,
'_customer_ip_address',
'182.68.132.91'
/* VALUES END */
), (
/* VALUES START */
1682,
4044,
'_customer_user_agent',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36'
/* VALUES END */
), (
/* VALUES START */
1683,
4044,
'_created_via',
'checkout'
/* VALUES END */
), (
/* VALUES START */
1684,
4044,
'_cart_hash',
'c53b024a6f4dc903c6418f2669e09c3f'
/* VALUES END */
), (
/* VALUES START */
1685,
4044,
'_billing_first_name',
'Ashish'
/* VALUES END */
), (
/* VALUES START */
1686,
4044,
'_billing_last_name',
'Agarwal'
/* VALUES END */
), (
/* VALUES START */
1687,
4044,
'_billing_address_1',
'ls nagr'
/* VALUES END */
), (
/* VALUES START */
1688,
4044,
'_billing_city',
'jaipur'
/* VALUES END */
), (
/* VALUES START */
1689,
4044,
'_billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
1690,
4044,
'_billing_postcode',
302039
/* VALUES END */
), (
/* VALUES START */
1691,
4044,
'_billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
1692,
4044,
'_billing_email',
'ashishshiv781@gmail.com'
/* VALUES END */
), (
/* VALUES START */
1693,
4044,
'_billing_phone',
9876543210
/* VALUES END */
), (
/* VALUES START */
1694,
4044,
'_order_currency',
'INR'
/* VALUES END */
), (
/* VALUES START */
1695,
4044,
'_cart_discount',
0
/* VALUES END */
), (
/* VALUES START */
1696,
4044,
'_cart_discount_tax',
0
/* VALUES END */
), (
/* VALUES START */
1697,
4044,
'_order_shipping',
0
/* VALUES END */
), (
/* VALUES START */
1698,
4044,
'_order_shipping_tax',
0
/* VALUES END */
), (
/* VALUES START */
1699,
4044,
'_order_tax',
0
/* VALUES END */
), (
/* VALUES START */
1700,
4044,
'_order_total',
80
/* VALUES END */
), (
/* VALUES START */
1701,
4044,
'_order_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1702,
4044,
'_prices_include_tax',
'no'
/* VALUES END */
), (
/* VALUES START */
1703,
4044,
'_billing_address_index',
'Ashish Agarwal  ls nagr  jaipur RJ 302039 IN ashishshiv781@gmail.com 9876543210'
/* VALUES END */
), (
/* VALUES START */
1704,
4044,
'_shipping_address_index',
'         '
/* VALUES END */
), (
/* VALUES START */
1705,
4044,
'is_vat_exempt',
'no'
/* VALUES END */
), (
/* VALUES START */
1706,
4044,
'_dokan_vendor_id',
3
/* VALUES END */
), (
/* VALUES START */
1707,
4044,
'shipping_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1708,
4044,
'tax_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1709,
4044,
'_download_permissions_granted',
'yes'
/* VALUES END */
), (
/* VALUES START */
1710,
4044,
'_recorded_sales',
'yes'
/* VALUES END */
), (
/* VALUES START */
1711,
4044,
'_recorded_coupon_usage_counts',
'yes'
/* VALUES END */
), (
/* VALUES START */
1712,
4044,
'_order_stock_reduced',
'yes'
/* VALUES END */
), (
/* VALUES START */
1713,
4044,
'_new_order_email_sent',
'true'
/* VALUES END */
), (
/* VALUES START */
1714,
4023,
'pageview',
8
/* VALUES END */
), (
/* VALUES START */
1715,
4025,
'pageview',
7
/* VALUES END */
), (
/* VALUES START */
1716,
3682,
'pageview',
10
/* VALUES END */
), (
/* VALUES START */
1717,
2,
'_uag_page_assets',
'a:7:{s:3:\"css\";s:0:\"\";s:2:\"js\";s:0:\"\";s:18:\"current_block_list\";a:2:{i:0;s:14:\"core/paragraph\";i:1;s:10:\"core/quote\";}s:8:\"uag_flag\";b:0;s:11:\"uag_version\";s:10:\"1655099702\";s:6:\"gfonts\";a:0:{}s:14:\"uag_faq_layout\";b:0;}'
/* VALUES END */
), (
/* VALUES START */
1718,
3677,
'pageview',
7
/* VALUES END */
), (
/* VALUES START */
1719,
4046,
'_order_key',
'wc_order_lYOqjFxm8UymB'
/* VALUES END */
), (
/* VALUES START */
1720,
4046,
'_customer_user',
4
/* VALUES END */
), (
/* VALUES START */
1721,
4046,
'_payment_method',
'cod'
/* VALUES END */
), (
/* VALUES START */
1722,
4046,
'_payment_method_title',
'Cash on delivery'
/* VALUES END */
), (
/* VALUES START */
1723,
4046,
'_customer_ip_address',
'223.177.215.57'
/* VALUES END */
), (
/* VALUES START */
1724,
4046,
'_customer_user_agent',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36'
/* VALUES END */
), (
/* VALUES START */
1725,
4046,
'_created_via',
'checkout'
/* VALUES END */
), (
/* VALUES START */
1726,
4046,
'_cart_hash',
'bc73a0345a13d547c4df7a9887c1a1ca'
/* VALUES END */
), (
/* VALUES START */
1727,
4046,
'_billing_first_name',
'Ashish'
/* VALUES END */
), (
/* VALUES START */
1728,
4046,
'_billing_last_name',
'Agarwal'
/* VALUES END */
), (
/* VALUES START */
1729,
4046,
'_billing_address_1',
'ls nagr'
/* VALUES END */
), (
/* VALUES START */
1730,
4046,
'_billing_city',
'jaipur'
/* VALUES END */
), (
/* VALUES START */
1731,
4046,
'_billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
1732,
4046,
'_billing_postcode',
302039
/* VALUES END */
), (
/* VALUES START */
1733,
4046,
'_billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
1734,
4046,
'_billing_email',
'ashishshiv781@gmail.com'
/* VALUES END */
), (
/* VALUES START */
1735,
4046,
'_billing_phone',
9876543210
/* VALUES END */
), (
/* VALUES START */
1736,
4046,
'_order_currency',
'INR'
/* VALUES END */
), (
/* VALUES START */
1737,
4046,
'_cart_discount',
0
/* VALUES END */
), (
/* VALUES START */
1738,
4046,
'_cart_discount_tax',
0
/* VALUES END */
), (
/* VALUES START */
1739,
4046,
'_order_shipping',
0
/* VALUES END */
), (
/* VALUES START */
1740,
4046,
'_order_shipping_tax',
0
/* VALUES END */
), (
/* VALUES START */
1741,
4046,
'_order_tax',
0
/* VALUES END */
), (
/* VALUES START */
1742,
4046,
'_order_total',
140
/* VALUES END */
), (
/* VALUES START */
1743,
4046,
'_order_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1744,
4046,
'_prices_include_tax',
'no'
/* VALUES END */
), (
/* VALUES START */
1745,
4046,
'_billing_address_index',
'Ashish Agarwal  ls nagr  jaipur RJ 302039 IN ashishshiv781@gmail.com 9876543210'
/* VALUES END */
), (
/* VALUES START */
1746,
4046,
'_shipping_address_index',
'         '
/* VALUES END */
), (
/* VALUES START */
1747,
4046,
'is_vat_exempt',
'no'
/* VALUES END */
), (
/* VALUES START */
1748,
4046,
'has_sub_order',
1
/* VALUES END */
), (
/* VALUES START */
1749,
4047,
'_order_key',
'wc_order_q2BrpunNsADqG'
/* VALUES END */
), (
/* VALUES START */
1750,
4047,
'_customer_user',
4
/* VALUES END */
), (
/* VALUES START */
1751,
4047,
'_billing_first_name',
'Ashish'
/* VALUES END */
), (
/* VALUES START */
1752,
4047,
'_billing_last_name',
'Agarwal'
/* VALUES END */
), (
/* VALUES START */
1753,
4047,
'_billing_address_1',
'ls nagr'
/* VALUES END */
), (
/* VALUES START */
1754,
4047,
'_billing_city',
'jaipur'
/* VALUES END */
), (
/* VALUES START */
1755,
4047,
'_billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
1756,
4047,
'_billing_postcode',
302039
/* VALUES END */
), (
/* VALUES START */
1757,
4047,
'_billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
1758,
4047,
'_billing_email',
'ashishshiv781@gmail.com'
/* VALUES END */
), (
/* VALUES START */
1759,
4047,
'_billing_phone',
9876543210
/* VALUES END */
), (
/* VALUES START */
1760,
4047,
'_order_currency',
'INR'
/* VALUES END */
), (
/* VALUES START */
1761,
4047,
'_cart_discount',
0
/* VALUES END */
), (
/* VALUES START */
1762,
4047,
'_cart_discount_tax',
0
/* VALUES END */
), (
/* VALUES START */
1763,
4047,
'_order_shipping',
0
/* VALUES END */
), (
/* VALUES START */
1764,
4047,
'_order_shipping_tax',
0
/* VALUES END */
), (
/* VALUES START */
1765,
4047,
'_order_tax',
0
/* VALUES END */
), (
/* VALUES START */
1766,
4047,
'_order_total',
60
/* VALUES END */
), (
/* VALUES START */
1767,
4047,
'_order_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1768,
4047,
'_prices_include_tax',
'no'
/* VALUES END */
), (
/* VALUES START */
1769,
4047,
'_billing_address_index',
'Ashish Agarwal  ls nagr  jaipur RJ 302039 IN ashishshiv781@gmail.com 9876543210'
/* VALUES END */
), (
/* VALUES START */
1770,
4047,
'_shipping_address_index',
'         '
/* VALUES END */
), (
/* VALUES START */
1771,
4047,
'_dokan_vendor_id',
1
/* VALUES END */
), (
/* VALUES START */
1772,
4047,
'_payment_method',
'cod'
/* VALUES END */
), (
/* VALUES START */
1773,
4047,
'_payment_method_title',
'Cash on delivery'
/* VALUES END */
), (
/* VALUES START */
1774,
4047,
'_customer_ip_address',
'223.177.215.57'
/* VALUES END */
), (
/* VALUES START */
1775,
4047,
'_customer_user_agent',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36'
/* VALUES END */
), (
/* VALUES START */
1776,
4047,
'_created_via',
'dokan'
/* VALUES END */
), (
/* VALUES START */
1777,
4047,
'_cart_hash',
'bc73a0345a13d547c4df7a9887c1a1ca'
/* VALUES END */
), (
/* VALUES START */
1778,
4047,
'_recorded_sales',
'yes'
/* VALUES END */
), (
/* VALUES START */
1779,
4047,
'shipping_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1780,
4047,
'tax_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1781,
4048,
'_order_key',
'wc_order_rYqvmtsgxGfQc'
/* VALUES END */
), (
/* VALUES START */
1782,
4048,
'_customer_user',
4
/* VALUES END */
), (
/* VALUES START */
1783,
4048,
'_billing_first_name',
'Ashish'
/* VALUES END */
), (
/* VALUES START */
1784,
4048,
'_billing_last_name',
'Agarwal'
/* VALUES END */
), (
/* VALUES START */
1785,
4048,
'_billing_address_1',
'ls nagr'
/* VALUES END */
), (
/* VALUES START */
1786,
4048,
'_billing_city',
'jaipur'
/* VALUES END */
), (
/* VALUES START */
1787,
4048,
'_billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
1788,
4048,
'_billing_postcode',
302039
/* VALUES END */
), (
/* VALUES START */
1789,
4048,
'_billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
1790,
4048,
'_billing_email',
'ashishshiv781@gmail.com'
/* VALUES END */
), (
/* VALUES START */
1791,
4048,
'_billing_phone',
9876543210
/* VALUES END */
), (
/* VALUES START */
1792,
4048,
'_order_currency',
'INR'
/* VALUES END */
), (
/* VALUES START */
1793,
4048,
'_cart_discount',
0
/* VALUES END */
), (
/* VALUES START */
1794,
4048,
'_cart_discount_tax',
0
/* VALUES END */
), (
/* VALUES START */
1795,
4048,
'_order_shipping',
0
/* VALUES END */
), (
/* VALUES START */
1796,
4048,
'_order_shipping_tax',
0
/* VALUES END */
), (
/* VALUES START */
1797,
4048,
'_order_tax',
0
/* VALUES END */
), (
/* VALUES START */
1798,
4048,
'_order_total',
80
/* VALUES END */
), (
/* VALUES START */
1799,
4048,
'_order_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1800,
4048,
'_prices_include_tax',
'no'
/* VALUES END */
), (
/* VALUES START */
1801,
4048,
'_billing_address_index',
'Ashish Agarwal  ls nagr  jaipur RJ 302039 IN ashishshiv781@gmail.com 9876543210'
/* VALUES END */
), (
/* VALUES START */
1802,
4048,
'_shipping_address_index',
'         '
/* VALUES END */
), (
/* VALUES START */
1803,
4048,
'_dokan_vendor_id',
3
/* VALUES END */
), (
/* VALUES START */
1804,
4048,
'_payment_method',
'cod'
/* VALUES END */
), (
/* VALUES START */
1805,
4048,
'_payment_method_title',
'Cash on delivery'
/* VALUES END */
), (
/* VALUES START */
1806,
4048,
'_customer_ip_address',
'223.177.215.57'
/* VALUES END */
), (
/* VALUES START */
1807,
4048,
'_customer_user_agent',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36'
/* VALUES END */
), (
/* VALUES START */
1808,
4048,
'_created_via',
'dokan'
/* VALUES END */
), (
/* VALUES START */
1809,
4048,
'_cart_hash',
'bc73a0345a13d547c4df7a9887c1a1ca'
/* VALUES END */
), (
/* VALUES START */
1810,
4048,
'_recorded_sales',
'yes'
/* VALUES END */
), (
/* VALUES START */
1811,
4048,
'shipping_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1812,
4048,
'tax_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1813,
4046,
'_download_permissions_granted',
'yes'
/* VALUES END */
), (
/* VALUES START */
1814,
4046,
'_recorded_sales',
'yes'
/* VALUES END */
), (
/* VALUES START */
1815,
4046,
'_recorded_coupon_usage_counts',
'yes'
/* VALUES END */
), (
/* VALUES START */
1816,
4046,
'_order_stock_reduced',
'yes'
/* VALUES END */
), (
/* VALUES START */
1817,
4046,
'_new_order_email_sent',
'true'
/* VALUES END */
), (
/* VALUES START */
1818,
4047,
'_download_permissions_granted',
'yes'
/* VALUES END */
), (
/* VALUES START */
1819,
4047,
'_recorded_coupon_usage_counts',
'yes'
/* VALUES END */
), (
/* VALUES START */
1820,
4047,
'_order_stock_reduced',
'yes'
/* VALUES END */
), (
/* VALUES START */
1821,
4048,
'_download_permissions_granted',
'yes'
/* VALUES END */
), (
/* VALUES START */
1822,
4048,
'_recorded_coupon_usage_counts',
'yes'
/* VALUES END */
), (
/* VALUES START */
1823,
4048,
'_order_stock_reduced',
'yes'
/* VALUES END */
), (
/* VALUES START */
1824,
4049,
'_order_key',
'wc_order_lxFoPyKlFq9w5'
/* VALUES END */
), (
/* VALUES START */
1825,
4049,
'_customer_user',
0
/* VALUES END */
), (
/* VALUES START */
1826,
4049,
'_payment_method',
'cod'
/* VALUES END */
), (
/* VALUES START */
1827,
4049,
'_payment_method_title',
'Cash on delivery'
/* VALUES END */
), (
/* VALUES START */
1828,
4049,
'_customer_ip_address',
'223.177.215.57'
/* VALUES END */
), (
/* VALUES START */
1829,
4049,
'_customer_user_agent',
'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36'
/* VALUES END */
), (
/* VALUES START */
1830,
4049,
'_created_via',
'checkout'
/* VALUES END */
), (
/* VALUES START */
1831,
4049,
'_cart_hash',
'bf94f62880ace1e748b23ebdcf3d54af'
/* VALUES END */
), (
/* VALUES START */
1832,
4049,
'_billing_first_name',
'ashish'
/* VALUES END */
), (
/* VALUES START */
1833,
4049,
'_billing_last_name',
'agarwal'
/* VALUES END */
), (
/* VALUES START */
1834,
4049,
'_billing_company',
'ashish'
/* VALUES END */
), (
/* VALUES START */
1835,
4049,
'_billing_address_1',
'aaa'
/* VALUES END */
), (
/* VALUES START */
1836,
4049,
'_billing_address_2',
'aaa'
/* VALUES END */
), (
/* VALUES START */
1837,
4049,
'_billing_city',
'aaa2'
/* VALUES END */
), (
/* VALUES START */
1838,
4049,
'_billing_state',
'RJ'
/* VALUES END */
), (
/* VALUES START */
1839,
4049,
'_billing_postcode',
666666
/* VALUES END */
), (
/* VALUES START */
1840,
4049,
'_billing_country',
'IN'
/* VALUES END */
), (
/* VALUES START */
1841,
4049,
'_billing_email',
'aaaa@gmail.co'
/* VALUES END */
), (
/* VALUES START */
1842,
4049,
'_billing_phone',
2222
/* VALUES END */
), (
/* VALUES START */
1843,
4049,
'_order_currency',
'INR'
/* VALUES END */
), (
/* VALUES START */
1844,
4049,
'_cart_discount',
0
/* VALUES END */
), (
/* VALUES START */
1845,
4049,
'_cart_discount_tax',
0
/* VALUES END */
), (
/* VALUES START */
1846,
4049,
'_order_shipping',
0
/* VALUES END */
), (
/* VALUES START */
1847,
4049,
'_order_shipping_tax',
0
/* VALUES END */
), (
/* VALUES START */
1848,
4049,
'_order_tax',
0
/* VALUES END */
), (
/* VALUES START */
1849,
4049,
'_order_total',
240
/* VALUES END */
), (
/* VALUES START */
1850,
4049,
'_order_version',
'6.6.0'
/* VALUES END */
), (
/* VALUES START */
1851,
4049,
'_prices_include_tax',
'no'
/* VALUES END */
), (
/* VALUES START */
1852,
4049,
'_billing_address_index',
'ashish agarwal ashish aaa aaa aaa2 RJ 666666 IN aaaa@gmail.co 2222'
/* VALUES END */
), (
/* VALUES START */
1853,
4049,
'_shipping_address_index',
'         '
/* VALUES END */
), (
/* VALUES START */
1854,
4049,
'is_vat_exempt',
'no'
/* VALUES END */
), (
/* VALUES START */
1855,
4049,
'_dokan_vendor_id',
3
/* VALUES END */
), (
/* VALUES START */
1856,
4049,
'shipping_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1857,
4049,
'tax_fee_recipient',
'admin'
/* VALUES END */
), (
/* VALUES START */
1858,
4049,
'_download_permissions_granted',
'yes'
/* VALUES END */
), (
/* VALUES START */
1859,
4049,
'_recorded_sales',
'yes'
/* VALUES END */
), (
/* VALUES START */
1860,
4049,
'_recorded_coupon_usage_counts',
'yes'
/* VALUES END */
), (
/* VALUES START */
1861,
4049,
'_order_stock_reduced',
'yes'
/* VALUES END */
), (
/* VALUES START */
1862,
4049,
'_new_order_email_sent',
'true'
/* VALUES END */
);
/* QUERY END */

