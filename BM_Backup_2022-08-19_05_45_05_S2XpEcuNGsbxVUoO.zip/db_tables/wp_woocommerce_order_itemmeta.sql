/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_woocommerce_order_itemmeta`; */
/* PRE_TABLE_NAME: `1660887906_wp_woocommerce_order_itemmeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_woocommerce_order_itemmeta` (`meta_id`, `order_item_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
10,
2,
'_product_id',
3979
/* VALUES END */
), (
/* VALUES START */
11,
2,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
12,
2,
'_qty',
1
/* VALUES END */
), (
/* VALUES START */
13,
2,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
14,
2,
'_line_subtotal',
60
/* VALUES END */
), (
/* VALUES START */
15,
2,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
16,
2,
'_line_total',
60
/* VALUES END */
), (
/* VALUES START */
17,
2,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
18,
2,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
19,
3,
'_product_id',
3979
/* VALUES END */
), (
/* VALUES START */
20,
3,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
21,
3,
'_qty',
5
/* VALUES END */
), (
/* VALUES START */
22,
3,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
23,
3,
'_line_subtotal',
300
/* VALUES END */
), (
/* VALUES START */
24,
3,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
25,
3,
'_line_total',
300
/* VALUES END */
), (
/* VALUES START */
26,
3,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
27,
3,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
29,
4,
'_product_id',
3979
/* VALUES END */
), (
/* VALUES START */
30,
4,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
31,
4,
'_qty',
1
/* VALUES END */
), (
/* VALUES START */
32,
4,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
33,
4,
'_line_subtotal',
60
/* VALUES END */
), (
/* VALUES START */
34,
4,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
35,
4,
'_line_total',
60
/* VALUES END */
), (
/* VALUES START */
36,
4,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
37,
4,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
38,
4,
'_dokan_commission_rate',
10
/* VALUES END */
), (
/* VALUES START */
39,
4,
'_dokan_commission_type',
'flat'
/* VALUES END */
), (
/* VALUES START */
40,
4,
'_dokan_additional_fee',
0
/* VALUES END */
), (
/* VALUES START */
41,
4,
'_reduced_stock',
1
/* VALUES END */
), (
/* VALUES START */
42,
5,
'_product_id',
4027
/* VALUES END */
), (
/* VALUES START */
43,
5,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
44,
5,
'_qty',
1
/* VALUES END */
), (
/* VALUES START */
45,
5,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
46,
5,
'_line_subtotal',
80
/* VALUES END */
), (
/* VALUES START */
47,
5,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
48,
5,
'_line_total',
80
/* VALUES END */
), (
/* VALUES START */
49,
5,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
50,
5,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
51,
5,
'_dokan_commission_rate',
10
/* VALUES END */
), (
/* VALUES START */
52,
5,
'_dokan_commission_type',
'flat'
/* VALUES END */
), (
/* VALUES START */
53,
5,
'_dokan_additional_fee',
0
/* VALUES END */
), (
/* VALUES START */
54,
6,
'_product_id',
4027
/* VALUES END */
), (
/* VALUES START */
55,
6,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
56,
6,
'_qty',
1
/* VALUES END */
), (
/* VALUES START */
57,
6,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
58,
6,
'_line_subtotal',
80
/* VALUES END */
), (
/* VALUES START */
59,
6,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
60,
6,
'_line_total',
80
/* VALUES END */
), (
/* VALUES START */
61,
6,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
62,
6,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
63,
6,
'_dokan_commission_rate',
10
/* VALUES END */
), (
/* VALUES START */
64,
6,
'_dokan_commission_type',
'flat'
/* VALUES END */
), (
/* VALUES START */
65,
6,
'_dokan_additional_fee',
0
/* VALUES END */
), (
/* VALUES START */
66,
7,
'_product_id',
3979
/* VALUES END */
), (
/* VALUES START */
67,
7,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
68,
7,
'_qty',
1
/* VALUES END */
), (
/* VALUES START */
69,
7,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
70,
7,
'_line_subtotal',
60
/* VALUES END */
), (
/* VALUES START */
71,
7,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
72,
7,
'_line_total',
60
/* VALUES END */
), (
/* VALUES START */
73,
7,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
74,
7,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
75,
8,
'_product_id',
4027
/* VALUES END */
), (
/* VALUES START */
76,
8,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
77,
8,
'_qty',
1
/* VALUES END */
), (
/* VALUES START */
78,
8,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
79,
8,
'_line_subtotal',
80
/* VALUES END */
), (
/* VALUES START */
80,
8,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
81,
8,
'_line_total',
80
/* VALUES END */
), (
/* VALUES START */
82,
8,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
83,
8,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
84,
9,
'_product_id',
3979
/* VALUES END */
), (
/* VALUES START */
85,
9,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
86,
9,
'_qty',
1
/* VALUES END */
), (
/* VALUES START */
87,
9,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
88,
9,
'_line_subtotal',
60
/* VALUES END */
), (
/* VALUES START */
89,
9,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
90,
9,
'_line_total',
60
/* VALUES END */
), (
/* VALUES START */
91,
9,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
92,
9,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
93,
9,
'_dokan_commission_rate',
10
/* VALUES END */
), (
/* VALUES START */
94,
9,
'_dokan_commission_type',
'flat'
/* VALUES END */
), (
/* VALUES START */
95,
9,
'_dokan_additional_fee',
0
/* VALUES END */
), (
/* VALUES START */
96,
10,
'_product_id',
4027
/* VALUES END */
), (
/* VALUES START */
97,
10,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
98,
10,
'_qty',
1
/* VALUES END */
), (
/* VALUES START */
99,
10,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
100,
10,
'_line_subtotal',
80
/* VALUES END */
), (
/* VALUES START */
101,
10,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
102,
10,
'_line_total',
80
/* VALUES END */
), (
/* VALUES START */
103,
10,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
104,
10,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
105,
10,
'_dokan_commission_rate',
10
/* VALUES END */
), (
/* VALUES START */
106,
10,
'_dokan_commission_type',
'flat'
/* VALUES END */
), (
/* VALUES START */
107,
10,
'_dokan_additional_fee',
0
/* VALUES END */
), (
/* VALUES START */
108,
7,
'_reduced_stock',
1
/* VALUES END */
), (
/* VALUES START */
110,
11,
'_product_id',
4029
/* VALUES END */
), (
/* VALUES START */
111,
11,
'_variation_id',
0
/* VALUES END */
), (
/* VALUES START */
112,
11,
'_qty',
2
/* VALUES END */
), (
/* VALUES START */
113,
11,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
114,
11,
'_line_subtotal',
240
/* VALUES END */
), (
/* VALUES START */
115,
11,
'_line_subtotal_tax',
0
/* VALUES END */
), (
/* VALUES START */
116,
11,
'_line_total',
240
/* VALUES END */
), (
/* VALUES START */
117,
11,
'_line_tax',
0
/* VALUES END */
), (
/* VALUES START */
118,
11,
'_line_tax_data',
'a:2:{s:5:\"total\";a:0:{}s:8:\"subtotal\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
119,
11,
'_dokan_commission_rate',
10
/* VALUES END */
), (
/* VALUES START */
120,
11,
'_dokan_commission_type',
'flat'
/* VALUES END */
), (
/* VALUES START */
121,
11,
'_dokan_additional_fee',
0
/* VALUES END */
);
/* QUERY END */

