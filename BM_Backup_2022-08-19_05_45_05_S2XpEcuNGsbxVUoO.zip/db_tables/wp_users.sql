/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_users`; */
/* PRE_TABLE_NAME: `1660887906_wp_users`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1660887906_wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1660887906_wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ( 
/* VALUES START */
1,
'mukulyashi@gmail.com',
'$P$Bu.6.uTl3RH68cPVYBwZPD9jjYSLSb/',
'mukulyashigmail-com',
'mukulyashi@gmail.com',
'http://13.233.32.209',
'2022-06-13 05:44:45',
'',
0,
'Mukul Kumar'
/* VALUES END */
), (
/* VALUES START */
2,
'mukuljaipur.2000',
'$P$BLKetfCA9bn1fybQx6CZ.cDKaNgsJB/',
'mukuljaipur-2000',
'mukuljaipur.2000@gmail.com',
'',
'2022-06-16 06:11:34',
'1655359894:$P$BKXwyVfjO/rBjfswC/xibzuHrLJDtq0',
0,
'mukuljaipur.2000'
/* VALUES END */
), (
/* VALUES START */
3,
'poonamagarwal0071',
'$P$BjnkV6wEGBya1cKtku3chfuu.1M7oR1',
'shree-store',
'Poonamagarwal0071@gmail.com',
'',
'2022-06-23 11:55:16',
'1656435404:$P$B2KbNTnTGkbptGek4TG1F4eMAZPNt00',
0,
'Poonam Agarwal'
/* VALUES END */
), (
/* VALUES START */
4,
'ashishshiv781',
'$P$BTmN4pkV4AnQsPy.xHV2D3/7RUWlr0/',
'ashishshiv781',
'ashishshiv781@gmail.com',
'',
'2022-06-25 14:11:20',
'1656166280:$P$BEBlHx1MA/NPuf0tiCw7jtSheRZe270',
0,
'ashishshiv781'
/* VALUES END */
), (
/* VALUES START */
5,
'testcustomer',
'$P$BrtdD6TcEeqPANeV4In.vKk3LAw8d8/',
'testcustomer',
'testcustomer@gmail.com',
'',
'2022-06-28 05:27:40',
'',
0,
'test customer'
/* VALUES END */
);
/* QUERY END */

